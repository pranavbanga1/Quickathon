# 🤖 Complete ROS 2 Integration Setup Guide

**Comprehensive step-by-step guide to integrate the Rover Dashboard with real ROS 2 topics on your rover.**

---

## Table of Contents

1. [Prerequisites](#prerequisites)
2. [ROS 2 Installation](#ros-2-installation)
3. [Setting Up the Bridge](#setting-up-the-bridge)
4. [Creating Publisher Nodes](#creating-publisher-nodes)
5. [Configuring the Dashboard](#configuring-the-dashboard)
6. [Testing ROS 2 Integration](#testing-ros-2-integration)
7. [Troubleshooting](#troubleshooting)

---

## Prerequisites

### System Requirements

| Component | Requirement | Check |
|-----------|-------------|-------|
| **OS** | Ubuntu 20.04+ or Ubuntu 22.04 | `lsb_release -a` |
| **ROS 2** | Foxy, Galactic, Humble, or Iron | `ros2 --version` |
| **Python** | 3.8+ | `python3 --version` |
| **Node.js** | 16+ | `node --version` |
| **Network** | Rover and operator on same network | `ping <rover-ip>` |

### Verify ROS 2 Installation

```bash
# Check if ROS 2 is installed
ros2 --version

# If not installed, see ROS 2 Installation section below

# Source ROS 2 setup
source /opt/ros/<distro>/setup.bash

# Verify ROS 2 is working
ros2 topic list
```

---

## ROS 2 Installation

### Option 1: Ubuntu 22.04 (Humble)

```bash
# Set locale
locale  # check for UTF-8

# Setup Sources
sudo apt update && sudo apt install curl gnupg lsb-release ubuntu-keyring

# Add ROS 2 GPG key
sudo curl -sSL https://repo.ros2.org/ros.key -o /usr/share/keyrings/ros-archive-keyring.gpg

# Add repository
echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/ros-archive-keyring.gpg] http://packages.ros2.org/ubuntu $(source /etc/os-release && echo $UBUNTU_CODENAME) main" | sudo tee /etc/apt/sources.list.d/ros2.list > /dev/null

# Install ROS 2
sudo apt update
sudo apt install ros-humble-desktop

# Setup environment
echo "source /opt/ros/humble/setup.bash" >> ~/.bashrc
source ~/.bashrc
```

### Option 2: Ubuntu 20.04 (Foxy)

```bash
# Set locale
locale

# Setup Sources
sudo apt update && sudo apt install curl gnupg lsb-release ubuntu-keyring

# Add ROS 2 GPG key
sudo curl -sSL https://repo.ros2.org/ros.key -o /usr/share/keyrings/ros-archive-keyring.gpg

# Add repository
echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/ros-archive-keyring.gpg] http://packages.ros2.org/ubuntu $(source /etc/os-release && echo $UBUNTU_CODENAME) main" | sudo tee /etc/apt/sources.list.d/ros2.list > /dev/null

# Install ROS 2
sudo apt update
sudo apt install ros-foxy-desktop

# Setup environment
echo "source /opt/ros/foxy/setup.bash" >> ~/.bashrc
source ~/.bashrc
```

### Verify Installation

```bash
# Test ROS 2 installation
ros2 run demo_nodes_cpp talker

# In another terminal
ros2 run demo_nodes_cpp listener

# You should see messages being exchanged
```

---

## Setting Up the Bridge

### Step 1: Understand the Bridge Architecture

The bridge connects your dashboard to ROS 2 topics:

```
ROS 2 Topics (rover)
    ↓
Bridge Server (Node.js)
    ↓
WebSocket Connection
    ↓
Dashboard (Browser)
```

### Step 2: Configure Bridge for ROS 2

Edit the bridge configuration file:

```bash
# Open the bridge file
nano ~/rover_dashboard/ros2-bridge-simulator.mjs

# Find this section:
# const DATA_SOURCE = process.env.DATA_SOURCE || 'simulator';

# Change to:
# const DATA_SOURCE = process.env.DATA_SOURCE || 'ros';
```

Or set environment variable:

```bash
# Set ROS mode
export DATA_SOURCE=ros

# Start bridge
node ros2-bridge-simulator.mjs
```

### Step 3: Start the Bridge on Rover/Network

```bash
# On the rover or a machine running ROS 2
cd ~/rover_dashboard

# Start bridge with ROS 2 data source
DATA_SOURCE=ros node ros2-bridge-simulator.mjs

# Expected output:
# [Bridge] Server running on port 9090
# [Bridge] Data source: ros
# [Bridge] Listening for ROS 2 topics...
# [Bridge] WebSocket ready for connections
```

**Important:** Note the IP address of the machine running the bridge:

```bash
# Get your IP address
hostname -I

# Example output: 192.168.1.100 172.17.0.1
# Use the first one (192.168.1.100)
```

---

## Creating Publisher Nodes

### Step 1: Create ROS 2 Package

```bash
# Create workspace
mkdir -p ~/rover_ws/src
cd ~/rover_ws

# Create package
ros2 pkg create rover_telemetry --build-type ament_python

# Navigate to package
cd src/rover_telemetry
```

### Step 2: Create Network Health Publisher

Create file: `rover_telemetry/network_health_publisher.py`

```python
#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32, Int32
import random
import math
import time

class NetworkHealthPublisher(Node):
    def __init__(self):
        super().__init__('network_health_publisher')
        
        # Create publishers
        self.latency_pub = self.create_publisher(Float32, '/rover/network/latency', 10)
        self.packet_loss_pub = self.create_publisher(Float32, '/rover/network/packet_loss', 10)
        self.signal_strength_pub = self.create_publisher(Int32, '/rover/network/signal_strength', 10)
        self.tx_throughput_pub = self.create_publisher(Float32, '/rover/network/tx_throughput', 10)
        self.rx_throughput_pub = self.create_publisher(Float32, '/rover/network/rx_throughput', 10)
        
        # Create timer for publishing
        self.timer = self.create_timer(0.1, self.publish_data)
        self.time_elapsed = 0
        
        self.get_logger().info('Network Health Publisher started')
    
    def publish_data(self):
        # Simulate realistic network metrics
        t = self.time_elapsed * 0.3
        
        # Latency with oscillation
        base_latency = 40.0
        oscillation = 10.0 * math.sin(t * 0.5)
        spike = random.gauss(0, 5) if random.random() < 0.1 else 0
        latency = max(10, base_latency + oscillation + spike)
        
        # Packet loss
        if random.random() < 0.95:
            packet_loss = random.gauss(0.05, 0.02)
        else:
            packet_loss = random.gauss(0.5, 0.3)
        packet_loss = max(0, min(5, packet_loss))
        
        # Signal strength
        signal_strength = int(-75 + random.gauss(0, 5))
        signal_strength = max(-90, min(-60, signal_strength))
        
        # Throughput
        tx_throughput = 50 + random.gauss(0, 10)
        tx_throughput = max(20, min(100, tx_throughput))
        
        rx_throughput = 70 + random.gauss(0, 15)
        rx_throughput = max(40, min(120, rx_throughput))
        
        # Publish messages
        latency_msg = Float32()
        latency_msg.data = latency
        self.latency_pub.publish(latency_msg)
        
        packet_loss_msg = Float32()
        packet_loss_msg.data = packet_loss
        self.packet_loss_pub.publish(packet_loss_msg)
        
        signal_strength_msg = Int32()
        signal_strength_msg.data = signal_strength
        self.signal_strength_pub.publish(signal_strength_msg)
        
        tx_throughput_msg = Float32()
        tx_throughput_msg.data = tx_throughput
        self.tx_throughput_pub.publish(tx_throughput_msg)
        
        rx_throughput_msg = Float32()
        rx_throughput_msg.data = rx_throughput
        self.rx_throughput_pub.publish(rx_throughput_msg)
        
        self.time_elapsed += 0.1

def main(args=None):
    rclpy.init(args=args)
    node = NetworkHealthPublisher()
    
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
```

### Step 3: Create Joystick Publisher

Create file: `rover_telemetry/joystick_publisher.py`

```python
#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Joy
import math
import time

class JoystickPublisher(Node):
    def __init__(self):
        super().__init__('joystick_publisher')
        
        # Create publisher for /joy topic
        self.joy_pub = self.create_publisher(Joy, '/joy', 10)
        
        # Create timer for publishing
        self.timer = self.create_timer(0.05, self.publish_joystick)
        self.time_elapsed = 0
        
        self.get_logger().info('Joystick Publisher started')
        self.get_logger().info('Publishing to /joy topic')
    
    def publish_joystick(self):
        # Create Joy message
        joy_msg = Joy()
        
        # Simulate joystick movement
        t = self.time_elapsed * 0.1
        
        # Axes: [LX, LY, LZ, RX, RY, RZ]
        # LX, LY: Left stick
        # RX, RY: Right stick
        # LZ, RZ: Triggers
        joy_msg.axes = [
            0.5 * math.sin(t),           # Left stick X
            0.5 * math.cos(t),           # Left stick Y
            0.0,                         # Left trigger
            0.3 * math.sin(t + 1),       # Right stick X
            0.3 * math.cos(t + 1),       # Right stick Y
            0.0                          # Right trigger
        ]
        
        # Buttons: [A, B, X, Y, LB, RB, Back, Start, LS, RS]
        joy_msg.buttons = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
        
        # Publish message
        self.joy_pub.publish(joy_msg)
        
        self.time_elapsed += 1

def main(args=None):
    rclpy.init(args=args)
    node = JoystickPublisher()
    
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
```

### Step 4: Create System Status Publisher

Create file: `rover_telemetry/system_status_publisher.py`

```python
#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from std_msgs.msg import String
import random

class SystemStatusPublisher(Node):
    def __init__(self):
        super().__init__('system_status_publisher')
        
        # Create publisher
        self.status_pub = self.create_publisher(String, '/rover/system/status', 10)
        
        # Create timer for publishing
        self.timer = self.create_timer(1.0, self.publish_status)
        
        self.get_logger().info('System Status Publisher started')
    
    def publish_status(self):
        # Randomly select status
        status_options = ['GOOD', 'GOOD', 'GOOD', 'WARNING', 'CRITICAL']
        status = random.choice(status_options)
        
        # Create message
        status_msg = String()
        status_msg.data = status
        
        # Publish
        self.status_pub.publish(status_msg)
        self.get_logger().info(f'Published status: {status}')

def main(args=None):
    rclpy.init(args=args)
    node = SystemStatusPublisher()
    
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
```

### Step 5: Build and Install Package

```bash
# Navigate to workspace
cd ~/rover_ws

# Build package
colcon build --packages-select rover_telemetry

# Source setup
source install/setup.bash

# Verify build
ros2 pkg list | grep rover_telemetry
```

### Step 6: Run Publishers

```bash
# Terminal 1: Network Health
ros2 run rover_telemetry network_health_publisher

# Terminal 2: Joystick
ros2 run rover_telemetry joystick_publisher

# Terminal 3: System Status
ros2 run rover_telemetry system_status_publisher
```

---

## Configuring the Dashboard

### Step 1: Switch to ROS 2 Mode

1. Open dashboard in browser: `http://localhost:3000`
2. Click ⚙️ (Settings) in top-right
3. Select **"🤖 ROS 2 Mode (Real Rover)"**
4. Configure settings:
   - **Bridge IP**: IP address of bridge machine (e.g., `192.168.1.100`)
   - **Bridge Port**: `9090` (default)
   - **ROS Namespace**: `/rover` (or your namespace)
   - **Auto-connect**: Enable
5. Click **Save**

### Step 2: Verify Connection

Dashboard should show:
- Green indicator: "Controller Connected"
- Values updating from ROS 2 topics
- No yellow "Simulation mode" banner

---

## Testing ROS 2 Integration

### Test 1: Verify Topics are Publishing

```bash
# List all topics
ros2 topic list

# You should see:
# /joy
# /rover/network/latency
# /rover/network/packet_loss
# /rover/network/signal_strength
# /rover/network/tx_throughput
# /rover/network/rx_throughput
# /rover/system/status
```

### Test 2: Monitor Topic Data

```bash
# Monitor latency topic
ros2 topic echo /rover/network/latency

# Monitor joystick topic
ros2 topic echo /joy

# Monitor system status
ros2 topic echo /rover/system/status
```

### Test 3: Dashboard Updates

1. Start all publishers (see Step 6 above)
2. Start bridge: `DATA_SOURCE=ros node ros2-bridge-simulator.mjs`
3. Open dashboard: `http://localhost:3000`
4. Verify values update in real-time
5. Check each stat card updates

### Test 4: End-to-End Flow

```bash
# Terminal 1: Publishers
ros2 run rover_telemetry network_health_publisher

# Terminal 2: Publishers
ros2 run rover_telemetry joystick_publisher

# Terminal 3: Publishers
ros2 run rover_telemetry system_status_publisher

# Terminal 4: Bridge
cd ~/rover_dashboard
DATA_SOURCE=ros node ros2-bridge-simulator.mjs

# Terminal 5: Dashboard
cd ~/rover_dashboard
pnpm dev

# Browser: Open http://localhost:3000
# Watch dashboard update with real ROS 2 data
```

---

## Integrating Real Rover Topics

### Mapping Your Topics

Replace the example publishers with your actual rover topics:

| Dashboard Metric | ROS 2 Topic | Message Type |
|-----------------|-------------|--------------|
| Latency | `/rover/network/latency` | `std_msgs/Float32` |
| Packet Loss | `/rover/network/packet_loss` | `std_msgs/Float32` |
| Signal Strength | `/rover/network/signal_strength` | `std_msgs/Int32` |
| TX Throughput | `/rover/network/tx_throughput` | `std_msgs/Float32` |
| RX Throughput | `/rover/network/rx_throughput` | `std_msgs/Float32` |
| System Status | `/rover/system/status` | `std_msgs/String` |
| Joystick Input | `/joy` | `sensor_msgs/Joy` |

### Update Bridge to Subscribe to Your Topics

Edit `ros2-bridge-simulator.mjs`:

```javascript
// Add your topic subscriptions
const subscriptions = {
  '/your/custom/topic': 'std_msgs/Float32',
  '/another/topic': 'sensor_msgs/Joy'
};

// Bridge will automatically subscribe and forward data
```

---

## Troubleshooting

### Bridge Not Connecting to ROS 2

**Problem:** Bridge shows "Listening for ROS 2 topics..." but no data arrives.

**Solution:**
1. Verify ROS 2 is running:
   ```bash
   ros2 topic list
   ```

2. Check ROS 2 environment:
   ```bash
   echo $ROS_DOMAIN_ID
   echo $ROS_LOCALHOST_ONLY
   ```

3. Ensure publishers are running:
   ```bash
   ros2 topic list | grep rover
   ```

### Dashboard Not Updating

**Problem:** Dashboard shows "Disconnected" or old values.

**Solution:**
1. Check bridge is running:
   ```bash
   curl http://<bridge-ip>:9090/health
   ```

2. Verify dashboard is in ROS 2 mode (Settings)

3. Check browser console (F12) for WebSocket errors

4. Restart bridge and dashboard

### Topics Not Found

**Problem:** `[ERROR] Topic /rover/network/latency not found`

**Solution:**
1. Verify topic exists:
   ```bash
   ros2 topic list | grep network
   ```

2. Check topic message type:
   ```bash
   ros2 topic info /rover/network/latency
   ```

3. Verify publishers are running

### Network Communication Issues

**Problem:** Bridge on different machine can't reach rover.

**Solution:**
1. Check network connectivity:
   ```bash
   ping <rover-ip>
   ```

2. Verify ROS 2 domain:
   ```bash
   export ROS_DOMAIN_ID=0
   ```

3. Check firewall:
   ```bash
   sudo ufw allow 9090
   ```

---

## Performance Optimization

### Reduce Network Traffic

```bash
# Increase topic publish rate (reduce frequency)
# In publisher: self.create_timer(0.5, ...)  # 2 Hz instead of 10 Hz
```

### Monitor Bridge Performance

```bash
# Check bridge resource usage
top -p $(pgrep -f "node ros2-bridge")

# Check network traffic
nethogs
```

### Expected Performance

- **Latency**: <100ms end-to-end
- **CPU**: <5% per process
- **Memory**: ~100MB bridge + 50MB per publisher
- **Network**: <1 Mbps for typical telemetry

---

## Next Steps

1. **Add More Sensors**: Extend publishers to include battery, temperature, GPS, etc.
2. **Implement Motor Control**: Create subscriber node for motor commands from dashboard
3. **Add Autonomous Navigation**: Integrate Nav2 for goal-based navigation
4. **Real Hardware Testing**: Connect to actual rover and test end-to-end

---

## Quick Reference

| Task | Command |
|------|---------|
| Install ROS 2 | `sudo apt install ros-humble-desktop` |
| Source ROS 2 | `source /opt/ros/humble/setup.bash` |
| Create Package | `ros2 pkg create rover_telemetry --build-type ament_python` |
| Build Package | `colcon build --packages-select rover_telemetry` |
| Run Publisher | `ros2 run rover_telemetry network_health_publisher` |
| List Topics | `ros2 topic list` |
| Monitor Topic | `ros2 topic echo /rover/network/latency` |
| Start Bridge (ROS) | `DATA_SOURCE=ros node ros2-bridge-simulator.mjs` |
| Start Dashboard | `pnpm dev` |

---

**Happy ROS 2 integration! 🚀**
