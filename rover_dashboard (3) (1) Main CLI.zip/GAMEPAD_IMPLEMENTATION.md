# Gamepad Overlay Implementation Guide

## Overview

The Rover Dashboard now includes a **realistic gamepad controller overlay** that mirrors actual physical joystick input from ROS 2 in real-time. The dashboard provides three visualization modes:

1. **Radar View** - Concentric circles with joystick position indicator
2. **Gamepad View** - Full Xbox/PlayStation-style controller visualization (NEW)
3. **Analog View** - Detailed analog stick and button readout

---

## Architecture

### Data Flow

```
Physical USB Joystick
    ↓
ROS 2 joy_node (/dev/input/js0)
    ↓
/joy topic (sensor_msgs/msg/Joy)
    ↓
ros2-bridge-enhanced.mjs (WebSocket server)
    ↓
parseJoyMessage() - Extract axes & buttons
    ↓
WebSocket broadcast to frontend
    ↓
useROS2Connection hook (React)
    ↓
GamepadOverlay component (Canvas rendering)
    ↓
Real-time visualization on dashboard
```

### Component Structure

```
Home.tsx
├── useROS2Connection() hook
│   ├── Subscribes to /joy topic via WebSocket
│   ├── Maintains joystickAxes[] and joystickButtons[]
│   └── Updates every 50-100ms
├── View Mode Toggle (Radar / Gamepad / Analog)
└── GamepadOverlay component
    ├── Canvas-based rendering
    ├── Draws controller body, sticks, buttons
    └── Updates in real-time as data changes
```

---

## Component: GamepadOverlay.tsx

### Props

```typescript
interface GamepadOverlayProps {
  axes: number[];      // Joystick axis values (0-6)
  buttons: number[];   // Button states (0-10)
  isConnected?: boolean; // Connection status
}
```

### Axis Mapping (Standard Xbox/Joy)

| Index | Function | Range | Notes |
|-------|----------|-------|-------|
| 0 | Left Stick X | -1 to 1 | Left (-1) to Right (1) |
| 1 | Left Stick Y | -1 to 1 | Up (-1) to Down (1) |
| 2 | LT Trigger | -1 to 1 | Released (-1) to Pressed (1) |
| 3 | Right Stick X | -1 to 1 | Left (-1) to Right (1) |
| 4 | Right Stick Y | -1 to 1 | Up (-1) to Down (1) |
| 5 | RT Trigger | -1 to 1 | Released (-1) to Pressed (1) |

### Button Mapping (Standard Xbox Layout)

| Index | Button | Color | Notes |
|-------|--------|-------|-------|
| 0 | A | Green | Bottom button |
| 1 | B | Red | Right button |
| 2 | X | Blue | Left button |
| 3 | Y | Yellow | Top button |
| 4 | LB | Cyan | Left bumper |
| 5 | RB | Cyan | Right bumper |
| 6 | Back | Cyan | Left center button |
| 7 | Start | Cyan | Right center button |
| 8 | LS Click | Cyan | Left stick click |
| 9 | RS Click | Cyan | Right stick click |

### Visual Features

- **Animated Sticks**: Smooth movement with cyan glow effect
- **Responsive Buttons**: Color-coded face buttons that light up when pressed
- **Trigger Bars**: Visual fill bars for LT/RT analog triggers
- **Bumper Indicators**: LB/RB buttons with press feedback
- **Connection Status**: Green/red indicator showing ROS 2 connection
- **Real-time Values**: Display of all axis and button states

---

## ROS 2 Integration

### Bridge Configuration

The `ros2-bridge-enhanced.mjs` automatically subscribes to `/joy` topic:

```javascript
const TOPICS = {
  networkHealth: `${NAMESPACE}/network_health`,
  joystickInput: `/joy`,  // Standard ROS 2 joy topic
  systemStatus: `${NAMESPACE}/system_status`,
};
```

### Joy Message Parsing

```javascript
function parseJoyMessage(message) {
  return {
    joystickX: axes[0] ?? 0,      // Left stick X
    joystickY: axes[1] ?? 0,      // Left stick Y
    joystickAxes: axes,           // All 6 axes
    joystickButtons: buttons.map(b => (b > 0 ? 1 : 0)), // Normalize to 0/1
  };
}
```

### WebSocket Message Format

The bridge sends real-time updates via WebSocket:

```json
{
  "joystickX": 0.25,
  "joystickY": -0.45,
  "joystickAxes": [0.25, -0.45, -1.0, 0.0, 0.0, -1.0],
  "joystickButtons": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
  "latency": 45.2,
  "packetLoss": 0.05,
  "signalStrength": -75,
  "systemStatus": "GOOD"
}
```

---

## Frontend Integration

### useROS2Connection Hook

The hook automatically handles ROS 2 connection and data updates:

```typescript
const { data, connectionState } = useROS2Connection({
  bridgeUrl: "ws://localhost:9090",
  useSimulation: true,
});

// Access joystick data
console.log(data.joystickAxes);   // [0.25, -0.45, -1.0, ...]
console.log(data.joystickButtons); // [0, 0, 0, 1, ...]
```

### Rendering Gamepad View

```typescript
{viewMode === "gamepad" && (
  <GamepadOverlay
    axes={data.joystickAxes}
    buttons={data.joystickButtons}
    isConnected={connectionState === "connected"}
  />
)}
```

---

## Setup & Testing

### Prerequisites

```bash
# Install ROS 2 joy package
sudo apt install -y ros-humble-joy

# Connect USB joystick
# Should appear as /dev/input/js0
ls /dev/input/js*
```

### Start ROS 2 Joy Node

```bash
# Terminal 1: Start joy node
ros2 run joy joy_node --ros-args -p dev:="/dev/input/js0"

# Verify joy topic is publishing
ros2 topic hz /joy
# Should show ~50 Hz
```

### Start Dashboard

```bash
# Terminal 2: Start ROS 2 bridge
cd ~/rover_dashboard
node ros2-bridge-enhanced.mjs --port 9090

# Terminal 3: Start dashboard dev server
pnpm dev

# Open http://localhost:3000
```

### Test Gamepad View

1. Open dashboard in browser
2. Click **"Gamepad View"** button
3. Move physical joystick
4. Observe real-time updates in gamepad overlay:
   - Left stick moves with joystick input
   - Button colors change when pressed
   - Trigger bars fill when pressed
   - Connection status shows green

---

## Customization

### Change Controller Layout

Edit `GamepadOverlay.tsx` to customize button positions, colors, or stick size:

```typescript
// Example: Change left stick position
const stickX = width * 0.25;  // 25% from left
const stickY = height * 0.65; // 65% from top
const stickRadius = 25;       // Radius in pixels
```

### Adjust Axis Mapping

If your joystick uses different axis indices, update the mapping in `Home.tsx`:

```typescript
// Example: Swap Y axes if inverted
const joystickY = -data.joystickAxes[1];  // Invert Y axis
```

### Add Custom Buttons

Extend the button rendering in `GamepadOverlay.tsx`:

```typescript
// Add new button visualization
function drawCustomButton(ctx, x, y, isPressed, label) {
  // Your custom drawing code
}
```

---

## Troubleshooting

### Gamepad View Not Updating

**Problem**: Gamepad overlay shows static values

**Solution**:
1. Check ROS 2 joy node is running: `ros2 node list | grep joy`
2. Verify joy topic is publishing: `ros2 topic echo /joy`
3. Check bridge logs for errors: `node ros2-bridge-enhanced.mjs`
4. Ensure WebSocket connection: Check browser console for connection errors

### Axes Values Incorrect

**Problem**: Joystick moves but values are wrong

**Solution**:
1. Test joystick directly: `jstest /dev/input/js0`
2. Check axis mapping in bridge: `parseJoyMessage()` function
3. Verify axis indices match your joystick: `ros2 topic echo /joy`
4. Adjust axis mapping in `Home.tsx` if needed

### Buttons Not Responding

**Problem**: Buttons don't light up when pressed

**Solution**:
1. Check button indices: `ros2 topic echo /joy` and press buttons
2. Verify button normalization in bridge: `buttons.map(b => (b > 0 ? 1 : 0))`
3. Check button rendering in `GamepadOverlay.tsx`
4. Ensure buttons array has 10 elements

### Performance Issues

**Problem**: Gamepad updates are laggy

**Solution**:
1. Reduce joy node frequency: `ros2 run joy joy_node -p autorepeat_rate:=20`
2. Check WebSocket latency: Monitor bridge logs
3. Reduce canvas resolution: Edit `GamepadOverlay.tsx` canvas width/height
4. Close other browser tabs to free resources

---

## Performance Metrics

- **Update Frequency**: 50-100 Hz (20-10ms per update)
- **Canvas Rendering**: ~2-5ms per frame
- **WebSocket Latency**: <50ms typical
- **Total Latency**: 30-100ms end-to-end

---

## Advanced: Custom Joystick Mapping

### Example: Arcade Drive Instead of Tank Drive

If you want to use the gamepad for arcade drive control (forward + turn):

```typescript
// In motor_controller_node.py
def arcade_drive(self, forward: float, turn: float) -> tuple:
    left_speed = forward + turn
    right_speed = forward - turn
    
    # Normalize
    max_speed = max(abs(left_speed), abs(right_speed))
    if max_speed > 1.0:
        left_speed /= max_speed
        right_speed /= max_speed
    
    return left_speed, right_speed
```

### Example: Custom Button Actions

Add custom button handling in `Home.tsx`:

```typescript
// Monitor button presses
useEffect(() => {
  if (data.joystickButtons[0]) {
    console.log("A button pressed - do something");
  }
  if (data.joystickButtons[4]) {
    console.log("LB button pressed - fine control");
  }
}, [data.joystickButtons]);
```

---

## Resources

- [ROS 2 Joy Package](https://index.ros.org/p/joy/)
- [sensor_msgs/Joy Message](https://docs.ros2.org/latest/api/sensor_msgs/msg/Joy.html)
- [Joystick Testing Tools](https://wiki.archlinux.org/title/Gamepad)
- [Canvas API Reference](https://developer.mozilla.org/en-US/docs/Web/API/Canvas_API)

---

## Next Steps

1. **Motor Integration** - Connect gamepad input to actual rover motors
2. **Feedback Display** - Show motor encoder feedback on dashboard
3. **Recording** - Log all joystick inputs for playback/analysis
4. **Autonomous Mode** - Add goal-based navigation alongside manual control

---

**Happy controlling! 🎮**
