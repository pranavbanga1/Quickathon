# 🎮 USB Joystick Quick Start Guide

Get your rover controlled by a real USB joystick in **5 minutes**.

## Prerequisites

- USB joystick/gamepad connected to rover system
- ROS 2 Humble installed
- Rover Dashboard running

## Quick Setup

### Step 1: Install Joy Package (1 minute)

```bash
# On rover system
sudo apt update
sudo apt install -y ros-humble-joy joystick
```

### Step 2: Verify Joystick Connection (1 minute)

```bash
# Check if joystick is detected
ls /dev/input/js*

# Should show: /dev/input/js0

# Test joystick input
jstest /dev/input/js0
# Move sticks and press buttons - should see values change
```

### Step 3: Start All Nodes (1 minute)

```bash
# Terminal 1: Start joystick + motor controller + telemetry
cd ~/rover_ws
source install/setup.bash
ros2 launch rover_telemetry launch_joystick.py device:=/dev/input/js0
```

### Step 4: Start Bridge & Dashboard (2 minutes)

```bash
# Terminal 2: Start ROS 2 bridge
cd ~/rover_dashboard
node ros2-bridge-enhanced.mjs --port 9090

# Terminal 3: Start dashboard
pnpm dev

# Open http://localhost:3000
```

### Step 5: Control Rover! 🎮

- **Left Stick Y**: Forward/Backward
- **Right Stick X**: Turn Left/Right
- **LB Button**: Fine Control (slower)
- **A Button**: Emergency Stop
- **B Button**: Reset

---

## What's Happening

```
USB Joystick
    ↓
ros2 joy_node (reads /dev/input/js0)
    ↓
/joy topic (sensor_msgs/Joy)
    ↓
motor_controller_node (converts to motor commands)
    ↓
/rover/motor_commands topic
    ↓
[Connect to your actual motor drivers here]
```

---

## Verify Everything Works

### Check Topics

```bash
# In new terminal
ros2 topic list

# Should show:
# /joy
# /rover/motor_commands
# /rover/network_health
# /rover/system_status
```

### Monitor Motor Commands

```bash
# Watch motor commands in real-time
ros2 topic echo /rover/motor_commands

# Move joystick - should see values change:
# data: [0.5, 0.5]   # Forward
# data: [0.0, 1.0]   # Turn right
# data: [-0.5, 0.5]  # Reverse turn
```

### Check Dashboard

- Open http://localhost:3000
- Switch to "Controller View"
- Move joystick - should see visualization update in real-time
- Check that latency/packet loss are updating

---

## Connect to Real Motors

The motor commands are published to `/rover/motor_commands` as `Float32MultiArray`:
- `data[0]`: Left motor speed (-1.0 to 1.0)
- `data[1]`: Right motor speed (-1.0 to 1.0)

### Connect to Your Motor Driver

Edit or create a motor driver node that subscribes to `/rover/motor_commands`:

```python
# Example: Subscribe to motor commands and send to motor driver
import rclpy
from std_msgs.msg import Float32MultiArray

class MotorDriver(Node):
    def __init__(self):
        super().__init__('motor_driver')
        self.sub = self.create_subscription(
            Float32MultiArray,
            '/rover/motor_commands',
            self.motor_callback,
            10
        )
    
    def motor_callback(self, msg):
        left_speed = msg.data[0]
        right_speed = msg.data[1]
        
        # Send to your motor driver
        # self.can_bus.send(left_speed, right_speed)
        # self.serial_port.write(f"L{left_speed},R{right_speed}\n")
        # self.gpio.set_pwm(left_speed, right_speed)
```

---

## Troubleshooting

### Joystick not detected

```bash
# Check USB connection
lsusb | grep -i joy

# Check device permissions
ls -l /dev/input/js0
# Should be readable by your user

# If not, add to input group
sudo usermod -a -G input $USER
newgrp input
```

### Joy node not publishing

```bash
# Check if joy node is running
ros2 node list | grep joy

# If not, check error
ros2 run joy joy_node --ros-args -p dev:="/dev/input/js0" 2>&1 | head -20
```

### Motor commands not updating

```bash
# Check motor controller is running
ros2 node list | grep motor

# Check joy topic is publishing
ros2 topic hz /joy
# Should show ~50 Hz

# Check motor commands topic
ros2 topic echo /rover/motor_commands
# Should update when you move joystick
```

### Dashboard not showing joystick input

```bash
# Check bridge is running
ps aux | grep ros2-bridge

# Check bridge logs
# Look for "ROS 2 found" message

# Verify joystick topic in bridge
# Edit ros2-bridge-enhanced.mjs and check TOPICS
```

---

## Advanced: Custom Motor Mapping

If your rover uses different motor control:

### 1. Edit Motor Controller Parameters

```bash
# Change max speed
ros2 launch rover_telemetry launch_joystick.py max_speed:=0.7

# Change deadzone
ros2 launch rover_telemetry launch_joystick.py deadzone:=0.15
```

### 2. Modify Tank Drive Algorithm

Edit `motor_controller_node.py` `tank_drive()` function:

```python
def tank_drive(self, forward: float, turn: float) -> tuple:
    # Example: Arcade drive instead of tank drive
    left_speed = forward + turn
    right_speed = forward - turn
    
    # Normalize
    max_speed = max(abs(left_speed), abs(right_speed))
    if max_speed > 1.0:
        left_speed /= max_speed
        right_speed /= max_speed
    
    return left_speed, right_speed
```

### 3. Add Custom Buttons

Edit `motor_controller_node.py` `joy_callback()`:

```python
# Button 5: RB - Boost speed
if len(msg.buttons) > 5 and msg.buttons[5]:
    self.max_speed = 1.5  # Boost

# Button 6: Back - Slow mode
if len(msg.buttons) > 6 and msg.buttons[6]:
    self.max_speed = 0.3  # Slow
```

---

## Performance Tips

1. **Reduce Joy Node Frequency** if CPU is high
   ```bash
   ros2 launch rover_telemetry launch_joystick.py device:=/dev/input/js0 \
     -p autorepeat_rate:=20
   ```

2. **Increase Deadzone** if joystick drifts
   ```bash
   ros2 launch rover_telemetry launch_joystick.py deadzone:=0.2
   ```

3. **Use Fine Control** (LB button) for precise movements

---

## Next Steps

1. **Integrate Motor Driver** - Connect motor commands to actual rover motors
2. **Add Feedback** - Subscribe to motor encoders and show speed feedback
3. **Implement Autonomous** - Add autonomous mode alongside manual control
4. **Add Recording** - Log all joystick inputs for replay/analysis

---

## Resources

- [ROS 2 Joy Package](https://index.ros.org/p/joy/)
- [Joystick Testing](https://wiki.archlinux.org/title/Gamepad)
- [Motor Control Examples](https://github.com/ros-drivers/joystick_drivers)

---

**Happy controlling! 🚀**
