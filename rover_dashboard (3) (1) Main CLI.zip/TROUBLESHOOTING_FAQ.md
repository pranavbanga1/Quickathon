# 🔧 Troubleshooting & FAQ

**Comprehensive troubleshooting guide and frequently asked questions for the Rover Dashboard.**

---

## Table of Contents

1. [Common Issues](#common-issues)
2. [Frequently Asked Questions](#frequently-asked-questions)
3. [Debug Checklist](#debug-checklist)
4. [Performance Issues](#performance-issues)
5. [Network Issues](#network-issues)

---

## Common Issues

### Issue 1: Dashboard Not Updating

**Symptoms:**
- Dashboard shows static values
- No real-time updates
- Values don't change when using CLI

**Diagnosis:**

```bash
# Check if bridge is running
curl http://localhost:9090/health

# Expected response:
# {"status":"ok","dataSource":"simulator","timestamp":"..."}

# If error, bridge is not running
```

**Solutions:**

1. **Restart Bridge:**
   ```bash
   # Kill existing bridge
   pkill -f "node ros2-bridge"
   
   # Start bridge again
   node ros2-bridge-simulator.mjs
   ```

2. **Check Dashboard Settings:**
   - Click ⚙️ (Settings)
   - Verify Bridge IP: `localhost` (if local) or `<machine-ip>` (if remote)
   - Verify Bridge Port: `9090`
   - Click Save

3. **Refresh Dashboard:**
   - Press `Ctrl+R` (Windows/Linux) or `Cmd+R` (Mac)
   - Or hard refresh: `Ctrl+Shift+R`

4. **Check Browser Console:**
   - Press `F12` to open Developer Tools
   - Click "Console" tab
   - Look for WebSocket errors
   - Screenshot error and check against solutions below

---

### Issue 2: Port 9090 Already in Use

**Symptoms:**
```
Error: listen EADDRINUSE :::9090
```

**Diagnosis:**

```bash
# Find process using port 9090
lsof -i :9090

# Example output:
# COMMAND   PID USER   FD   TYPE DEVICE SIZE/OFF NODE NAME
# node    12345 user   20u  IPv6   0x123      0t0  TCP *:9090 (LISTEN)
```

**Solutions:**

1. **Kill the Process:**
   ```bash
   # Kill by PID
   kill -9 12345
   
   # Or kill all node processes
   pkill -f "node ros2-bridge"
   ```

2. **Use Different Port:**
   ```bash
   # Edit ros2-bridge-simulator.mjs
   nano ros2-bridge-simulator.mjs
   
   # Find: const PORT = 9090;
   # Change to: const PORT = 9091;
   
   # Update dashboard settings to port 9091
   ```

3. **Wait for Process to Release Port:**
   ```bash
   # Sometimes takes a few seconds
   sleep 5
   node ros2-bridge-simulator.mjs
   ```

---

### Issue 3: CLI Simulator Not Connecting

**Symptoms:**
```
[ERROR] Failed to send data: Connection refused
```

**Diagnosis:**

```bash
# Test bridge connectivity
curl http://localhost:9090/health

# If fails, bridge is not running
# If succeeds, check CLI bridge URL
```

**Solutions:**

1. **Verify Bridge is Running:**
   ```bash
   # Check if bridge process exists
   ps aux | grep "node ros2-bridge"
   
   # If not running, start it
   node ros2-bridge-simulator.mjs
   ```

2. **Check CLI Bridge URL:**
   ```bash
   # If bridge is on different machine
   python3 data_simulator_interactive.py --bridge-url http://<bridge-ip>:9090
   
   # Example:
   python3 data_simulator_interactive.py --bridge-url http://192.168.1.100:9090
   ```

3. **Test Connectivity:**
   ```bash
   # From CLI machine, test bridge
   curl http://localhost:9090/health
   
   # If fails, check firewall
   sudo ufw allow 9090
   ```

---

### Issue 4: Dashboard Shows "Disconnected"

**Symptoms:**
- Red indicator: "Controller Disconnected"
- Dashboard not updating
- Browser console shows WebSocket errors

**Diagnosis:**

```bash
# Check WebSocket connection
# Open browser console (F12 → Console)
# Look for: "WebSocket connection failed"
```

**Solutions:**

1. **Check Bridge IP in Settings:**
   - If dashboard is on same machine: `localhost`
   - If dashboard is on different machine: `<bridge-machine-ip>`
   
   ```bash
   # Get bridge machine IP
   hostname -I
   ```

2. **Verify Firewall:**
   ```bash
   # Allow port 9090
   sudo ufw allow 9090
   
   # Check firewall status
   sudo ufw status
   ```

3. **Check Network Connectivity:**
   ```bash
   # From dashboard machine, ping bridge
   ping <bridge-ip>
   
   # Should see responses
   ```

4. **Restart WebSocket Connection:**
   - Refresh dashboard page
   - Check browser console for new errors

---

### Issue 5: Python Module Not Found

**Symptoms:**
```
ModuleNotFoundError: No module named 'requests'
```

**Solutions:**

```bash
# Install missing module
pip3 install requests

# Verify installation
python3 -c "import requests; print('OK')"

# If still fails, try:
pip install requests
```

---

### Issue 6: Dashboard Freezes or Lags

**Symptoms:**
- Dashboard UI is slow
- Updates are delayed
- Browser becomes unresponsive

**Diagnosis:**

```bash
# Check system resources
top

# Look for high CPU or memory usage
```

**Solutions:**

1. **Reduce Update Frequency:**
   ```bash
   # In CLI, use automatic simulation less frequently
   # Or manually update values instead
   ```

2. **Close Other Applications:**
   - Close unnecessary browser tabs
   - Close other heavy applications
   - Free up system RAM

3. **Restart Services:**
   ```bash
   # Kill all services
   pkill -f "node ros2-bridge"
   pkill -f "pnpm dev"
   pkill -f "python3 data_simulator"
   
   # Wait 5 seconds
   sleep 5
   
   # Restart
   node ros2-bridge-simulator.mjs
   pnpm dev
   python3 data_simulator_interactive.py --bridge-url http://localhost:9090
   ```

4. **Check Browser:**
   - Try different browser (Chrome, Firefox, Safari)
   - Clear browser cache: `Ctrl+Shift+Delete`
   - Disable browser extensions

---

### Issue 7: ROS 2 Topics Not Found

**Symptoms:**
```
[ERROR] Topic /rover/network/latency not found
```

**Diagnosis:**

```bash
# List all available topics
ros2 topic list

# Check if your topic exists
ros2 topic list | grep rover
```

**Solutions:**

1. **Verify Publishers are Running:**
   ```bash
   # Check if publisher processes exist
   ps aux | grep "python3" | grep publisher
   
   # If not running, start them
   ros2 run rover_telemetry network_health_publisher
   ```

2. **Check Topic Message Type:**
   ```bash
   # Get topic info
   ros2 topic info /rover/network/latency
   
   # Should show message type and publisher count
   ```

3. **Verify ROS 2 Environment:**
   ```bash
   # Source ROS 2
   source /opt/ros/humble/setup.bash
   
   # Check ROS 2 is working
   ros2 topic list
   ```

4. **Update Bridge Topic Subscriptions:**
   - Edit `ros2-bridge-simulator.mjs`
   - Add your custom topics
   - Restart bridge

---

### Issue 8: High Latency or Slow Updates

**Symptoms:**
- Dashboard updates are delayed
- Values lag behind actual data
- Network feels slow

**Diagnosis:**

```bash
# Check network latency
ping <bridge-ip>

# Check bridge CPU usage
top -p $(pgrep -f "node ros2-bridge")
```

**Solutions:**

1. **Reduce Update Frequency:**
   ```bash
   # In publishers, increase timer interval
   # From: self.create_timer(0.1, ...)  # 10 Hz
   # To: self.create_timer(0.5, ...)    # 2 Hz
   ```

2. **Optimize Network:**
   - Use wired connection instead of WiFi
   - Reduce network congestion
   - Check for packet loss: `ping -c 100 <bridge-ip>`

3. **Check System Resources:**
   ```bash
   # Monitor system
   watch -n 1 'top -b -n 1 | head -20'
   ```

---

## Frequently Asked Questions

### Q1: Can I run dashboard on a different machine than the bridge?

**A:** Yes! The bridge and dashboard can be on different machines:

```bash
# Machine 1 (Bridge)
node ros2-bridge-simulator.mjs

# Machine 2 (Dashboard)
# In Settings, set Bridge IP to Machine 1's IP
# Example: 192.168.1.100:9090
```

---

### Q2: Can I use both CLI simulator and ROS 2 at the same time?

**A:** No, you need to choose one mode:

- **Simulator Mode**: Uses Python CLI to send data
- **ROS 2 Mode**: Subscribes to real ROS 2 topics

Switch in Settings modal.

---

### Q3: How do I add custom metrics to the dashboard?

**A:** Follow these steps:

1. **Add UI Component:**
   - Edit `client/src/pages/Home.tsx`
   - Add new StatCard for your metric

2. **Add ROS 2 Topic:**
   - Create publisher node
   - Publish to `/rover/custom/metric`

3. **Update Bridge:**
   - Edit `ros2-bridge-simulator.mjs`
   - Subscribe to new topic
   - Forward data to dashboard

---

### Q4: What's the maximum update frequency?

**A:** The dashboard can handle updates up to 100 Hz (10ms intervals):

```bash
# In publishers
self.create_timer(0.01, publish_data)  # 100 Hz
```

Higher frequencies may cause performance issues.

---

### Q5: Can I record and playback data?

**A:** Currently, the dashboard doesn't have built-in recording. You can:

1. **Use ROS 2 Bag:**
   ```bash
   ros2 bag record -a  # Record all topics
   ros2 bag play <bag-file>  # Playback
   ```

2. **Use CLI Script:**
   ```bash
   # Create script with commands
   cat > demo.txt << EOF
   latency 50
   loss 0.1
   status GOOD
   joystick 0.5 0.3
   EOF
   
   # Run script
   python3 data_simulator_interactive.py < demo.txt
   ```

---

### Q6: How do I connect a real USB joystick?

**A:** The CLI simulator auto-detects USB joysticks:

```bash
# Connect USB joystick to computer
# Run CLI simulator
python3 data_simulator_interactive.py --bridge-url http://localhost:9090

# Joystick input will automatically update the dashboard
```

---

### Q7: Can I customize the dashboard colors/layout?

**A:** Yes, edit the CSS and React components:

```bash
# Edit global styles
nano client/src/index.css

# Edit dashboard layout
nano client/src/pages/Home.tsx

# Edit components
nano client/src/components/StatCard.tsx
```

---

### Q8: What's the network bandwidth requirement?

**A:** Very low:

- **Simulator Mode**: ~10 KB/s
- **ROS 2 Mode**: ~50 KB/s
- **Total**: <1 Mbps

Suitable for WiFi and cellular networks.

---

### Q9: Can I deploy the dashboard online?

**A:** Yes, but with limitations:

- **Frontend**: Can be deployed to Netlify, Vercel, GitHub Pages
- **Bridge**: Must run locally (needs ROS 2 or simulator)
- **Solution**: Deploy frontend to cloud, bridge on rover network

---

### Q10: How do I debug WebSocket connection issues?

**A:** Use browser developer tools:

```javascript
// Open browser console (F12 → Console)
// Paste this code:

const ws = new WebSocket('ws://localhost:9090');
ws.onopen = () => console.log('Connected');
ws.onerror = (e) => console.log('Error:', e);
ws.onmessage = (e) => console.log('Data:', e.data);
```

---

## Debug Checklist

Use this checklist when troubleshooting:

- [ ] Bridge is running: `curl http://localhost:9090/health`
- [ ] Dashboard is running: `http://localhost:3000` loads
- [ ] CLI is running: Can type commands
- [ ] No port conflicts: `lsof -i :9090`
- [ ] Firewall allows port 9090: `sudo ufw allow 9090`
- [ ] Network connectivity: `ping <bridge-ip>`
- [ ] Browser console has no errors: `F12 → Console`
- [ ] Dashboard is in correct mode: Settings → Data Source
- [ ] Bridge IP is correct: Settings → Bridge IP
- [ ] Publishers are running (ROS mode): `ros2 topic list`
- [ ] System resources are available: `top`
- [ ] No other services on port 9090: `lsof -i :9090`

---

## Performance Issues

### Slow Dashboard Updates

**Check:**
1. Network latency: `ping <bridge-ip>`
2. Bridge CPU: `top -p $(pgrep -f "node")`
3. Dashboard CPU: Open DevTools → Performance tab
4. System RAM: `free -h`

**Optimize:**
1. Reduce update frequency
2. Close unnecessary applications
3. Use wired network connection
4. Restart all services

---

### High Memory Usage

**Check:**
```bash
# Monitor memory
watch -n 1 'free -h'

# Check process memory
ps aux | grep -E "(node|python3|pnpm)"
```

**Optimize:**
1. Close browser tabs
2. Restart bridge and dashboard
3. Reduce number of publishers
4. Clear browser cache

---

## Network Issues

### Dashboard on Different Machine

**Setup:**
1. Note bridge machine IP: `hostname -I`
2. On dashboard machine, Settings → Bridge IP: `<bridge-ip>`
3. Ensure firewall allows port 9090

**Test:**
```bash
# From dashboard machine
ping <bridge-ip>
curl http://<bridge-ip>:9090/health
```

### WiFi Connection Issues

**Solutions:**
1. Use 5GHz WiFi instead of 2.4GHz
2. Reduce distance to router
3. Check for interference: `iwconfig`
4. Use wired connection if possible

---

## Getting Help

If you're still stuck:

1. **Check Logs:**
   ```bash
   # Bridge logs
   tail -f bridge.log
   
   # Browser console
   F12 → Console tab
   ```

2. **Reproduce Issue:**
   - Write down exact steps
   - Note error messages
   - Take screenshots

3. **Provide Information:**
   - OS and version
   - ROS 2 version (if applicable)
   - Browser and version
   - Full error messages

---

**Happy debugging! 🔧**
