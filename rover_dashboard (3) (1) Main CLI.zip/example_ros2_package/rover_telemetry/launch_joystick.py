#!/usr/bin/env python3

"""
Launch file for joystick-based rover control

Starts all necessary nodes for USB joystick control:
1. Joy node (reads USB joystick)
2. Motor controller (converts joy to motor commands)
3. Network health publisher
4. System status publisher

Usage:
    ros2 launch rover_telemetry launch_joystick.py device:=/dev/input/js0
"""

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node

def generate_launch_description():
    # Declare arguments
    device_arg = DeclareLaunchArgument(
        'device',
        default_value='/dev/input/js0',
        description='USB joystick device path'
    )
    
    deadzone_arg = DeclareLaunchArgument(
        'deadzone',
        default_value='0.1',
        description='Joystick deadzone (0.0-1.0)'
    )
    
    max_speed_arg = DeclareLaunchArgument(
        'max_speed',
        default_value='1.0',
        description='Maximum motor speed (0.0-1.0)'
    )
    
    # Joy node (reads USB joystick)
    joy_node = Node(
        package='joy',
        executable='joy_node',
        parameters=[
            {'dev': LaunchConfiguration('device')},
            {'deadzone': LaunchConfiguration('deadzone')},
            {'autorepeat_rate': 50},
        ],
        output='screen',
    )
    
    # Motor controller (converts joy to motor commands)
    motor_controller_node = Node(
        package='rover_telemetry',
        executable='motor_controller',
        parameters=[
            {'joy_topic': '/joy'},
            {'motor_topic': '/rover/motor_commands'},
            {'max_speed': LaunchConfiguration('max_speed')},
            {'turn_speed': 0.8},
            {'deadzone': LaunchConfiguration('deadzone')},
            {'fine_control_factor': 0.5},
        ],
        output='screen',
    )
    
    # Network health publisher
    network_health_node = Node(
        package='rover_telemetry',
        executable='network_health_pub',
        output='screen',
    )
    
    # System status publisher
    system_status_node = Node(
        package='rover_telemetry',
        executable='system_status_pub',
        output='screen',
    )
    
    return LaunchDescription([
        device_arg,
        deadzone_arg,
        max_speed_arg,
        joy_node,
        motor_controller_node,
        network_health_node,
        system_status_node,
    ])
