#!/usr/bin/env python3

"""
Custom Joystick Reader Node

Reads raw joystick input from USB device and publishes as sensor_msgs/Joy.
Provides more control than the standard ROS 2 joy package.

Features:
- Direct USB joystick reading
- Configurable dead zones
- Axis inversion
- Button mapping
- Calibration support

Usage:
    ros2 run rover_telemetry joystick_reader_node --ros-args -p device:="/dev/input/js0"
"""

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Joy
import struct
import os
import math

class JoystickReaderNode(Node):
    """Read USB joystick input and publish as ROS 2 Joy messages"""
    
    # Joystick event structure
    EVENT_SIZE = struct.calcsize('4i2h')
    
    # Event types
    JS_EVENT_BUTTON = 0x01
    JS_EVENT_AXIS = 0x02
    JS_EVENT_INIT = 0x80
    
    def __init__(self):
        super().__init__('joystick_reader_node')
        
        # Declare parameters
        self.declare_parameter('device', '/dev/input/js0')
        self.declare_parameter('deadzone', 0.1)
        self.declare_parameter('autorepeat_rate', 50)
        self.declare_parameter('topic', '/joy')
        
        # Get parameters
        self.device = self.get_parameter('device').value
        self.deadzone = self.get_parameter('deadzone').value
        self.autorepeat_rate = self.get_parameter('autorepeat_rate').value
        topic_name = self.get_parameter('topic').value
        
        # Create publisher
        self.publisher = self.create_publisher(Joy, topic_name, 10)
        
        # Initialize joystick state
        self.axes = []
        self.buttons = []
        self.num_axes = 0
        self.num_buttons = 0
        
        # Open joystick device
        try:
            self.js_fd = os.open(self.device, os.O_RDONLY | os.O_NONBLOCK)
            self.get_logger().info(f'Opened joystick device: {self.device}')
        except OSError as e:
            self.get_logger().error(f'Failed to open joystick device: {e}')
            raise
        
        # Create timer for reading
        self.timer = self.create_timer(1.0 / self.autorepeat_rate, self.read_joystick)
        
        self.get_logger().info(f'Joystick Reader started (deadzone={self.deadzone})')
    
    def read_joystick(self):
        """Read joystick events and publish Joy message"""
        try:
            # Read all available events
            while True:
                event_data = os.read(self.js_fd, self.EVENT_SIZE)
                if not event_data:
                    break
                
                # Parse event
                time, value, event_type, number = struct.unpack('4i2h', event_data)
                
                # Initialize state on first read
                if event_type & self.JS_EVENT_INIT:
                    if event_type & self.JS_EVENT_BUTTON:
                        self.num_buttons = number + 1
                        self.buttons = [0] * self.num_buttons
                    elif event_type & self.JS_EVENT_AXIS:
                        self.num_axes = number + 1
                        self.axes = [0.0] * self.num_axes
                    continue
                
                # Handle button events
                if event_type & self.JS_EVENT_BUTTON:
                    if number < len(self.buttons):
                        self.buttons[number] = 1 if value else 0
                
                # Handle axis events
                elif event_type & self.JS_EVENT_AXIS:
                    if number < len(self.axes):
                        # Normalize to -1.0 to 1.0
                        normalized = value / 32767.0
                        
                        # Apply deadzone
                        if abs(normalized) < self.deadzone:
                            normalized = 0.0
                        
                        self.axes[number] = normalized
        
        except BlockingIOError:
            # No more events to read
            pass
        except Exception as e:
            self.get_logger().error(f'Error reading joystick: {e}')
            return
        
        # Publish Joy message
        self.publish_joy()
    
    def publish_joy(self):
        """Publish current joystick state as Joy message"""
        msg = Joy()
        msg.axes = self.axes.copy()
        msg.buttons = self.buttons.copy()
        
        self.publisher.publish(msg)
    
    def destroy_node(self):
        """Clean up resources"""
        try:
            os.close(self.js_fd)
        except:
            pass
        super().destroy_node()

def main(args=None):
    rclpy.init(args=args)
    node = JoystickReaderNode()
    
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info('Shutting down...')
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
