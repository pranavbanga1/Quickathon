#!/usr/bin/env python3

"""
Network Health Publisher Node

Publishes network metrics as Float32MultiArray messages.
Simulates realistic network conditions.

Message format:
    [latency_ms, packet_loss_pct, signal_strength_dbm, tx_mbps, rx_mbps]

Usage:
    ros2 run rover_telemetry network_health_pub
"""

import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32MultiArray
import random

class NetworkHealthPublisher(Node):
    def __init__(self):
        super().__init__('network_health_publisher')
        
        # Create publisher
        self.publisher = self.create_publisher(
            Float32MultiArray,
            '/rover/network_health',
            10  # QoS history depth
        )
        
        # Create timer to publish every 1 second
        self.timer = self.create_timer(1.0, self.publish_data)
        
        # Network state for more realistic simulation
        self.latency_trend = 40.0
        self.packet_loss_trend = 0.05
        self.signal_strength_trend = -70.0
        
        self.get_logger().info('Network Health Publisher started')
        self.get_logger().info('Publishing to: /rover/network_health')
    
    def publish_data(self):
        """Publish simulated network health data"""
        msg = Float32MultiArray()
        
        # Simulate network metrics with trends (more realistic than pure random)
        # Latency: 30-50ms with occasional spikes
        self.latency_trend = max(30, min(80, self.latency_trend + (random.random() - 0.5) * 5))
        latency_ms = self.latency_trend + (random.random() * 10 if random.random() > 0.8 else 0)
        
        # Packet loss: 0-0.2% with occasional bursts
        self.packet_loss_trend = max(0, min(0.3, self.packet_loss_trend + (random.random() - 0.5) * 0.05))
        packet_loss_pct = max(0, self.packet_loss_trend + (random.random() * 0.1 if random.random() > 0.9 else 0))
        
        # Signal strength: -80 to -60 dBm
        self.signal_strength_trend = max(-85, min(-55, self.signal_strength_trend + (random.random() - 0.5) * 2))
        signal_strength_dbm = self.signal_strength_trend
        
        # TX throughput: 30-70 Mbps
        tx_mbps = 30 + random.random() * 40
        
        # RX throughput: 40-90 Mbps
        rx_mbps = 40 + random.random() * 50
        
        # Pack into Float32MultiArray
        msg.data = [
            float(latency_ms),
            float(packet_loss_pct),
            float(signal_strength_dbm),
            float(tx_mbps),
            float(rx_mbps),
        ]
        
        self.publisher.publish(msg)
        self.get_logger().debug(
            f'Published: latency={latency_ms:.1f}ms, '
            f'loss={packet_loss_pct:.2f}%, '
            f'signal={signal_strength_dbm:.0f}dBm, '
            f'tx={tx_mbps:.1f}Mbps, '
            f'rx={rx_mbps:.1f}Mbps'
        )

def main(args=None):
    rclpy.init(args=args)
    node = NetworkHealthPublisher()
    
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info('Shutting down...')
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
