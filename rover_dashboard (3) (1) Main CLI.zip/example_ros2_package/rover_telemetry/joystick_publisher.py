#!/usr/bin/env python3

"""
Joystick Input Publisher Node

Publishes sensor_msgs/Joy messages representing joystick input.
Can be extended to read from actual USB joystick devices.

Usage:
    ros2 run rover_telemetry joystick_pub
"""

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Joy
import random
import math

class JoystickPublisher(Node):
    def __init__(self):
        super().__init__('joystick_publisher')
        
        # Create publisher for sensor_msgs/Joy
        self.publisher = self.create_publisher(
            Joy,
            '/rover/joystick_input',
            10  # QoS history depth
        )
        
        # Create timer to publish at 10 Hz (100ms)
        self.timer = self.create_timer(0.1, self.publish_data)
        
        # Simulation state
        self.angle = 0.0
        self.button_press_counter = 0
        
        self.get_logger().info('Joystick Publisher started')
        self.get_logger().info('Publishing to: /rover/joystick_input')
    
    def publish_data(self):
        """Publish joystick input data"""
        msg = Joy()
        
        # Simulate circular joystick motion (for testing)
        self.angle += 0.1
        radius = 0.7
        
        # Left stick (axes 0-1): circular motion
        msg.axes = [
            radius * math.cos(self.angle),           # X: -1.0 to 1.0
            radius * math.sin(self.angle),           # Y: -1.0 to 1.0
            0.0,                                      # Z (unused)
            0.0,                                      # Throttle (unused)
            (random.random() - 0.5) * 2,             # Right stick X
            (random.random() - 0.5) * 2,             # Right stick Y
        ]
        
        # Simulate button presses (mostly unpressed, occasional presses)
        self.button_press_counter += 1
        msg.buttons = [
            1 if self.button_press_counter % 50 == 0 else 0,  # A button
            1 if self.button_press_counter % 70 == 0 else 0,  # B button
            1 if self.button_press_counter % 100 == 0 else 0, # X button
            1 if self.button_press_counter % 120 == 0 else 0, # Y button
            0,  # LB
            0,  # RB
            0,  # Back
            0,  # Start
        ]
        
        self.publisher.publish(msg)
        self.get_logger().debug(
            f'Published Joy: X={msg.axes[0]:.2f}, Y={msg.axes[1]:.2f}, '
            f'Buttons={sum(msg.buttons)}'
        )

def main(args=None):
    rclpy.init(args=args)
    node = JoystickPublisher()
    
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info('Shutting down...')
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
