#!/usr/bin/env python3

"""
Motor Controller Node

Subscribes to joystick input and converts it to rover motor commands.
Implements tank-drive (differential drive) control.

Joystick Mapping:
- Left Stick Y: Forward/Backward speed
- Right Stick X: Turn left/right
- LB/RB: Fine control (slower speed)
- A: Emergency stop
- B: Reset

Motor Output:
- Publishes to /rover/motor_commands with left/right motor speeds

Usage:
    ros2 run rover_telemetry motor_controller
"""

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Joy
from std_msgs.msg import Float32MultiArray, String
import math

class MotorCommand:
    """Simple motor command structure"""
    def __init__(self, left=0.0, right=0.0):
        self.left = max(-1.0, min(1.0, left))
        self.right = max(-1.0, min(1.0, right))

class MotorControllerNode(Node):
    """Convert joystick input to motor commands"""
    
    def __init__(self):
        super().__init__('motor_controller')
        
        # Declare parameters
        self.declare_parameter('joy_topic', '/joy')
        self.declare_parameter('motor_topic', '/rover/motor_commands')
        self.declare_parameter('max_speed', 1.0)
        self.declare_parameter('turn_speed', 0.8)
        self.declare_parameter('deadzone', 0.1)
        self.declare_parameter('fine_control_factor', 0.5)
        
        # Get parameters
        joy_topic = self.get_parameter('joy_topic').value
        self.motor_topic = self.get_parameter('motor_topic').value
        self.max_speed = self.get_parameter('max_speed').value
        self.turn_speed = self.get_parameter('turn_speed').value
        self.deadzone = self.get_parameter('deadzone').value
        self.fine_control_factor = self.get_parameter('fine_control_factor').value
        
        # Create subscribers
        self.joy_sub = self.create_subscription(Joy, joy_topic, self.joy_callback, 10)
        
        # Create publishers
        self.motor_pub = self.create_publisher(Float32MultiArray, self.motor_topic, 10)
        self.status_pub = self.create_publisher(String, '/rover/motor_status', 10)
        
        # State
        self.last_command = MotorCommand()
        self.emergency_stop = False
        self.fine_control = False
        
        self.get_logger().info(f'Motor Controller started')
        self.get_logger().info(f'  Joy topic: {joy_topic}')
        self.get_logger().info(f'  Motor topic: {self.motor_topic}')
        self.get_logger().info(f'  Max speed: {self.max_speed}')
        self.get_logger().info(f'  Turn speed: {self.turn_speed}')
    
    def joy_callback(self, msg: Joy):
        """Process joystick input and generate motor commands"""
        
        # Check for emergency stop (A button)
        if len(msg.buttons) > 0 and msg.buttons[0]:  # A button
            self.emergency_stop = True
            self.publish_motor_command(MotorCommand(0.0, 0.0))
            self.publish_status('EMERGENCY_STOP')
            return
        
        # Check for reset (B button)
        if len(msg.buttons) > 1 and msg.buttons[1]:  # B button
            self.emergency_stop = False
            self.publish_status('RESET')
        
        # Check for fine control (LB button)
        self.fine_control = len(msg.buttons) > 4 and msg.buttons[4] == 1
        
        if self.emergency_stop:
            return
        
        # Extract joystick values
        # Axis 1: Left stick Y (forward/backward)
        # Axis 3: Right stick X (turn)
        
        forward = msg.axes[1] if len(msg.axes) > 1 else 0.0  # Left stick Y
        turn = msg.axes[3] if len(msg.axes) > 3 else 0.0     # Right stick X
        
        # Apply deadzone
        forward = self.apply_deadzone(forward, self.deadzone)
        turn = self.apply_deadzone(turn, self.deadzone)
        
        # Apply fine control
        if self.fine_control:
            forward *= self.fine_control_factor
            turn *= self.fine_control_factor
        
        # Convert to motor commands using tank drive
        left_speed, right_speed = self.tank_drive(forward, turn)
        
        # Clamp speeds
        left_speed = max(-1.0, min(1.0, left_speed * self.max_speed))
        right_speed = max(-1.0, min(1.0, right_speed * self.max_speed))
        
        # Create and publish command
        command = MotorCommand(left_speed, right_speed)
        self.last_command = command
        self.publish_motor_command(command)
    
    def apply_deadzone(self, value: float, deadzone: float) -> float:
        """Apply deadzone to joystick axis"""
        if abs(value) < deadzone:
            return 0.0
        
        # Scale value to remove deadzone
        if value > 0:
            return (value - deadzone) / (1.0 - deadzone)
        else:
            return (value + deadzone) / (1.0 - deadzone)
    
    def tank_drive(self, forward: float, turn: float) -> tuple:
        """
        Convert forward/turn input to left/right motor speeds.
        
        Tank drive (differential drive) control:
        - Forward: both motors at same speed
        - Turn: reduce speed on one side
        
        Args:
            forward: -1.0 (reverse) to 1.0 (forward)
            turn: -1.0 (left) to 1.0 (right)
        
        Returns:
            (left_speed, right_speed): -1.0 to 1.0
        """
        
        # Simple tank drive algorithm
        left_speed = forward - (turn * self.turn_speed)
        right_speed = forward + (turn * self.turn_speed)
        
        # Normalize if either exceeds 1.0
        max_speed = max(abs(left_speed), abs(right_speed))
        if max_speed > 1.0:
            left_speed /= max_speed
            right_speed /= max_speed
        
        return left_speed, right_speed
    
    def publish_motor_command(self, command: MotorCommand):
        """Publish motor command"""
        msg = Float32MultiArray()
        msg.data = [float(command.left), float(command.right)]
        self.motor_pub.publish(msg)
        
        self.get_logger().debug(
            f'Motor command: L={command.left:.2f}, R={command.right:.2f}'
        )
    
    def publish_status(self, status: str):
        """Publish motor controller status"""
        msg = String()
        msg.data = status
        self.status_pub.publish(msg)
        self.get_logger().info(f'Status: {status}')

def main(args=None):
    rclpy.init(args=args)
    node = MotorControllerNode()
    
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info('Shutting down...')
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
