#!/usr/bin/env python3

"""
System Status Publisher Node

Publishes system health status as std_msgs/String messages.

Message format:
    "GOOD" | "WARNING" | "CRITICAL"

Usage:
    ros2 run rover_telemetry system_status_pub
"""

import rclpy
from rclpy.node import Node
from std_msgs.msg import String
import random

class SystemStatusPublisher(Node):
    def __init__(self):
        super().__init__('system_status_publisher')
        
        self.publisher = self.create_publisher(
            String,
            '/rover/system_status',
            10
        )
        
        # Publish every 2 seconds
        self.timer = self.create_timer(2.0, self.publish_data)
        
        self.get_logger().info('System Status Publisher started')
        self.get_logger().info('Publishing to: /rover/system_status')
    
    def publish_data(self):
        """Publish system status"""
        msg = String()
        
        # Randomly choose status (mostly GOOD, occasionally WARNING/CRITICAL)
        rand = random.random()
        if rand > 0.85:
            msg.data = 'CRITICAL'
        elif rand > 0.70:
            msg.data = 'WARNING'
        else:
            msg.data = 'GOOD'
        
        self.publisher.publish(msg)
        self.get_logger().info(f'Published status: {msg.data}')

def main(args=None):
    rclpy.init(args=args)
    node = SystemStatusPublisher()
    
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info('Shutting down...')
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
