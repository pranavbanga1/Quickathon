from setuptools import setup, find_packages

package_name = 'rover_telemetry'

setup(
    name=package_name,
    version='0.1.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='TASC Team',
    maintainer_email='tasc@example.com',
    description='Rover telemetry publishers for dashboard integration',
    license='MIT',
    tests_require=['pytest'],
      entry_points={
        'console_scripts': [
            'network_health_pub = rover_telemetry.network_health_publisher:main',
            'joystick_pub = rover_telemetry.joystick_publisher:main',
            'system_status_pub = rover_telemetry.system_status_publisher:main',
            'joystick_reader_node = rover_telemetry.joystick_reader_node:main',
            'motor_controller = rover_telemetry.motor_controller_node:main',
        ],
    }
