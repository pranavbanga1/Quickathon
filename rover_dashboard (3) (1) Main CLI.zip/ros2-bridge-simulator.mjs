import express from 'express';
import WebSocket from 'ws';
import { createServer } from 'http';

const app = express();
app.use(express.json());

const PORT = parseInt(process.env.BRIDGE_PORT || '9090');

// Data source mode
let dataSourceMode = 'ros';
let latestData = {
  latency: 0,
  packetLoss: 0,
  signalStrength: -80,
  txThroughput: 0,
  rxThroughput: 0,
  joystickX: 0,
  joystickY: 0,
  joystickButtons: Array(10).fill(0),
  joystickAxes: Array(6).fill(0),
  systemStatus: 'GOOD',
};

// WebSocket server
const server = createServer(app);
const wss = new WebSocket.Server({ server });

// Health check
app.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    dataSource: dataSourceMode,
    timestamp: new Date().toISOString()
  });
});

// Simulation data endpoint
app.post('/simulate', (req, res) => {
  try {
    const simulatedData = req.body;
    dataSourceMode = 'simulator';
    
    latestData = {
      ...latestData,
      latency: simulatedData.latency || 0,
      packetLoss: simulatedData.packetLoss || 0,
      signalStrength: simulatedData.signalStrength || -80,
      txThroughput: simulatedData.txThroughput || 0,
      rxThroughput: simulatedData.rxThroughput || 0,
      joystickAxes: simulatedData.joystickAxes || Array(6).fill(0),
      joystickButtons: simulatedData.joystickButtons || Array(10).fill(0),
      joystickX: simulatedData.joystickAxes?.[0] || 0,
      joystickY: simulatedData.joystickAxes?.[1] || 0,
      systemStatus: simulatedData.systemStatus || 'GOOD',
    };
    
    broadcastData();
    res.json({ status: 'ok', message: 'Simulation data received' });
  } catch (e) {
    console.error('[Simulator] Error:', e);
    res.status(400).json({ error: 'Invalid data' });
  }
});

// WebSocket connections
wss.on('connection', (ws) => {
  console.log('[WS] Client connected. Total clients:', wss.clients.size);
  ws.send(JSON.stringify({ type: 'data', payload: latestData }));
  ws.on('close', () => {
    console.log('[WS] Client disconnected. Total clients:', wss.clients.size);
  });
});

// Broadcast data
function broadcastData() {
  const message = JSON.stringify({ type: 'data', payload: latestData });
  wss.clients.forEach(client => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(message);
    }
  });
}

// Start server
server.listen(PORT, () => {
  console.log(`[Bridge] Running on port ${PORT}`);
  console.log(`[Bridge] Data source: ${dataSourceMode}`);
  console.log(`[Bridge] Simulation endpoint: POST http://localhost:${PORT}/simulate`);
});

process.on('SIGINT', () => {
  console.log('[Bridge] Shutting down...');
  wss.clients.forEach(client => client.close());
  server.close(() => process.exit(0));
});
