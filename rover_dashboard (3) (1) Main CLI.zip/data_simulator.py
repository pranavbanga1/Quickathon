#!/usr/bin/env python3

"""
Rover Dashboard Data Simulator

Generates realistic network telemetry and joystick data for the dashboard.
Simulates all dashboard parameters without requiring ROS.

Usage:
    python3 data_simulator.py --bridge-url http://localhost:9090
    python3 data_simulator.py --bridge-url http://localhost:9090 --joystick /dev/input/js0
    python3 data_simulator.py --bridge-url http://localhost:9090 --mode interactive

Features:
- Realistic network metrics (latency, packet loss, signal strength)
- Simulated TX/RX throughput with variations
- USB joystick input detection (optional)
- Interactive mode for manual parameter adjustment
- Configurable update frequency
"""

import argparse
import json
import math
import random
import sys
import time
from dataclasses import dataclass, asdict
from typing import Optional, Tuple

import requests

try:
    import pygame
    PYGAME_AVAILABLE = True
except ImportError:
    PYGAME_AVAILABLE = False
    print("[WARNING] pygame not installed. Joystick input disabled.")
    print("          Install with: pip install pygame")


@dataclass
class NetworkMetrics:
    """Network telemetry data"""
    latency: float = 40.0  # ms
    packet_loss: float = 0.05  # %
    signal_strength: float = -75  # dBm
    tx_throughput: float = 50.0  # Mbps
    rx_throughput: float = 75.0  # Mbps
    system_status: str = "GOOD"  # GOOD, WARNING, CRITICAL


@dataclass
class JoystickData:
    """Joystick input data"""
    axes: list = None  # [lx, ly, lt, rx, ry, rt]
    buttons: list = None  # [a, b, x, y, lb, rb, back, start, ls, rs]

    def __post_init__(self):
        if self.axes is None:
            self.axes = [0.0] * 6
        if self.buttons is None:
            self.buttons = [0] * 10


class DataSimulator:
    """Generates realistic dashboard data"""

    def __init__(self, bridge_url: str, joystick_device: Optional[str] = None):
        self.bridge_url = bridge_url
        self.joystick_device = joystick_device
        self.running = True
        self.update_frequency = 20  # Hz (50ms updates)
        
        # Data state
        self.network = NetworkMetrics()
        self.joystick = JoystickData()
        
        # Simulation state
        self.time_elapsed = 0
        self.joystick_available = False
        
        # Initialize joystick if available
        if PYGAME_AVAILABLE and joystick_device:
            self._init_joystick()
    
    def _init_joystick(self):
        """Initialize pygame joystick"""
        try:
            pygame.init()
            pygame.joystick.init()
            
            joystick_count = pygame.joystick.get_count()
            if joystick_count > 0:
                self.joystick_obj = pygame.joystick.Joystick(0)
                self.joystick_obj.init()
                self.joystick_available = True
                print(f"[SUCCESS] Joystick detected: {self.joystick_obj.get_name()}")
                print(f"          Axes: {self.joystick_obj.get_numaxes()}")
                print(f"          Buttons: {self.joystick_obj.get_numbuttons()}")
            else:
                print("[WARNING] No joystick detected")
        except Exception as e:
            print(f"[ERROR] Failed to initialize joystick: {e}")
    
    def _read_joystick(self):
        """Read real joystick input"""
        if not self.joystick_available:
            return
        
        try:
            pygame.event.pump()  # Update joystick state
            
            # Read axes
            axes = []
            for i in range(min(6, self.joystick_obj.get_numaxes())):
                axes.append(self.joystick_obj.get_axis(i))
            
            # Pad with zeros if fewer than 6 axes
            while len(axes) < 6:
                axes.append(0.0)
            
            # Read buttons
            buttons = []
            for i in range(min(10, self.joystick_obj.get_numbuttons())):
                buttons.append(1 if self.joystick_obj.get_button(i) else 0)
            
            # Pad with zeros if fewer than 10 buttons
            while len(buttons) < 10:
                buttons.append(0)
            
            self.joystick.axes = axes
            self.joystick.buttons = buttons
        except Exception as e:
            print(f"[ERROR] Failed to read joystick: {e}")
    
    def _simulate_network_metrics(self):
        """Generate realistic network metrics with variations"""
        
        # Latency: oscillates around 40ms with random spikes
        base_latency = 40.0
        oscillation = 10.0 * math.sin(self.time_elapsed * 0.5)
        spike = random.gauss(0, 5) if random.random() < 0.1 else 0
        self.network.latency = max(10, base_latency + oscillation + spike)
        
        # Packet loss: mostly low with occasional spikes
        if random.random() < 0.95:
            self.network.packet_loss = random.gauss(0.05, 0.02)
        else:
            self.network.packet_loss = random.gauss(0.5, 0.3)
        self.network.packet_loss = max(0, min(5, self.network.packet_loss))
        
        # Signal strength: varies between -65 and -85 dBm
        self.network.signal_strength = -75 + random.gauss(0, 5)
        self.network.signal_strength = max(-90, min(-60, self.network.signal_strength))
        
        # TX throughput: varies between 30-70 Mbps
        self.network.tx_throughput = 50 + random.gauss(0, 10)
        self.network.tx_throughput = max(20, min(100, self.network.tx_throughput))
        
        # RX throughput: varies between 50-90 Mbps
        self.network.rx_throughput = 70 + random.gauss(0, 15)
        self.network.rx_throughput = max(40, min(120, self.network.rx_throughput))
        
        # System status based on latency and packet loss
        if self.network.latency > 100 or self.network.packet_loss > 1.0:
            self.network.system_status = "CRITICAL"
        elif self.network.latency > 60 or self.network.packet_loss > 0.5:
            self.network.system_status = "WARNING"
        else:
            self.network.system_status = "GOOD"
    
    def _simulate_joystick(self):
        """Generate simulated joystick input (if no real joystick)"""
        if self.joystick_available:
            return  # Use real joystick
        
        # Simulate smooth joystick movement
        t = self.time_elapsed * 0.3
        
        # Left stick: circular motion
        self.joystick.axes[0] = 0.5 * math.sin(t)
        self.joystick.axes[1] = 0.5 * math.cos(t)
        
        # Right stick: slower circular motion
        self.joystick.axes[3] = 0.3 * math.sin(t * 0.5)
        self.joystick.axes[4] = 0.3 * math.cos(t * 0.5)
        
        # Triggers: oscillate
        self.joystick.axes[2] = 0.5 * math.sin(t * 2)
        self.joystick.axes[5] = 0.5 * math.cos(t * 2)
        
        # Buttons: random presses
        if random.random() < 0.05:
            button_idx = random.randint(0, 9)
            self.joystick.buttons[button_idx] = 1
        else:
            self.joystick.buttons = [0] * 10
    
    def generate_data(self) -> dict:
        """Generate complete dashboard data"""
        self._simulate_network_metrics()
        self._simulate_joystick()
        self._read_joystick()
        
        return {
            "latency": round(self.network.latency, 1),
            "packetLoss": round(self.network.packet_loss, 2),
            "signalStrength": round(self.network.signal_strength, 0),
            "txThroughput": round(self.network.tx_throughput, 1),
            "rxThroughput": round(self.network.rx_throughput, 1),
            "systemStatus": self.network.system_status,
            "joystickAxes": [round(x, 2) for x in self.joystick.axes],
            "joystickButtons": self.joystick.buttons,
        }
    
    def send_data(self, data: dict) -> bool:
        """Send data to bridge"""
        try:
            response = requests.post(
                f"{self.bridge_url}/simulate",
                json=data,
                timeout=2
            )
            if response.status_code == 200:
                return True
            else:
                print(f"[ERROR] Bridge returned {response.status_code}")
                return False
        except requests.exceptions.ConnectionError:
            print(f"[ERROR] Cannot connect to bridge at {self.bridge_url}")
            return False
        except Exception as e:
            print(f"[ERROR] Failed to send data: {e}")
            return False
    
    def run(self, interactive: bool = False):
        """Run simulator loop"""
        print(f"[START] Rover Dashboard Data Simulator")
        print(f"        Bridge URL: {self.bridge_url}")
        print(f"        Update frequency: {self.update_frequency} Hz")
        print(f"        Joystick available: {self.joystick_available}")
        print(f"        Interactive mode: {interactive}")
        print()
        print("Press Ctrl+C to stop")
        print("-" * 60)
        
        update_interval = 1.0 / self.update_frequency
        last_update = time.time()
        
        try:
            while self.running:
                current_time = time.time()
                
                if current_time - last_update >= update_interval:
                    self.time_elapsed += update_interval
                    
                    # Generate and send data
                    data = self.generate_data()
                    success = self.send_data(data)
                    
                    if success:
                        status = "✓"
                    else:
                        status = "✗"
                    
                    # Print status
                    print(
                        f"{status} Latency: {data['latency']:6.1f}ms | "
                        f"Loss: {data['packetLoss']:5.2f}% | "
                        f"Signal: {data['signalStrength']:4.0f}dBm | "
                        f"Status: {data['systemStatus']:8s} | "
                        f"TX: {data['txThroughput']:5.1f}Mbps RX: {data['rxThroughput']:5.1f}Mbps"
                    )
                    
                    if interactive:
                        self._interactive_prompt()
                    
                    last_update = current_time
                
                time.sleep(0.01)  # Small sleep to prevent busy waiting
        
        except KeyboardInterrupt:
            print("\n[STOP] Simulator stopped")
    
    def _interactive_prompt(self):
        """Interactive mode for manual parameter adjustment"""
        # This would be implemented for interactive mode
        pass
    
    def set_latency(self, value: float):
        """Manually set latency"""
        self.network.latency = max(0, value)
    
    def set_packet_loss(self, value: float):
        """Manually set packet loss"""
        self.network.packet_loss = max(0, min(100, value))
    
    def set_signal_strength(self, value: float):
        """Manually set signal strength"""
        self.network.signal_strength = value
    
    def set_system_status(self, status: str):
        """Manually set system status"""
        if status in ["GOOD", "WARNING", "CRITICAL"]:
            self.network.system_status = status


def main():
    parser = argparse.ArgumentParser(
        description="Rover Dashboard Data Simulator"
    )
    parser.add_argument(
        "--bridge-url",
        default="http://localhost:9090",
        help="Bridge server URL (default: http://localhost:9090)"
    )
    parser.add_argument(
        "--joystick",
        default=None,
        help="USB joystick device path (e.g., /dev/input/js0)"
    )
    parser.add_argument(
        "--frequency",
        type=int,
        default=20,
        help="Update frequency in Hz (default: 20)"
    )
    parser.add_argument(
        "--interactive",
        action="store_true",
        help="Enable interactive mode for manual parameter adjustment"
    )
    
    args = parser.parse_args()
    
    simulator = DataSimulator(args.bridge_url, args.joystick)
    simulator.update_frequency = args.frequency
    simulator.run(interactive=args.interactive)


if __name__ == "__main__":
    main()
