# 🐍 Complete CLI Simulator Setup Guide

**Comprehensive step-by-step guide to set up and run the Rover Dashboard in Simulator Mode using Python CLI.**

---

## Table of Contents

1. [Prerequisites](#prerequisites)
2. [Installation](#installation)
3. [Running the Dashboard](#running-the-dashboard)
4. [Using the CLI Simulator](#using-the-cli-simulator)
5. [Testing Scenarios](#testing-scenarios)
6. [Troubleshooting](#troubleshooting)

---

## Prerequisites

Before you start, ensure you have the following installed on your system:

### Required Software

| Software | Version | Purpose | Installation |
|----------|---------|---------|--------------|
| **Python** | 3.8+ | Run CLI simulator | `python3 --version` |
| **Node.js** | 16+ | Run bridge server | `node --version` |
| **npm/pnpm** | Latest | Package manager | `pnpm --version` |
| **Git** | Any | Clone/manage code | `git --version` |

### Check Your System

```bash
# Check Python
python3 --version
# Expected: Python 3.8.0 or higher

# Check Node.js
node --version
# Expected: v16.0.0 or higher

# Check pnpm
pnpm --version
# Expected: 8.0.0 or higher
```

If any are missing, install them:

**Ubuntu/Debian:**
```bash
sudo apt update
sudo apt install python3 python3-pip nodejs npm
npm install -g pnpm
```

**macOS (with Homebrew):**
```bash
brew install python3 node
npm install -g pnpm
```

**Windows (with Chocolatey):**
```bash
choco install python nodejs
npm install -g pnpm
```

---

## Installation

### Step 1: Clone/Download the Project

```bash
# Navigate to your projects directory
cd ~/projects

# If you have the ZIP file, extract it
unzip rover_dashboard.zip
cd rover_dashboard

# OR clone from git (if available)
git clone <your-repo-url>
cd rover_dashboard
```

### Step 2: Install Dependencies

```bash
# Install Node.js dependencies for the bridge and dashboard
pnpm install

# This will install:
# - React, TypeScript, Vite (frontend)
# - Express, WebSocket libraries (bridge)
# - Testing libraries (vitest)
```

**Expected output:**
```
✓ Packages in lockfile are up to date
✓ 245 packages installed
```

### Step 3: Verify Installation

```bash
# Check if all files are present
ls -la

# You should see:
# - client/          (React frontend)
# - server/          (Backend placeholder)
# - ros2-bridge-simulator.mjs  (Bridge server)
# - data_simulator_interactive.py  (CLI simulator)
# - package.json     (Dependencies)
```

### Step 4: Install Python Dependencies

```bash
# Install Python packages for the simulator
pip3 install requests

# Verify installation
python3 -c "import requests; print('✓ requests installed')"
```

**Expected output:**
```
✓ requests installed
```

---

## Running the Dashboard

### Terminal Setup

You'll need **3 terminal windows** open simultaneously:

1. **Terminal 1**: Bridge Server
2. **Terminal 2**: Dashboard Frontend
3. **Terminal 3**: CLI Simulator

### Step 1: Start the Bridge Server (Terminal 1)

```bash
# Navigate to project directory
cd ~/rover_dashboard

# Start the bridge server
node ros2-bridge-simulator.mjs

# Expected output:
# [Bridge] Server running on port 9090
# [Bridge] Data source: simulator
# [Bridge] Simulation endpoint: POST http://localhost:9090/simulate
# [Bridge] WebSocket ready for connections
```

**What this does:**
- Starts a Node.js server on `http://localhost:9090`
- Accepts data from the Python CLI simulator via HTTP POST
- Broadcasts data to the dashboard via WebSocket
- Provides health check endpoint

**Troubleshooting:**
- If port 9090 is already in use: `lsof -i :9090` to find the process
- Kill it with: `kill -9 <PID>`

### Step 2: Start the Dashboard (Terminal 2)

```bash
# Navigate to project directory
cd ~/rover_dashboard

# Start the development server
pnpm dev

# Expected output:
# ➜  Local:   http://localhost:3000/
# ➜  Network: http://169.254.0.21:3000/
# ➜  press h to show help
```

**What this does:**
- Starts a Vite development server on `http://localhost:3000`
- Hot-reloads on code changes
- Connects to the bridge via WebSocket

**Open in Browser:**
```
http://localhost:3000
```

You should see the Rover Dashboard with:
- Yellow banner: "Running in simulation mode"
- Radar View showing joystick visualization
- Stat cards showing default values
- Network Traffic chart

### Step 3: Start the CLI Simulator (Terminal 3)

```bash
# Navigate to project directory
cd ~/rover_dashboard

# Run the interactive simulator
python3 data_simulator_interactive.py --bridge-url http://localhost:9090

# Expected output:
# ============================================================
# 🚀 Rover Dashboard Interactive Simulator
# ============================================================
# Bridge URL: http://localhost:9090
# Type 'help' for commands, 'exit' to quit
# ============================================================
#
# >>>
```

**What this does:**
- Connects to the bridge server
- Provides an interactive CLI for controlling dashboard values
- Sends data updates every 50ms (20 Hz)
- Displays confirmation messages for each command

---

## Using the CLI Simulator

### Basic Commands

Once the CLI is running, you can type commands to update the dashboard in real-time.

#### Network Metrics

**Set Latency (milliseconds)**
```bash
>>> latency 50
✓ Latency set to 50.0 ms

>>> latency 100
✓ Latency set to 100.0 ms
```

**Set Packet Loss (percentage)**
```bash
>>> loss 0.1
✓ Packet loss set to 0.1%

>>> loss 1.5
✓ Packet loss set to 1.5%
```

**Set Signal Strength (dBm)**
```bash
>>> signal -75
✓ Signal strength set to -75 dBm

>>> signal -65
✓ Signal strength set to -65 dBm
```

**Set TX Throughput (Mbps)**
```bash
>>> tx 50
✓ TX throughput set to 50.0 Mbps

>>> tx 100
✓ TX throughput set to 100.0 Mbps
```

**Set RX Throughput (Mbps)**
```bash
>>> rx 75
✓ RX throughput set to 75.0 Mbps

>>> rx 120
✓ RX throughput set to 120.0 Mbps
```

**Set System Status**
```bash
>>> status GOOD
✓ System status set to GOOD

>>> status WARNING
✓ System status set to WARNING

>>> status CRITICAL
✓ System status set to CRITICAL
```

#### Joystick Control

**Set Joystick Position**
```bash
# Move joystick forward (Y = -1)
>>> joystick 0 -1

# Move joystick right (X = 1)
>>> joystick 1 0

# Diagonal movement
>>> joystick 0.7 -0.5

# Center joystick
>>> joystick 0 0
```

**Press Buttons**
```bash
# Button IDs: 0=A, 1=B, 2=X, 3=Y, 4=LB, 5=RB, 6=Back, 7=Start, 8=LS, 9=RS

# Press A button
>>> button 0 1

# Release A button
>>> button 0 0

# Press multiple buttons
>>> button 0 1
>>> button 4 1
>>> button 0 0
>>> button 4 0
```

#### Automatic Simulation

**Start/Stop Automatic Simulation**
```bash
# Start automatic simulation (values oscillate realistically)
>>> simulate

# Watch dashboard update automatically
# Values will change smoothly over time

# Stop automatic simulation
>>> simulate
```

#### View Current State

**Display All Current Values**
```bash
>>> status

# Output:
# === Current Dashboard State ===
# Latency:        40.5 ms
# Packet Loss:    0.05%
# Signal:         -75 dBm
# TX:             50.2 Mbps
# RX:             75.1 Mbps
# System Status:  GOOD
# Joystick X:     0.25
# Joystick Y:     -0.45
# Buttons:        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
```

#### Help and Exit

**Show All Commands**
```bash
>>> help

# Displays full command reference
```

**Exit the Simulator**
```bash
>>> exit
Goodbye!
```

---

## Testing Scenarios

### Scenario 1: Basic Network Test

**Objective:** Verify all network metrics update correctly.

```bash
# Terminal 3 (CLI)
>>> latency 40
>>> loss 0.05
>>> signal -75
>>> tx 50
>>> rx 75
>>> status GOOD

# Watch Terminal 2 (Dashboard)
# All values should update immediately
```

### Scenario 2: Network Degradation

**Objective:** Simulate network problems and recovery.

```bash
# Terminal 3 (CLI)

# Good network
>>> latency 30
>>> loss 0.05
>>> status GOOD

# Network starts degrading
>>> latency 80
>>> loss 0.5
>>> status WARNING

# Network gets critical
>>> latency 150
>>> loss 2.0
>>> status CRITICAL

# Network recovers
>>> latency 40
>>> loss 0.05
>>> status GOOD
```

### Scenario 3: Joystick Control

**Objective:** Test joystick visualization and button presses.

```bash
# Terminal 3 (CLI)

# Move joystick forward
>>> joystick 0 -1

# Move joystick right
>>> joystick 1 0

# Move diagonally
>>> joystick 0.7 -0.5

# Press A button
>>> button 0 1

# Release A button
>>> button 0 0

# Watch Terminal 2 (Dashboard)
# Radar should show joystick position
# Buttons should highlight when pressed
```

### Scenario 4: Automatic Simulation

**Objective:** Test automatic oscillation mode.

```bash
# Terminal 3 (CLI)

# Start automatic simulation
>>> simulate

# Watch for 30 seconds
# Values should oscillate smoothly

# Stop simulation
>>> simulate
```

### Scenario 5: Full Hackathon Demo

**Objective:** Complete demo flow for judges.

```bash
# Terminal 3 (CLI)

# 1. Show normal operation
>>> status GOOD
>>> latency 40
>>> loss 0.05
>>> signal -75

# 2. Demonstrate joystick control
>>> joystick 0.5 0.3
# (Pause 2 seconds for judges to see)

# 3. Simulate network interference
>>> latency 120
>>> loss 1.5
>>> status WARNING
# (Pause 2 seconds - show dashboard responding)

# 4. Recover network
>>> latency 40
>>> loss 0.05
>>> status GOOD

# 5. Show button presses
>>> button 0 1
# (Pause 1 second)
>>> button 0 0
```

---

## Troubleshooting

### Dashboard Not Updating

**Problem:** CLI commands execute but dashboard doesn't change.

**Solution:**
1. Check if bridge is running (Terminal 1):
   ```bash
   curl http://localhost:9090/health
   # Should return: {"status":"ok","dataSource":"simulator"}
   ```

2. Check if dashboard is in Simulator Mode:
   - Click ⚙️ (Settings) in top-right
   - Verify "🐍 Simulator Mode (Python CLI)" is selected
   - Click Save

3. Refresh dashboard page: `Ctrl+R` or `Cmd+R`

### Bridge Not Starting

**Problem:** `Error: listen EADDRINUSE :::9090`

**Solution:**
```bash
# Find process using port 9090
lsof -i :9090

# Kill the process
kill -9 <PID>

# Try starting bridge again
node ros2-bridge-simulator.mjs
```

### CLI Not Connecting

**Problem:** `[ERROR] Failed to send data: Connection refused`

**Solution:**
1. Verify bridge is running on port 9090
2. Check bridge URL: `http://localhost:9090`
3. Try manually:
   ```bash
   curl http://localhost:9090/health
   ```

### Python Module Not Found

**Problem:** `ModuleNotFoundError: No module named 'requests'`

**Solution:**
```bash
# Install requests
pip3 install requests

# Verify
python3 -c "import requests; print('OK')"
```

### Dashboard Shows "Disconnected"

**Problem:** Dashboard shows red "Controller Disconnected" status.

**Solution:**
1. Check if bridge is running
2. Check browser console for WebSocket errors (F12)
3. Verify bridge URL in Settings matches your setup
4. Restart bridge and dashboard

---

## Performance Tips

### Optimize for Smooth Updates

```bash
# Use automatic simulation for smooth visuals
>>> simulate

# Manually update only when needed
>>> latency 50
>>> loss 0.1
```

### Monitor System Resources

```bash
# In a separate terminal, monitor CPU/memory
watch -n 1 'ps aux | grep -E "(node|python3|pnpm)"'
```

### Expected Resource Usage

- **Bridge (Node.js)**: ~30-50MB RAM, <1% CPU
- **Dashboard (Vite)**: ~100-150MB RAM, 2-5% CPU
- **CLI (Python)**: ~20-30MB RAM, <1% CPU
- **Total**: ~200MB RAM, <10% CPU

---

## Next Steps

Once you've verified the CLI simulator works:

1. **Test with USB Joystick** (optional):
   ```bash
   # Connect a USB gamepad/joystick
   # The CLI will auto-detect it
   python3 data_simulator_interactive.py --bridge-url http://localhost:9090
   ```

2. **Move to ROS 2 Mode** (see `SETUP_ROS2_INTEGRATION.md`):
   - Set up ROS 2 on your rover
   - Switch dashboard to "ROS 2 Mode" in Settings
   - Connect to real rover topics

3. **Prepare for Hackathon**:
   - Practice the demo flow
   - Create a demo script with key commands
   - Test on different browsers/devices

---

## Quick Reference

| Task | Command |
|------|---------|
| Start Bridge | `node ros2-bridge-simulator.mjs` |
| Start Dashboard | `pnpm dev` |
| Start CLI | `python3 data_simulator_interactive.py --bridge-url http://localhost:9090` |
| Set Latency | `latency 50` |
| Set Status | `status GOOD` |
| Move Joystick | `joystick 0.5 0.3` |
| Press Button | `button 0 1` |
| Auto Simulate | `simulate` |
| View State | `status` |
| Show Help | `help` |
| Exit | `exit` |

---

## Support

If you encounter issues:

1. Check the [Troubleshooting](#troubleshooting) section
2. Review browser console (F12 → Console tab)
3. Check terminal output for error messages
4. Verify all three processes are running
5. Try restarting all services

**Happy testing! 🚀**
