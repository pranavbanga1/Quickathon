# 🚀 Python Simulator Quick Start

**Demonstrate the full dashboard WITHOUT ROS in 2 minutes!**

---

## What is This?

A Python script that generates realistic rover telemetry data and streams it to the dashboard. Perfect for:
- **Hackathon demos** - Show off the dashboard without ROS setup
- **Testing** - Verify dashboard features work correctly
- **Development** - Rapid iteration without ROS dependencies
- **Proof of Concept** - Demonstrate the system works before integrating real ROS

---

## Quick Start (2 Minutes)

### Step 1: Install Dependencies

```bash
# Install Python packages
pip install requests pygame

# pygame is optional - only needed if you have a USB joystick
```

### Step 2: Start the Bridge

```bash
# Terminal 1: Start the bridge (accepts both ROS and simulator data)
cd ~/rover_dashboard
node ros2-bridge-simulator.mjs
```

You should see:
```
[Bridge] Running on port 9090
[Bridge] Data source: ros
[Bridge] Simulation endpoint: POST http://localhost:9090/simulate
```

### Step 3: Start the Dashboard

```bash
# Terminal 2: Start the dashboard
cd ~/rover_dashboard
pnpm dev
```

Open http://localhost:3000 in your browser.

### Step 4: Run the Simulator

```bash
# Terminal 3: Run the Python simulator
cd ~/rover_dashboard
python3 data_simulator.py --bridge-url http://localhost:9090
```

You should see:
```
[START] Rover Dashboard Data Simulator
        Bridge URL: http://localhost:9090
        Update frequency: 20 Hz
        Joystick available: False
        Interactive mode: False

Press Ctrl+C to stop
------------------------------------------------------------
✓ Latency:  40.5ms | Loss:  0.05% | Signal: -75dBm | Status: GOOD     | TX:  50.2Mbps RX:  75.1Mbps
✓ Latency:  42.1ms | Loss:  0.03% | Signal: -74dBm | Status: GOOD     | TX:  48.9Mbps RX:  76.3Mbps
✓ Latency:  41.8ms | Loss:  0.07% | Signal: -76dBm | Status: GOOD     | TX:  51.5Mbps RX:  74.8Mbps
```

**Watch the dashboard update in real-time!** 🎉

---

## With USB Joystick

If you have a USB joystick connected:

```bash
# Detect joystick
ls /dev/input/js*
# Should show: /dev/input/js0

# Run simulator with joystick
python3 data_simulator.py --bridge-url http://localhost:9090 --joystick /dev/input/js0
```

You should see:
```
[SUCCESS] Joystick detected: Xbox 360 Controller
          Axes: 6
          Buttons: 10
```

Now move the physical joystick and watch the dashboard update in real-time!

---

## Customization

### Change Update Frequency

```bash
# Update every 50ms instead of default 50ms (20 Hz)
python3 data_simulator.py --bridge-url http://localhost:9090 --frequency 20
```

### Simulate Different Network Conditions

The simulator automatically varies:
- **Latency**: 30-50ms with occasional spikes
- **Packet Loss**: 0.05% normally, occasional 0.5% spikes
- **Signal Strength**: -65 to -85 dBm variations
- **TX/RX Throughput**: Realistic variations

To change these, edit `data_simulator.py` in the `_simulate_network_metrics()` function.

---

## For Hackathon Judges

**What to tell them:**

> "We've built a modular dashboard that works with both simulated data (for rapid prototyping) and real ROS 2 topics (for production). The Python simulator demonstrates all dashboard features without ROS setup. For the actual rover, we simply swap the data source from `simulator` to `ros`, and the dashboard subscribes to real `/joy`, `/network_health`, and `/system_status` topics."

**Key talking points:**

1. **Modular Architecture** - Data source is pluggable (simulator or ROS)
2. **Rapid Prototyping** - Develop UI without waiting for ROS setup
3. **Production Ready** - Real ROS integration ready to go
4. **Scalable** - Easy to add more ROS topics or simulator parameters

---

## Switching Between Simulator and ROS

### Simulator Mode (Current)
```bash
# Terminal 1
node ros2-bridge-simulator.mjs

# Terminal 2
pnpm dev

# Terminal 3
python3 data_simulator.py --bridge-url http://localhost:9090
```

### ROS Mode (When Ready)
```bash
# Terminal 1
node ros2-bridge-enhanced.mjs  # Original bridge with ROS support

# Terminal 2
pnpm dev

# Terminal 3
ros2 run joy joy_node --ros-args -p dev:="/dev/input/js0"
# + other ROS publishers for network health, system status
```

**No code changes needed!** Just switch the bridge and data source.

---

## Troubleshooting

### Bridge not accepting data

```bash
# Check if bridge is running
curl http://localhost:9090/health

# Should return:
# {"status":"ok","dataSource":"simulator","timestamp":"..."}
```

### Dashboard not updating

1. Check browser console for WebSocket errors
2. Verify bridge is running: `curl http://localhost:9090/health`
3. Check simulator is sending data: Look for `✓` in terminal output
4. Try refreshing the dashboard page

### Joystick not detected

```bash
# Check if joystick is connected
ls /dev/input/js*

# If not found, check USB connection
lsusb | grep -i joy

# Test joystick directly
jstest /dev/input/js0
```

---

## Next Steps

1. **Connect Real Motors** - Modify `motor_controller_node.py` to use `/rover/motor_commands` from dashboard
2. **Add More Metrics** - Extend simulator to include battery, temperature, etc.
3. **Record & Playback** - Add feature to record all telemetry and replay
4. **Autonomous Mode** - Add goal-based navigation alongside manual control

---

## Files

- `data_simulator.py` - Python simulator script
- `ros2-bridge-simulator.mjs` - Bridge that accepts simulator data
- `ros2-bridge-enhanced.mjs` - Original bridge with ROS support

---

**Happy demoing! 🚀**
