# 🚀 Complete ROS 2 Implementation Guide for Rover Dashboard

This guide provides step-by-step instructions to integrate your actual rover with the Rover Dashboard using ROS 2.

## Table of Contents

1. [Quick Start (5 minutes)](#quick-start)
2. [Understanding the Architecture](#architecture)
3. [Setting Up ROS 2 Publishers](#setting-up-ros-2-publishers)
4. [Connecting to Your Rover](#connecting-to-your-rover)
5. [Real-Time Testing](#real-time-testing)
6. [Troubleshooting](#troubleshooting)

---

## Quick Start

### For Testing (Simulation Mode)

```bash
# Terminal 1: Start dashboard
cd rover_dashboard
pnpm dev

# Terminal 2: Start enhanced bridge (with simulation)
node ros2-bridge-enhanced.mjs --port 9090

# Open browser: http://localhost:3000
# You'll see simulated joystick and network data
```

### For Real Rover Data

```bash
# Terminal 1: On rover system, start publishers
cd ~/rover_ws
source install/setup.bash
ros2 run rover_telemetry joystick_pub &
ros2 run rover_telemetry network_health_pub &
ros2 run rover_telemetry system_status_pub

# Terminal 2: Start bridge
node ros2-bridge-enhanced.mjs --port 9090

# Terminal 3: On operator machine, start dashboard
pnpm dev

# Configure dashboard:
# Settings → IP: rover_ip → Port: 9090 → Save
```

---

## Architecture

```
┌─────────────────────────────────────────┐
│   Operator Machine (Your Computer)      │
│                                         │
│  ┌─────────────────────────────────┐   │
│  │  Rover Dashboard (Browser)      │   │
│  │  - Real-time UI updates         │   │
│  │  - Controller visualization     │   │
│  │  - Network metrics display      │   │
│  └──────────────┬──────────────────┘   │
│                 │ WebSocket (ws://)    │
│  ┌──────────────▼──────────────────┐   │
│  │  ROS 2 Bridge (Node.js)         │   │
│  │  - Subscribes to ROS topics     │   │
│  │  - Parses Joy messages          │   │
│  │  - Forwards data via WebSocket  │   │
│  └──────────────┬──────────────────┘   │
└─────────────────┼──────────────────────┘
                  │ Network (WiFi/Ethernet)
┌─────────────────▼──────────────────────┐
│   Rover System (Ubuntu + ROS 2)        │
│                                         │
│  ┌─────────────────────────────────┐   │
│  │  ROS 2 Publishers               │   │
│  │  - /rover/joystick_input        │   │
│  │  - /rover/network_health        │   │
│  │  - /rover/system_status         │   │
│  └─────────────────────────────────┘   │
│                                         │
│  ┌─────────────────────────────────┐   │
│  │  Rover Hardware                 │   │
│  │  - Motors, sensors, etc.        │   │
│  └─────────────────────────────────┘   │
└─────────────────────────────────────────┘
```

---

## Setting Up ROS 2 Publishers

### Step 1: Copy Example Package

```bash
# Copy the example package to your workspace
cp -r rover_dashboard/example_ros2_package ~/rover_ws/src/rover_telemetry

# Build it
cd ~/rover_ws
colcon build --packages-select rover_telemetry

# Source workspace
source install/setup.bash
```

### Step 2: Verify Publishers Work

```bash
# Terminal 1: Start joystick publisher
ros2 run rover_telemetry joystick_pub

# Terminal 2: Verify it's publishing
ros2 topic echo /rover/joystick_input

# You should see:
# header:
#   stamp:
#     sec: ...
#     nsec: ...
#   frame_id: ''
# axes: [0.7, 0.3, 0.0, 0.0, -0.2, 0.1]
# buttons: [0, 0, 0, 0, 0, 0, 0, 0]
```

### Step 3: Test Network Health Publisher

```bash
# Terminal 1: Start network health publisher
ros2 run rover_telemetry network_health_pub

# Terminal 2: Verify it's publishing
ros2 topic echo /rover/network_health

# You should see:
# data: [45.3, 0.05, -74.0, 45.3, 64.4]
#        ↑     ↑     ↑       ↑     ↑
#        |     |     |       |     └─ RX (Mbps)
#        |     |     |       └─ TX (Mbps)
#        |     |     └─ Signal (dBm)
#        |     └─ Packet Loss (%)
#        └─ Latency (ms)
```

### Step 4: Test System Status Publisher

```bash
# Terminal 1: Start system status publisher
ros2 run rover_telemetry system_status_pub

# Terminal 2: Verify it's publishing
ros2 topic echo /rover/system_status

# You should see:
# data: GOOD
```

---

## Connecting to Your Rover

### Option A: Same Machine (Development)

```bash
# Terminal 1: Start all publishers
cd ~/rover_ws
source install/setup.bash
ros2 run rover_telemetry joystick_pub &
ros2 run rover_telemetry network_health_pub &
ros2 run rover_telemetry system_status_pub &

# Terminal 2: Start bridge
cd ~/rover_dashboard
node ros2-bridge-enhanced.mjs --port 9090

# Terminal 3: Start dashboard
pnpm dev

# Open http://localhost:3000
# Settings → localhost:9090 → Save
```

### Option B: Separate Machines (Real Deployment)

**On Rover System:**

```bash
# SSH into rover
ssh ubuntu@rover_ip

# Start publishers
cd ~/rover_ws
source install/setup.bash
ros2 run rover_telemetry joystick_pub &
ros2 run rover_telemetry network_health_pub &
ros2 run rover_telemetry system_status_pub &

# Start bridge (listen on all interfaces)
cd ~/rover_dashboard
node ros2-bridge-enhanced.mjs --port 9090
```

**On Operator Machine:**

```bash
# Start dashboard
cd ~/rover_dashboard
pnpm dev

# Open http://localhost:3000
# Settings → rover_ip (e.g., 192.168.1.100) → Port: 9090 → Save
```

---

## Real-Time Testing

### Test Checklist

- [ ] Dashboard loads without errors
- [ ] Settings modal opens and saves configuration
- [ ] Bridge connects to ROS 2 (check console for "ROS 2 found")
- [ ] Joystick visualization updates in real-time
- [ ] Network metrics change every second
- [ ] System status changes periodically
- [ ] Both "Radar View" and "Controller View" work
- [ ] Connection status shows "Connected"

### Monitor ROS 2 Topics

```bash
# List all active topics
ros2 topic list

# Should show:
# /rover/joystick_input
# /rover/network_health
# /rover/system_status

# Check message frequency
ros2 topic hz /rover/joystick_input
# Should show ~10 Hz

ros2 topic hz /rover/network_health
# Should show ~1 Hz

# Check message types
ros2 topic info /rover/joystick_input
# Type: sensor_msgs/msg/Joy
```

### Monitor WebSocket Bridge

```bash
# Check if bridge is running
ps aux | grep ros2-bridge

# Check port is listening
netstat -tuln | grep 9090
# or
lsof -i :9090

# Check bridge logs
# The bridge prints to console, so you should see:
# [ROS2] Subscribing to topic: /rover/joystick_input
# [ROS2] First message received from /rover/joystick_input: ...
```

---

## Integrating with Your Actual Rover

### Step 1: Identify Your Rover's Topics

```bash
# List all topics on your rover
ros2 topic list

# Find joystick-related topics
ros2 topic list | grep -i joy
ros2 topic list | grep -i cmd
ros2 topic list | grep -i input

# Check message types
ros2 topic info /your_joystick_topic
ros2 msg show sensor_msgs/Joy
```

### Step 2: Map Topics in Bridge

Edit `ros2-bridge-enhanced.mjs` line 24-28:

```javascript
// Update these to match your rover's actual topics
const TOPICS = {
  networkHealth: `/your_rover_namespace/network_metrics`,  // or /diagnostics
  joystickInput: `/your_rover_namespace/joy`,              // or /cmd_vel
  systemStatus: `/your_rover_namespace/system_state`,      // or /status
};
```

### Step 3: Handle Custom Message Types

If your rover uses custom messages, update the parsers in `ros2-bridge-enhanced.mjs`:

```javascript
// Example: If your joystick topic uses custom message type
function parseCustomJoyMessage(message) {
  return {
    joystickX: message.x_axis ?? 0,
    joystickY: message.y_axis ?? 0,
    joystickButtons: message.button_states ?? Array(8).fill(0),
    joystickAxes: [
      message.x_axis ?? 0,
      message.y_axis ?? 0,
      message.z_axis ?? 0,
      // ... more axes
    ],
  };
}
```

### Step 4: Test with Real Data

```bash
# Verify your topics are publishing
ros2 topic echo /your_joystick_topic

# Start bridge with your topics
node ros2-bridge-enhanced.mjs --port 9090

# Check bridge output for parsing errors
# If you see "Error parsing Joy message", update the parser

# Start dashboard and configure with rover IP
```

---

## Troubleshooting

### Issue: "ROS 2 not found"

```bash
# Solution: Source ROS 2 before running bridge
source /opt/ros/humble/setup.bash
node ros2-bridge-enhanced.mjs
```

### Issue: Bridge connects but no data updates

```bash
# Check if topics are publishing
ros2 topic list

# If topics don't exist, start publishers
ros2 run rover_telemetry joystick_pub

# Check topic frequency
ros2 topic hz /rover/joystick_input

# If frequency is 0, publishers aren't running
```

### Issue: Dashboard shows "Disconnected"

```bash
# Check bridge is running
ps aux | grep ros2-bridge

# Check port is accessible
nc -zv localhost 9090

# If connection refused, restart bridge
# Make sure ROS 2 is sourced first
source /opt/ros/humble/setup.bash
node ros2-bridge-enhanced.mjs
```

### Issue: Joystick data not updating

```bash
# Verify topic is publishing
ros2 topic echo /rover/joystick_input

# Check message format matches parser
# If message fields are different, update parseJoyMessage()

# Check bridge logs for parsing errors
# Look for "[Parser] Error parsing Joy message"

# Verify dashboard is connected
# Check browser console (F12) for WebSocket errors
```

### Issue: Network metrics all zeros

```bash
# Check network health topic
ros2 topic echo /rover/network_health

# Verify message format
ros2 msg show std_msgs/Float32MultiArray

# If format is different, update parseNetworkHealthMessage()
```

---

## Performance Optimization

### Reduce Update Frequency

If dashboard is consuming too much CPU:

```bash
# Reduce publisher frequency in your nodes
# Change timer from 0.1s (10 Hz) to 0.2s (5 Hz)

# Or configure QoS in bridge
# Edit ros2-bridge-enhanced.mjs line 24
const TOPICS = {
  networkHealth: `/rover/network_health`,  // 1 Hz is fine
  joystickInput: `/rover/joystick_input`,  // 10 Hz recommended
  systemStatus: `/rover/system_status`,    // 0.5 Hz is fine
};
```

### Network Optimization

For wireless connections:

```bash
# Reduce WebSocket message size by filtering data
# Only send changed values instead of full state

# Or increase update interval
# Change from 100ms to 200ms for joystick
```

---

## Next Steps

1. **Integrate Real Joystick**: Replace simulated joystick with actual USB joystick
   ```bash
   ros2 run joy joy_node --ros-args -p dev:="/dev/input/js0"
   ```

2. **Add More Metrics**: Extend dashboard to show battery, temperature, etc.

3. **Implement Recording**: Log all telemetry data for post-mission analysis

4. **Add Alerts**: Implement audio/visual alerts for critical conditions

5. **Mobile Support**: Adapt dashboard for mobile operator devices

---

## Resources

- [ROS 2 Documentation](https://docs.ros.org/en/humble/)
- [sensor_msgs/Joy](https://docs.ros2.org/latest/api/sensor_msgs/msg/Joy.html)
- [ROS 2 Python Tutorial](https://docs.ros.org/en/humble/Tutorials/Beginner-Client-Libraries/Writing-A-Simple-Py-Publisher-And-Subscriber.html)
- [WebSocket API](https://developer.mozilla.org/en-US/docs/Web/API/WebSocket)

---

**Good luck with your rover! 🤖**
