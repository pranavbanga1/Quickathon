import { useState, useEffect } from "react";
import { Settings as SettingsIcon } from "lucide-react";
import JoystickRadar from "@/components/JoystickRadar";
import GamepadOverlay from "@/components/GamepadOverlay";
import ControllerVisualization from "@/components/ControllerVisualization";
import StatCard from "@/components/StatCard";
import AnalogView from "@/components/AnalogView";
import Settings, { ROS2Config } from "@/components/Settings";
import { useROS2Connection } from "@/hooks/useROS2Connection";

interface DashboardData {
  latency: number;
  packetLoss: number;
  signalStrength: number;
  systemStatus: string;
  joystickX: number;
  joystickY: number;
  joystickButtons: number[];
  joystickAxes: number[];
  txThroughput: number;
  rxThroughput: number;
  networkHistory: Array<{ tx: number; rx: number; timestamp: number }>;
}

export default function Home() {
  const [settingsOpen, setSettingsOpen] = useState(false);
  
  const defaultConfig: ROS2Config = {
    rosIP: "localhost",
    rosPort: 9090,
    rosNamespace: "/rover",
    autoConnect: true,
    dataMode: "simulator",
  };
  
  const [config, setConfig] = useState<ROS2Config>(defaultConfig);

  const [data, setData] = useState<DashboardData>({
    latency: 36.4,
    packetLoss: 0.05,
    signalStrength: -74,
    systemStatus: "GOOD",
    joystickX: -0.29,
    joystickY: -0.45,
    joystickButtons: Array(8).fill(0),
    joystickAxes: Array(6).fill(0),
    txThroughput: 45.3,
    rxThroughput: 64.4,
    networkHistory: [],
  });

  const [time, setTime] = useState<string>("");
  const [useSimulation, setUseSimulation] = useState(true);
  const [viewMode, setViewMode] = useState<"gamepad" | "controller">("controller");

  // Load config from localStorage on mount
  useEffect(() => {
    const saved = localStorage.getItem("ros2Config");
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        setConfig(parsed);
      } catch (e) {
        console.error("Failed to load config:", e);
      }
    }
  }, []);

  // ROS 2 connection
  const { data: rosData, state: connectionState } = useROS2Connection({
    ip: config.rosIP,
    port: config.rosPort,
    namespace: config.rosNamespace,
    autoConnect: config.autoConnect,
  });

  // Update dashboard data from ROS
  useEffect(() => {
    if (rosData) {
      setData((prev) => ({
        ...prev,
        latency: rosData.latency || prev.latency,
        packetLoss: rosData.packetLoss || prev.packetLoss,
        signalStrength: rosData.signalStrength || prev.signalStrength,
        systemStatus: rosData.systemStatus || prev.systemStatus,
        joystickX: rosData.joystickX || prev.joystickX,
        joystickY: rosData.joystickY || prev.joystickY,
        joystickAxes: rosData.joystickAxes || prev.joystickAxes,
        joystickButtons: rosData.joystickButtons || prev.joystickButtons,
        txThroughput: rosData.txThroughput || prev.txThroughput,
        rxThroughput: rosData.rxThroughput || prev.rxThroughput,
      }));
    }
  }, [rosData]);

  // Update time
  useEffect(() => {
    const timer = setInterval(() => {
      const now = new Date();
      setTime(now.toLocaleTimeString());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const handleSettingsSave = (newConfig: ROS2Config) => {
    setConfig(newConfig);
  };

  return (
    <div className="min-h-screen bg-background text-foreground p-4 md:p-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="w-3 h-3 rounded-full bg-cyan-400 glow-cyan"></div>
          <h1 className="text-2xl md:text-3xl font-bold glow-cyan">Rover Dashboard</h1>
        </div>
        <div className="flex items-center gap-4">
          <div className="text-sm font-mono text-muted-foreground">{time}</div>
          <div className="flex items-center gap-2 px-3 py-1 rounded-lg border border-border/50 bg-background/50">
            <div className="w-2 h-2 rounded-full bg-cyan-400"></div>
            <span className="text-xs font-semibold">LTE</span>
          </div>
          <button
            onClick={() => setSettingsOpen(true)}
            className="p-2 hover:bg-accent/20 rounded-lg transition-colors"
            title="Settings"
          >
            <SettingsIcon size={20} className="text-cyan-400" />
          </button>
        </div>
      </div>

      {/* Mode Indicator */}
      {config.dataMode === "simulator" && (
        <div className="mb-6 p-4 rounded-lg bg-yellow-900/20 border border-yellow-700/50 text-yellow-200 text-sm">
          <strong>🐍 Running in simulation mode.</strong> Configure ROS 2 connection in settings to use real rover data.
        </div>
      )}

      {/* Settings Modal */}
      <Settings
        isOpen={settingsOpen}
        onClose={() => setSettingsOpen(false)}
        onSave={handleSettingsSave}
      />

      {/* View Mode Toggle */}
      <div className="mb-6 flex gap-2">
        <button
          onClick={() => setViewMode("gamepad")}
          className={`px-4 py-2 rounded-lg font-semibold text-sm transition-colors ${
            viewMode === "gamepad"
              ? "bg-cyan-400/20 border border-cyan-400 text-cyan-400"
              : "bg-background/50 border border-border text-muted-foreground hover:border-cyan-400/50"
          }`}
        >
          🎮 Gamepad View
        </button>
        <button
          onClick={() => setViewMode("controller")}
          className={`px-4 py-2 rounded-lg font-semibold text-sm transition-colors ${
            viewMode === "controller"
              ? "bg-cyan-400/20 border border-cyan-400 text-cyan-400"
              : "bg-background/50 border border-border text-muted-foreground hover:border-cyan-400/50"
          }`}
        >
          📡 Radar View
        </button>
      </div>

      {/* Main Dashboard Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Panel - Joystick Visualization */}
        <div className="lg:col-span-1">
          <div className="sci-fi-border rounded-2xl p-6 bg-card/50 backdrop-blur-sm h-full">
            {viewMode === "gamepad" ? (
              <GamepadOverlay
                axes={data.joystickAxes}
                buttons={data.joystickButtons}
                isConnected={connectionState === "connected" || config.dataMode === "simulator"}
              />
            ) : (
              <AnalogView
                joystickX={data.joystickX}
                joystickY={data.joystickY}
                joystickAxes={data.joystickAxes}
                joystickButtons={data.joystickButtons}
              />
            )}
          </div>
        </div>

        {/* Right Panel - Stats and Chart */}
        <div className="lg:col-span-2 space-y-6">
          {/* Stat Cards Grid */}
          <div className="grid grid-cols-2 gap-4">
            <StatCard
              label="Latency"
              value={`${data.latency.toFixed(1)}`}
              unit="ms"
              icon="⚡"
              subtitle="Optimal range"
            />
            <StatCard
              label="System Status"
              value={data.systemStatus}
              icon="✓"
              status={data.systemStatus as "GOOD" | "WARNING" | "CRITICAL"}
            />
            <StatCard
              label="Packet Loss"
              value={`${data.packetLoss.toFixed(2)}`}
              unit="%"
              icon="📡"
            />
            <StatCard
              label="Signal Strength"
              value={`${data.signalStrength.toFixed(0)}`}
              unit="dBm"
              icon="📶"
            />
          </div>

          {/* Network Traffic Chart */}
          <div className="sci-fi-border rounded-2xl p-6 bg-card/50 backdrop-blur-sm">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-foreground">Network Traffic</h3>
              <span className="text-xs text-muted-foreground">Last updated: 1 sec ago</span>
            </div>
            <div className="flex items-end gap-8 mb-4">
              <div>
                <div className="text-sm text-muted-foreground mb-1">↑ TX</div>
                <div className="text-2xl font-bold text-cyan-400">
                  {data.txThroughput.toFixed(1)} <span className="text-sm">Mbps</span>
                </div>
              </div>
              <div>
                <div className="text-sm text-muted-foreground mb-1">↓ RX</div>
                <div className="text-2xl font-bold text-cyan-400">
                  {data.rxThroughput.toFixed(1)} <span className="text-sm">Mbps</span>
                </div>
              </div>
            </div>
            <svg className="w-full h-24" viewBox="0 0 400 100" preserveAspectRatio="none">
              <defs>
                <linearGradient id="txGradient" x1="0%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" style={{ stopColor: "#22D3EE", stopOpacity: 0.3 }} />
                  <stop offset="100%" style={{ stopColor: "#22D3EE", stopOpacity: 0 }} />
                </linearGradient>
                <linearGradient id="rxGradient" x1="0%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" style={{ stopColor: "#06B6D4", stopOpacity: 0.3 }} />
                  <stop offset="100%" style={{ stopColor: "#06B6D4", stopOpacity: 0 }} />
                </linearGradient>
              </defs>
              {/* TX Line */}
              <polyline
                points="0,60 50,50 100,55 150,45 200,50 250,40 300,45 350,35 400,40"
                fill="none"
                stroke="#22D3EE"
                strokeWidth="2"
              />
              {/* RX Line */}
              <polyline
                points="0,70 50,65 100,68 150,60 200,65 250,55 300,60 350,50 400,55"
                fill="none"
                stroke="#06B6D4"
                strokeWidth="2"
              />
              {/* Grid */}
              <line x1="0" y1="50" x2="400" y2="50" stroke="#0B1221" strokeWidth="1" strokeDasharray="5,5" />
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
}
