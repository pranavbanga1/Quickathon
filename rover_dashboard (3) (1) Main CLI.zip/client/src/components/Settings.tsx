import { useState, useEffect } from "react";
import { X, Save, RotateCcw } from "lucide-react";

interface SettingsProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (config: ROS2Config) => void;
}

export interface ROS2Config {
  rosIP: string;
  rosPort: number;
  rosNamespace: string;
  autoConnect: boolean;
  dataMode: "simulator" | "ros";
}

const DEFAULT_CONFIG: ROS2Config = {
  rosIP: "localhost",
  rosPort: 9090,
  rosNamespace: "/rover",
  autoConnect: true,
  dataMode: "simulator",
};

export default function Settings({ isOpen, onClose, onSave }: SettingsProps) {
  const [config, setConfig] = useState<ROS2Config>(DEFAULT_CONFIG);

  // Load saved config from localStorage on mount
  useEffect(() => {
    const saved = localStorage.getItem("ros2Config");
    if (saved) {
      try {
        setConfig(JSON.parse(saved));
      } catch (e) {
        console.error("Failed to load config:", e);
      }
    }
  }, [isOpen]);

  const handleSave = () => {
    localStorage.setItem("ros2Config", JSON.stringify(config));
    onSave(config);
    onClose();
  };

  const handleReset = () => {
    setConfig(DEFAULT_CONFIG);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="sci-fi-border rounded-2xl bg-card/95 backdrop-blur-sm max-w-md w-full p-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold glow-cyan">Configuration</h2>
          <button
            onClick={onClose}
            className="p-1 hover:bg-accent/20 rounded-lg transition-colors"
          >
            <X size={20} />
          </button>
        </div>

        {/* Form */}
        <div className="space-y-4 mb-6">
          {/* Data Source Mode */}
          <div>
            <label className="block text-sm font-semibold text-muted-foreground mb-2">
              Data Source Mode
            </label>
            <select
              value={config.dataMode}
              onChange={(e) =>
                setConfig({
                  ...config,
                  dataMode: e.target.value as "simulator" | "ros",
                })
              }
              className="w-full px-3 py-2 bg-background border border-border rounded-lg text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent/50"
            >
              <option value="simulator">🐍 Simulator Mode (Python CLI)</option>
              <option value="ros">🤖 ROS 2 Mode (Real Rover)</option>
            </select>
            <p className="text-xs text-muted-foreground mt-2">
              {config.dataMode === "simulator"
                ? "Use Python CLI to update dashboard values in real-time. No ROS required."
                : "Connect to real ROS 2 topics on rover. Requires ROS 2 setup."}
            </p>
          </div>

          {/* ROS IP */}
          <div>
            <label className="block text-sm font-semibold text-muted-foreground mb-2">
              Bridge IP
            </label>
            <input
              type="text"
              value={config.rosIP}
              onChange={(e) =>
                setConfig({ ...config, rosIP: e.target.value })
              }
              placeholder="localhost or 192.168.x.x"
              className="w-full px-3 py-2 bg-background border border-border rounded-lg text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent/50"
            />
          </div>

          {/* ROS Port */}
          <div>
            <label className="block text-sm font-semibold text-muted-foreground mb-2">
              Bridge Port
            </label>
            <input
              type="number"
              value={config.rosPort}
              onChange={(e) =>
                setConfig({ ...config, rosPort: parseInt(e.target.value) })
              }
              placeholder="9090"
              className="w-full px-3 py-2 bg-background border border-border rounded-lg text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent/50"
            />
          </div>

          {/* ROS Namespace */}
          <div>
            <label className="block text-sm font-semibold text-muted-foreground mb-2">
              ROS Namespace
            </label>
            <input
              type="text"
              value={config.rosNamespace}
              onChange={(e) =>
                setConfig({ ...config, rosNamespace: e.target.value })
              }
              placeholder="/rover"
              className="w-full px-3 py-2 bg-background border border-border rounded-lg text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent/50"
            />
          </div>

          {/* Auto Connect */}
          <div className="flex items-center gap-3">
            <input
              type="checkbox"
              id="autoConnect"
              checked={config.autoConnect}
              onChange={(e) =>
                setConfig({ ...config, autoConnect: e.target.checked })
              }
              className="w-4 h-4 rounded border-border bg-background cursor-pointer"
            />
            <label
              htmlFor="autoConnect"
              className="text-sm font-semibold text-muted-foreground cursor-pointer"
            >
              Auto-connect on startup
            </label>
          </div>
        </div>

        {/* Info Box */}
        <div className="bg-background/50 border border-border/50 rounded-lg p-3 mb-6">
          <p className="text-xs text-muted-foreground">
            {config.dataMode === "simulator" ? (
              <>
                <strong>Simulator Mode:</strong> Run Python CLI to update values
                in real-time. Perfect for demos and testing.
              </>
            ) : (
              <>
                <strong>ROS 2 Mode:</strong> Connect to real rover topics. Ensure
                ROS 2 is running on the bridge IP.
              </>
            )}
          </p>
        </div>

        {/* Buttons */}
        <div className="flex gap-3">
          <button
            onClick={handleReset}
            className="flex-1 px-4 py-2 rounded-lg border border-border text-muted-foreground hover:bg-accent/10 transition-colors flex items-center justify-center gap-2"
          >
            <RotateCcw size={16} />
            Reset
          </button>
          <button
            onClick={handleSave}
            className="flex-1 px-4 py-2 rounded-lg bg-cyan-400/20 border border-cyan-400 text-cyan-400 hover:bg-cyan-400/30 transition-colors flex items-center justify-center gap-2 font-semibold"
          >
            <Save size={16} />
            Save
          </button>
        </div>
      </div>
    </div>
  );
}
