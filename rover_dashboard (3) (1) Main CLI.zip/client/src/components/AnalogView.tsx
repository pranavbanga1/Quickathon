import { useRef, useEffect } from "react";

interface AnalogViewProps {
  joystickX: number;
  joystickY: number;
  joystickAxes: number[];
  joystickButtons: number[];
  isConnected?: boolean;
}

export default function AnalogView({
  joystickX,
  joystickY,
  joystickAxes,
  joystickButtons,
  isConnected = true,
}: AnalogViewProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;

    // Clear canvas
    ctx.fillStyle = "rgba(11, 18, 33, 0.5)";
    ctx.fillRect(0, 0, width, height);

    // Draw grid background
    ctx.strokeStyle = "rgba(34, 211, 238, 0.1)";
    ctx.lineWidth = 1;
    const gridSize = 40;
    for (let i = 0; i <= width; i += gridSize) {
      ctx.beginPath();
      ctx.moveTo(i, 0);
      ctx.lineTo(i, height);
      ctx.stroke();
    }
    for (let i = 0; i <= height; i += gridSize) {
      ctx.beginPath();
      ctx.moveTo(0, i);
      ctx.lineTo(width, i);
      ctx.stroke();
    }

    // Draw concentric circles
    ctx.strokeStyle = "rgba(34, 211, 238, 0.3)";
    ctx.lineWidth = 1.5;
    const centerX = width / 2;
    const centerY = height / 2;
    const maxRadius = Math.min(width, height) / 2 - 20;

    for (let i = 1; i <= 4; i++) {
      const radius = (maxRadius / 4) * i;
      ctx.beginPath();
      ctx.arc(centerX, centerY, radius, 0, Math.PI * 2);
      ctx.stroke();
    }

    // Draw crosshairs
    ctx.strokeStyle = "rgba(34, 211, 238, 0.5)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(centerX, centerY - maxRadius - 10);
    ctx.lineTo(centerX, centerY + maxRadius + 10);
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(centerX - maxRadius - 10, centerY);
    ctx.lineTo(centerX + maxRadius + 10, centerY);
    ctx.stroke();

    // Draw directional labels
    ctx.fillStyle = "rgba(34, 211, 238, 0.6)";
    ctx.font = "12px monospace";
    ctx.textAlign = "center";
    ctx.fillText("FWD", centerX, 20);
    ctx.fillText("REV", centerX, height - 10);
    ctx.textAlign = "right";
    ctx.fillText("LEFT", 20, centerY + 5);
    ctx.textAlign = "left";
    ctx.fillText("RIGHT", width - 20, centerY + 5);

    // Draw joystick position indicator
    const indicatorX = centerX + joystickX * maxRadius * 0.8;
    const indicatorY = centerY + joystickY * maxRadius * 0.8;

    // Glow effect
    ctx.shadowColor = "rgba(34, 211, 238, 0.8)";
    ctx.shadowBlur = 20;
    ctx.fillStyle = "rgba(34, 211, 238, 0.3)";
    ctx.beginPath();
    ctx.arc(indicatorX, indicatorY, 15, 0, Math.PI * 2);
    ctx.fill();

    // Main indicator
    ctx.shadowColor = "rgba(34, 211, 238, 1)";
    ctx.shadowBlur = 30;
    ctx.fillStyle = "rgba(34, 211, 238, 0.9)";
    ctx.beginPath();
    ctx.arc(indicatorX, indicatorY, 8, 0, Math.PI * 2);
    ctx.fill();

    // Center dot
    ctx.shadowColor = "rgba(100, 100, 100, 0.5)";
    ctx.shadowBlur = 5;
    ctx.fillStyle = "rgba(100, 100, 100, 0.6)";
    ctx.beginPath();
    ctx.arc(centerX, centerY, 3, 0, Math.PI * 2);
    ctx.fill();

    ctx.shadowColor = "transparent";
  }, [joystickX, joystickY]);

  return (
    <div className="space-y-6">
      {/* Radar Canvas */}
      <div>
        <canvas
          ref={canvasRef}
          width={300}
          height={300}
          className="w-full border border-cyan-400/30 rounded-lg bg-background/50"
        />
      </div>

      {/* Joystick Coordinates */}
      <div className="text-center">
        <div className="text-sm font-mono text-muted-foreground mb-2">JOYSTICK INPUT</div>
        <div className="text-cyan-400 font-mono font-bold">
          X: {joystickX.toFixed(2)} | Y: {joystickY.toFixed(2)}
        </div>
      </div>

      {/* Analog Sticks Readout */}
      <div className="grid grid-cols-2 gap-4 text-sm">
        <div>
          <div className="text-muted-foreground mb-2">Left Stick</div>
          <div className="font-mono text-cyan-400">
            X: {joystickAxes[0]?.toFixed(2) || "0.00"}
            <br />
            Y: {joystickAxes[1]?.toFixed(2) || "0.00"}
          </div>
        </div>
        <div>
          <div className="text-muted-foreground mb-2">Right Stick</div>
          <div className="font-mono text-cyan-400">
            X: {joystickAxes[3]?.toFixed(2) || "0.00"}
            <br />
            Y: {joystickAxes[4]?.toFixed(2) || "0.00"}
          </div>
        </div>
      </div>

      {/* Triggers */}
      <div className="grid grid-cols-2 gap-4 text-sm">
        <div>
          <div className="text-muted-foreground mb-2">LT Trigger</div>
          <div className="font-mono text-cyan-400">{joystickAxes[2]?.toFixed(2) || "0.00"}</div>
        </div>
        <div>
          <div className="text-muted-foreground mb-2">RT Trigger</div>
          <div className="font-mono text-cyan-400">{joystickAxes[5]?.toFixed(2) || "0.00"}</div>
        </div>
      </div>

      {/* Buttons */}
      <div>
        <div className="text-sm text-muted-foreground mb-2">BUTTONS</div>
        <div className="grid grid-cols-5 gap-2">
          {["A", "B", "X", "Y", "LB", "RB", "Back", "Start", "LS", "RS"].map((label, idx) => (
            <div
              key={idx}
              className={`px-2 py-1 rounded text-xs font-semibold text-center transition-colors ${
                joystickButtons[idx]
                  ? "bg-cyan-400/50 text-cyan-400 border border-cyan-400"
                  : "bg-background/50 text-muted-foreground border border-border"
              }`}
            >
              {label}
            </div>
          ))}
        </div>
      </div>

      {/* Connection Status */}
      <div className="flex items-center gap-2 text-sm">
        <div className={`w-2 h-2 rounded-full ${isConnected ? "bg-green-400" : "bg-red-400"}`}></div>
        <span className={isConnected ? "text-green-400" : "text-red-400"}>
          {isConnected ? "Controller Connected" : "Controller Disconnected"}
        </span>
      </div>
    </div>
  );
}
