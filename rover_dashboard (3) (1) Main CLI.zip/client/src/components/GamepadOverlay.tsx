import { useEffect, useRef } from "react";

interface GamepadOverlayProps {
  axes: number[];
  buttons: number[];
  isConnected?: boolean;
}

/**
 * Realistic gamepad controller overlay component
 * Mirrors physical joystick input in real-time
 * 
 * Axis mapping (standard Xbox/Joy):
 * - axes[0]: Left stick X (-1 left, 1 right)
 * - axes[1]: Left stick Y (-1 up, 1 down)
 * - axes[2]: LT trigger (-1 released, 1 pressed)
 * - axes[3]: Right stick X (-1 left, 1 right)
 * - axes[4]: Right stick Y (-1 up, 1 down)
 * - axes[5]: RT trigger (-1 released, 1 pressed)
 * 
 * Button mapping:
 * - buttons[0]: A
 * - buttons[1]: B
 * - buttons[2]: X
 * - buttons[3]: Y
 * - buttons[4]: LB
 * - buttons[5]: RB
 * - buttons[6]: Back
 * - buttons[7]: Start
 * - buttons[8]: Left stick click
 * - buttons[9]: Right stick click
 */
export default function GamepadOverlay({
  axes = Array(6).fill(0),
  buttons = Array(10).fill(0),
  isConnected = true,
}: GamepadOverlayProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;

    // Clear canvas
    ctx.fillStyle = "rgba(11, 18, 33, 0.3)";
    ctx.fillRect(0, 0, width, height);

    // Draw gamepad body
    drawGamepadBody(ctx, width, height);

    // Draw left stick
    drawLeftStick(ctx, width, height, axes[0] ?? 0, axes[1] ?? 0);

    // Draw right stick
    drawRightStick(ctx, width, height, axes[3] ?? 0, axes[4] ?? 0);

    // Draw face buttons (A, B, X, Y)
    drawFaceButtons(ctx, width, height, buttons);

    // Draw bumpers (LB, RB)
    drawBumpers(ctx, width, height, buttons);

    // Draw triggers (LT, RT)
    drawTriggers(ctx, width, height, axes);

    // Draw center buttons (Back, Start)
    drawCenterButtons(ctx, width, height, buttons);
  }, [axes, buttons]);

  return (
    <div className="space-y-4">
      {/* Canvas visualization */}
      <div className="relative flex justify-center">
        <canvas
          ref={canvasRef}
          width={480}
          height={300}
          className="w-full border border-cyan-400/30 rounded-lg bg-background/50"
        />
      </div>

      {/* Joystick values */}
      <div className="grid grid-cols-2 gap-3">
        <div className="bg-background/50 border border-border rounded p-3">
          <div className="text-muted-foreground text-xs font-semibold">
            LEFT STICK
          </div>
          <div className="text-cyan-400 font-mono text-sm mt-1">
            X: {(axes[0] ?? 0).toFixed(2)}
          </div>
          <div className="text-cyan-400 font-mono text-sm">
            Y: {(axes[1] ?? 0).toFixed(2)}
          </div>
        </div>
        <div className="bg-background/50 border border-border rounded p-3">
          <div className="text-muted-foreground text-xs font-semibold">
            RIGHT STICK
          </div>
          <div className="text-cyan-400 font-mono text-sm mt-1">
            X: {(axes[3] ?? 0).toFixed(2)}
          </div>
          <div className="text-cyan-400 font-mono text-sm">
            Y: {(axes[4] ?? 0).toFixed(2)}
          </div>
        </div>
      </div>

      {/* Buttons status */}
      <div className="space-y-2">
        <div className="text-xs font-semibold text-muted-foreground">
          BUTTONS PRESSED
        </div>
        <div className="grid grid-cols-5 gap-2">
          {["A", "B", "X", "Y", "LB", "RB", "Back", "Start", "LS", "RS"].map(
            (label, idx) => (
              <div
                key={idx}
                className={`py-1 px-2 rounded text-xs font-bold text-center transition-colors ${
                  buttons[idx]
                    ? "bg-green-500/30 border border-green-500 text-green-400"
                    : "bg-background/50 border border-border text-muted-foreground"
                }`}
              >
                {label}
              </div>
            )
          )}
        </div>
      </div>

      {/* Connection status */}
      <div className="flex items-center gap-2 text-xs">
        <div
          className={`w-2 h-2 rounded-full ${
            isConnected ? "bg-green-400" : "bg-red-400"
          }`}
        />
        <span className={isConnected ? "text-green-400" : "text-red-400"}>
          {isConnected ? "Joystick Connected" : "No Joystick"}
        </span>
      </div>
    </div>
  );
}

// ============= Drawing Functions =============

function drawGamepadBody(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number
) {
  const centerX = width / 2;
  const centerY = height / 2;

  // Draw rounded rectangle for gamepad body
  const radius = 30;
  const bodyWidth = width * 0.8;
  const bodyHeight = height * 0.8;
  const x = (width - bodyWidth) / 2;
  const y = (height - bodyHeight) / 2;

  // Gradient for body
  const gradient = ctx.createLinearGradient(x, y, x, y + bodyHeight);
  gradient.addColorStop(0, "rgba(30, 50, 80, 0.4)");
  gradient.addColorStop(1, "rgba(15, 25, 45, 0.4)");

  ctx.fillStyle = gradient;
  ctx.strokeStyle = "rgba(34, 211, 238, 0.3)";
  ctx.lineWidth = 2;

  // Rounded rectangle
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.lineTo(x + bodyWidth - radius, y);
  ctx.quadraticCurveTo(x + bodyWidth, y, x + bodyWidth, y + radius);
  ctx.lineTo(x + bodyWidth, y + bodyHeight - radius);
  ctx.quadraticCurveTo(
    x + bodyWidth,
    y + bodyHeight,
    x + bodyWidth - radius,
    y + bodyHeight
  );
  ctx.lineTo(x + radius, y + bodyHeight);
  ctx.quadraticCurveTo(x, y + bodyHeight, x, y + bodyHeight - radius);
  ctx.lineTo(x, y + radius);
  ctx.quadraticCurveTo(x, y, x + radius, y);
  ctx.closePath();

  ctx.fill();
  ctx.stroke();
}

function drawLeftStick(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  x: number,
  y: number
) {
  const stickX = width * 0.25;
  const stickY = height * 0.65;
  const stickRadius = 25;
  const maxOffset = 18;

  // Stick background circle
  ctx.fillStyle = "rgba(20, 35, 60, 0.6)";
  ctx.strokeStyle = "rgba(34, 211, 238, 0.3)";
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(stickX, stickY, stickRadius, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();

  // Stick position indicator
  const offsetX = x * maxOffset;
  const offsetY = y * maxOffset;

  // Glow effect
  const glowGradient = ctx.createRadialGradient(
    stickX + offsetX,
    stickY + offsetY,
    0,
    stickX + offsetX,
    stickY + offsetY,
    12
  );
  glowGradient.addColorStop(0, "rgba(34, 211, 238, 0.8)");
  glowGradient.addColorStop(0.7, "rgba(34, 211, 238, 0.3)");
  glowGradient.addColorStop(1, "rgba(34, 211, 238, 0)");

  ctx.fillStyle = glowGradient;
  ctx.beginPath();
  ctx.arc(stickX + offsetX, stickY + offsetY, 12, 0, Math.PI * 2);
  ctx.fill();

  // Stick dot
  ctx.fillStyle = "#22D3EE";
  ctx.beginPath();
  ctx.arc(stickX + offsetX, stickY + offsetY, 6, 0, Math.PI * 2);
  ctx.fill();

  // Label
  ctx.fillStyle = "rgba(148, 163, 184, 0.6)";
  ctx.font = "11px monospace";
  ctx.textAlign = "center";
  ctx.fillText("L", stickX, stickY + stickRadius + 18);
}

function drawRightStick(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  x: number,
  y: number
) {
  const stickX = width * 0.75;
  const stickY = height * 0.65;
  const stickRadius = 25;
  const maxOffset = 18;

  // Stick background circle
  ctx.fillStyle = "rgba(20, 35, 60, 0.6)";
  ctx.strokeStyle = "rgba(34, 211, 238, 0.3)";
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(stickX, stickY, stickRadius, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();

  // Stick position indicator
  const offsetX = x * maxOffset;
  const offsetY = y * maxOffset;

  // Glow effect
  const glowGradient = ctx.createRadialGradient(
    stickX + offsetX,
    stickY + offsetY,
    0,
    stickX + offsetX,
    stickY + offsetY,
    12
  );
  glowGradient.addColorStop(0, "rgba(34, 211, 238, 0.8)");
  glowGradient.addColorStop(0.7, "rgba(34, 211, 238, 0.3)");
  glowGradient.addColorStop(1, "rgba(34, 211, 238, 0)");

  ctx.fillStyle = glowGradient;
  ctx.beginPath();
  ctx.arc(stickX + offsetX, stickY + offsetY, 12, 0, Math.PI * 2);
  ctx.fill();

  // Stick dot
  ctx.fillStyle = "#22D3EE";
  ctx.beginPath();
  ctx.arc(stickX + offsetX, stickY + offsetY, 6, 0, Math.PI * 2);
  ctx.fill();

  // Label
  ctx.fillStyle = "rgba(148, 163, 184, 0.6)";
  ctx.font = "11px monospace";
  ctx.textAlign = "center";
  ctx.fillText("R", stickX, stickY + stickRadius + 18);
}

function drawFaceButtons(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  buttons: number[]
) {
  const centerX = width * 0.75;
  const centerY = height * 0.35;
  const buttonRadius = 12;
  const spacing = 28;

  // Button positions (diamond layout)
  const buttonPositions = [
    { x: centerX, y: centerY - spacing, label: "Y", color: "#FBBF24" }, // Yellow
    { x: centerX + spacing, y: centerY, label: "B", color: "#EF4444" }, // Red
    { x: centerX, y: centerY + spacing, label: "A", color: "#10B981" }, // Green
    { x: centerX - spacing, y: centerY, label: "X", color: "#3B82F6" }, // Blue
  ];

  buttonPositions.forEach((btn, idx) => {
    const isPressed = buttons[idx] === 1;

    // Button background
    ctx.fillStyle = isPressed
      ? `${btn.color}40`
      : "rgba(20, 35, 60, 0.5)";
    ctx.strokeStyle = isPressed ? btn.color : "rgba(34, 211, 238, 0.2)";
    ctx.lineWidth = isPressed ? 2.5 : 1.5;

    ctx.beginPath();
    ctx.arc(btn.x, btn.y, buttonRadius, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    // Button label
    ctx.fillStyle = isPressed ? btn.color : "rgba(148, 163, 184, 0.6)";
    ctx.font = "bold 12px sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(btn.label, btn.x, btn.y);
  });
}

function drawBumpers(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  buttons: number[]
) {
  const topY = height * 0.12;
  const leftX = width * 0.2;
  const rightX = width * 0.8;
  const bumperWidth = 50;
  const bumperHeight = 16;

  // LB (button[4])
  drawBumper(
    ctx,
    leftX - bumperWidth / 2,
    topY,
    bumperWidth,
    bumperHeight,
    buttons[4] === 1,
    "LB"
  );

  // RB (button[5])
  drawBumper(
    ctx,
    rightX - bumperWidth / 2,
    topY,
    bumperWidth,
    bumperHeight,
    buttons[5] === 1,
    "RB"
  );
}

function drawBumper(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  width: number,
  height: number,
  isPressed: boolean,
  label: string
) {
  const radius = 6;

  ctx.fillStyle = isPressed
    ? "rgba(34, 211, 238, 0.4)"
    : "rgba(20, 35, 60, 0.4)";
  ctx.strokeStyle = isPressed
    ? "rgba(34, 211, 238, 0.8)"
    : "rgba(34, 211, 238, 0.2)";
  ctx.lineWidth = isPressed ? 2 : 1;

  // Rounded rectangle
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.lineTo(x + width - radius, y);
  ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
  ctx.lineTo(x + width, y + height - radius);
  ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
  ctx.lineTo(x + radius, y + height);
  ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
  ctx.lineTo(x, y + radius);
  ctx.quadraticCurveTo(x, y, x + radius, y);
  ctx.closePath();

  ctx.fill();
  ctx.stroke();

  // Label
  ctx.fillStyle = isPressed ? "#22D3EE" : "rgba(148, 163, 184, 0.5)";
  ctx.font = "9px monospace";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText(label, x + width / 2, y + height / 2);
}

function drawTriggers(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  axes: number[]
) {
  const topY = height * 0.08;
  const leftX = width * 0.15;
  const rightX = width * 0.85;
  const barWidth = 35;
  const barHeight = 12;

  // LT (axes[2])
  const ltValue = Math.max(0, (axes[2] ?? -1) + 1) / 2; // Convert from -1..1 to 0..1
  drawTriggerBar(ctx, leftX - barWidth / 2, topY, barWidth, barHeight, ltValue, "LT");

  // RT (axes[5])
  const rtValue = Math.max(0, (axes[5] ?? -1) + 1) / 2; // Convert from -1..1 to 0..1
  drawTriggerBar(ctx, rightX - barWidth / 2, topY, barWidth, barHeight, rtValue, "RT");
}

function drawTriggerBar(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  width: number,
  height: number,
  value: number,
  label: string
) {
  const radius = 4;

  // Background
  ctx.fillStyle = "rgba(20, 35, 60, 0.4)";
  ctx.strokeStyle = "rgba(34, 211, 238, 0.2)";
  ctx.lineWidth = 1;

  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.lineTo(x + width - radius, y);
  ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
  ctx.lineTo(x + width, y + height - radius);
  ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
  ctx.lineTo(x + radius, y + height);
  ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
  ctx.lineTo(x, y + radius);
  ctx.quadraticCurveTo(x, y, x + radius, y);
  ctx.closePath();

  ctx.fill();
  ctx.stroke();

  // Fill bar based on trigger value
  if (value > 0) {
    const fillWidth = width * value;
    ctx.fillStyle = "rgba(34, 211, 238, 0.6)";

    ctx.beginPath();
    ctx.moveTo(x + radius, y);
    ctx.lineTo(x + fillWidth - radius, y);
    ctx.quadraticCurveTo(x + fillWidth, y, x + fillWidth, y + radius);
    ctx.lineTo(x + fillWidth, y + height - radius);
    ctx.quadraticCurveTo(x + fillWidth, y + height, x + fillWidth - radius, y + height);
    ctx.lineTo(x + radius, y + height);
    ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
    ctx.lineTo(x, y + radius);
    ctx.quadraticCurveTo(x, y, x + radius, y);
    ctx.closePath();

    ctx.fill();
  }

  // Label
  ctx.fillStyle = "rgba(148, 163, 184, 0.5)";
  ctx.font = "8px monospace";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText(label, x + width / 2, y + height / 2);
}

function drawCenterButtons(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  buttons: number[]
) {
  const centerY = height * 0.35;
  const leftX = width * 0.35;
  const rightX = width * 0.65;
  const buttonWidth = 30;
  const buttonHeight = 12;

  // Back button (button[6])
  drawCenterButton(
    ctx,
    leftX - buttonWidth / 2,
    centerY,
    buttonWidth,
    buttonHeight,
    buttons[6] === 1,
    "Back"
  );

  // Start button (button[7])
  drawCenterButton(
    ctx,
    rightX - buttonWidth / 2,
    centerY,
    buttonWidth,
    buttonHeight,
    buttons[7] === 1,
    "Start"
  );
}

function drawCenterButton(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  width: number,
  height: number,
  isPressed: boolean,
  label: string
) {
  const radius = 4;

  ctx.fillStyle = isPressed
    ? "rgba(34, 211, 238, 0.3)"
    : "rgba(20, 35, 60, 0.3)";
  ctx.strokeStyle = isPressed
    ? "rgba(34, 211, 238, 0.6)"
    : "rgba(34, 211, 238, 0.15)";
  ctx.lineWidth = isPressed ? 1.5 : 1;

  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.lineTo(x + width - radius, y);
  ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
  ctx.lineTo(x + width, y + height - radius);
  ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
  ctx.lineTo(x + radius, y + height);
  ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
  ctx.lineTo(x, y + radius);
  ctx.quadraticCurveTo(x, y, x + radius, y);
  ctx.closePath();

  ctx.fill();
  ctx.stroke();

  ctx.fillStyle = isPressed ? "#22D3EE" : "rgba(148, 163, 184, 0.4)";
  ctx.font = "8px monospace";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText(label, x + width / 2, y + height / 2);
}
