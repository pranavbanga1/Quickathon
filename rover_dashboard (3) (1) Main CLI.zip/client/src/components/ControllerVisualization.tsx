import { useEffect, useRef } from "react";
import { Gamepad2 } from "lucide-react";

interface ControllerVisualizationProps {
  x: number;
  y: number;
  buttons?: number[];
  axes?: number[];
  isConnected?: boolean;
}

export default function ControllerVisualization({
  x,
  y,
  buttons = Array(8).fill(0),
  axes = Array(6).fill(0),
  isConnected = true,
}: ControllerVisualizationProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;

    // Clear canvas
    ctx.fillStyle = "rgba(11, 18, 33, 0.5)";
    ctx.fillRect(0, 0, width, height);

    // Draw grid background
    ctx.strokeStyle = "rgba(34, 211, 238, 0.1)";
    ctx.lineWidth = 1;
    const gridSize = 40;
    for (let i = 0; i <= width; i += gridSize) {
      ctx.beginPath();
      ctx.moveTo(i, 0);
      ctx.lineTo(i, height);
      ctx.stroke();
    }
    for (let i = 0; i <= height; i += gridSize) {
      ctx.beginPath();
      ctx.moveTo(0, i);
      ctx.lineTo(width, i);
      ctx.stroke();
    }

    // Draw center crosshair
    const centerX = width / 2;
    const centerY = height / 2;

    // Center circle
    ctx.fillStyle = "rgba(34, 211, 238, 0.2)";
    ctx.beginPath();
    ctx.arc(centerX, centerY, 8, 0, Math.PI * 2);
    ctx.fill();

    // Crosshair lines
    ctx.strokeStyle = "rgba(34, 211, 238, 0.3)";
    ctx.lineWidth = 1;
    ctx.setLineDash([5, 5]);
    ctx.beginPath();
    ctx.moveTo(0, centerY);
    ctx.lineTo(width, centerY);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(centerX, 0);
    ctx.lineTo(centerX, height);
    ctx.stroke();
    ctx.setLineDash([]);

    // Draw joystick position
    const maxRadius = Math.min(width, height) / 2 - 40;
    const joystickX = centerX + x * maxRadius;
    const joystickY = centerY + y * maxRadius;

    // Joystick trail (fading history)
    ctx.strokeStyle = "rgba(34, 211, 238, 0.2)";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(joystickX, joystickY, maxRadius * 0.7, 0, Math.PI * 2);
    ctx.stroke();

    // Joystick indicator
    const glowSize = 20;
    const gradient = ctx.createRadialGradient(
      joystickX,
      joystickY,
      0,
      joystickX,
      joystickY,
      glowSize
    );
    gradient.addColorStop(0, "rgba(34, 211, 238, 0.8)");
    gradient.addColorStop(0.5, "rgba(34, 211, 238, 0.4)");
    gradient.addColorStop(1, "rgba(34, 211, 238, 0)");

    ctx.fillStyle = gradient;
    ctx.beginPath();
    ctx.arc(joystickX, joystickY, glowSize, 0, Math.PI * 2);
    ctx.fill();

    // Joystick center dot
    ctx.fillStyle = "#22D3EE";
    ctx.beginPath();
    ctx.arc(joystickX, joystickY, 8, 0, Math.PI * 2);
    ctx.fill();

    // Draw axes labels
    ctx.fillStyle = "rgba(148, 163, 184, 0.6)";
    ctx.font = "12px monospace";
    ctx.textAlign = "center";
    ctx.fillText("FWD", centerX, 20);
    ctx.fillText("REV", centerX, height - 10);
    ctx.textAlign = "right";
    ctx.fillText("LEFT", 20, centerY + 5);
    ctx.textAlign = "left";
    ctx.fillText("RIGHT", width - 20, centerY + 5);

    // Draw coordinates
    ctx.fillStyle = "#22D3EE";
    ctx.font = "bold 14px monospace";
    ctx.textAlign = "center";
    ctx.fillText(`X: ${x.toFixed(2)}`, centerX, centerY - 60);
    ctx.fillText(`Y: ${y.toFixed(2)}`, centerX, centerY - 40);
  }, [x, y]);

  // Calculate button states
  const buttonLabels = ["A", "B", "X", "Y", "LB", "RB", "Back", "Start"];

  return (
    <div className="space-y-4">
      {/* Canvas visualization */}
      <div className="relative">
        <canvas
          ref={canvasRef}
          width={320}
          height={320}
          className="w-full border border-cyan-400/30 rounded-lg bg-background/50"
        />
      </div>

      {/* Joystick values */}
      <div className="grid grid-cols-2 gap-2 text-sm">
        <div className="bg-background/50 border border-border rounded p-2">
          <div className="text-muted-foreground text-xs">X Axis</div>
          <div className="text-cyan-400 font-mono font-bold">{x.toFixed(3)}</div>
        </div>
        <div className="bg-background/50 border border-border rounded p-2">
          <div className="text-muted-foreground text-xs">Y Axis</div>
          <div className="text-cyan-400 font-mono font-bold">{y.toFixed(3)}</div>
        </div>
      </div>

      {/* Buttons grid */}
      <div className="space-y-2">
        <div className="text-xs font-semibold text-muted-foreground">BUTTONS</div>
        <div className="grid grid-cols-4 gap-2">
          {buttons.map((pressed, idx) => (
            <button
              key={idx}
              disabled
              className={`py-2 rounded text-xs font-bold transition-colors ${
                pressed
                  ? "bg-green-500/30 border border-green-500 text-green-400"
                  : "bg-background/50 border border-border text-muted-foreground"
              }`}
            >
              {buttonLabels[idx] || idx}
            </button>
          ))}
        </div>
      </div>

      {/* Analog sticks */}
      {axes.length > 2 && (
        <div className="space-y-2">
          <div className="text-xs font-semibold text-muted-foreground">
            ANALOG STICKS
          </div>
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="bg-background/50 border border-border rounded p-2">
              <div className="text-muted-foreground">Left Stick</div>
              <div className="text-cyan-400 font-mono">
                X: {axes[0]?.toFixed(2) || "0.00"}
              </div>
              <div className="text-cyan-400 font-mono">
                Y: {axes[1]?.toFixed(2) || "0.00"}
              </div>
            </div>
            <div className="bg-background/50 border border-border rounded p-2">
              <div className="text-muted-foreground">Right Stick</div>
              <div className="text-cyan-400 font-mono">
                X: {axes[2]?.toFixed(2) || "0.00"}
              </div>
              <div className="text-cyan-400 font-mono">
                Y: {axes[3]?.toFixed(2) || "0.00"}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Connection status */}
      <div className="flex items-center gap-2 text-xs">
        <Gamepad2
          size={16}
          className={isConnected ? "text-green-400" : "text-red-400"}
        />
        <span className={isConnected ? "text-green-400" : "text-red-400"}>
          {isConnected ? "Controller Connected" : "No Controller"}
        </span>
      </div>
    </div>
  );
}
