#!/usr/bin/env python3

"""
Rover Dashboard Interactive Data Simulator

Real-time CLI for updating dashboard values without ROS.

Usage:
    python3 data_simulator_interactive.py --bridge-url http://localhost:9090

Commands:
    latency <value>      - Set latency in ms (e.g., latency 50)
    loss <value>         - Set packet loss in % (e.g., loss 0.2)
    signal <value>       - Set signal strength in dBm (e.g., signal -75)
    tx <value>           - Set TX throughput in Mbps (e.g., tx 60)
    rx <value>           - Set RX throughput in Mbps (e.g., rx 80)
    status <status>      - Set system status (GOOD/WARNING/CRITICAL)
    joystick <x> <y>     - Set joystick position (e.g., joystick 0.5 0.3)
    button <id> <state>  - Press button (e.g., button 0 1)
    simulate             - Run automatic simulation
    help                 - Show this help
    exit                 - Exit program
"""

import argparse
import json
import math
import random
import sys
import time
from dataclasses import dataclass, asdict
from typing import Optional

import requests


@dataclass
class DashboardState:
    """Current dashboard state"""
    latency: float = 40.0
    packetLoss: float = 0.05
    signalStrength: float = -75
    txThroughput: float = 50.0
    rxThroughput: float = 75.0
    systemStatus: str = "GOOD"
    joystickAxes: list = None
    joystickButtons: list = None

    def __post_init__(self):
        if self.joystickAxes is None:
            self.joystickAxes = [0.0] * 6
        if self.joystickButtons is None:
            self.joystickButtons = [0] * 10


class InteractiveSimulator:
    """Interactive CLI simulator"""

    def __init__(self, bridge_url: str):
        self.bridge_url = bridge_url
        self.state = DashboardState()
        self.running = True
        self.simulation_active = False
        self.time_elapsed = 0

    def send_data(self) -> bool:
        """Send current state to bridge"""
        try:
            payload = {
                "latency": round(self.state.latency, 1),
                "packetLoss": round(self.state.packetLoss, 2),
                "signalStrength": round(self.state.signalStrength, 0),
                "txThroughput": round(self.state.txThroughput, 1),
                "rxThroughput": round(self.state.rxThroughput, 1),
                "systemStatus": self.state.systemStatus,
                "joystickAxes": [round(x, 2) for x in self.state.joystickAxes],
                "joystickButtons": self.state.joystickButtons,
            }
            response = requests.post(
                f"{self.bridge_url}/simulate",
                json=payload,
                timeout=2
            )
            return response.status_code == 200
        except Exception as e:
            print(f"[ERROR] Failed to send data: {e}")
            return False

    def update_simulation(self):
        """Update values for automatic simulation"""
        if not self.simulation_active:
            return

        t = self.time_elapsed * 0.3

        # Latency oscillation
        base_latency = 40.0
        oscillation = 10.0 * math.sin(t * 0.5)
        spike = random.gauss(0, 5) if random.random() < 0.1 else 0
        self.state.latency = max(10, base_latency + oscillation + spike)

        # Packet loss
        if random.random() < 0.95:
            self.state.packetLoss = random.gauss(0.05, 0.02)
        else:
            self.state.packetLoss = random.gauss(0.5, 0.3)
        self.state.packetLoss = max(0, min(5, self.state.packetLoss))

        # Signal strength
        self.state.signalStrength = -75 + random.gauss(0, 5)
        self.state.signalStrength = max(-90, min(-60, self.state.signalStrength))

        # Throughput
        self.state.txThroughput = 50 + random.gauss(0, 10)
        self.state.txThroughput = max(20, min(100, self.state.txThroughput))

        self.state.rxThroughput = 70 + random.gauss(0, 15)
        self.state.rxThroughput = max(40, min(120, self.state.rxThroughput))

        # Joystick
        self.state.joystickAxes[0] = 0.5 * math.sin(t)
        self.state.joystickAxes[1] = 0.5 * math.cos(t)

        # Status
        if self.state.latency > 100 or self.state.packetLoss > 1.0:
            self.state.systemStatus = "CRITICAL"
        elif self.state.latency > 60 or self.state.packetLoss > 0.5:
            self.state.systemStatus = "WARNING"
        else:
            self.state.systemStatus = "GOOD"

        self.time_elapsed += 0.05

    def handle_command(self, cmd: str):
        """Parse and execute CLI command"""
        parts = cmd.strip().split()
        if not parts:
            return

        command = parts[0].lower()

        try:
            if command == "latency" and len(parts) > 1:
                self.state.latency = float(parts[1])
                print(f"✓ Latency set to {self.state.latency} ms")

            elif command == "loss" and len(parts) > 1:
                self.state.packetLoss = float(parts[1])
                print(f"✓ Packet loss set to {self.state.packetLoss}%")

            elif command == "signal" and len(parts) > 1:
                self.state.signalStrength = float(parts[1])
                print(f"✓ Signal strength set to {self.state.signalStrength} dBm")

            elif command == "tx" and len(parts) > 1:
                self.state.txThroughput = float(parts[1])
                print(f"✓ TX throughput set to {self.state.txThroughput} Mbps")

            elif command == "rx" and len(parts) > 1:
                self.state.rxThroughput = float(parts[1])
                print(f"✓ RX throughput set to {self.state.rxThroughput} Mbps")

            elif command == "status" and len(parts) > 1:
                status = parts[1].upper()
                if status in ["GOOD", "WARNING", "CRITICAL"]:
                    self.state.systemStatus = status
                    print(f"✓ System status set to {status}")
                else:
                    print("[ERROR] Status must be GOOD, WARNING, or CRITICAL")

            elif command == "joystick" and len(parts) > 2:
                x = float(parts[1])
                y = float(parts[2])
                self.state.joystickAxes[0] = max(-1, min(1, x))
                self.state.joystickAxes[1] = max(-1, min(1, y))
                print(f"✓ Joystick set to X:{x}, Y:{y}")

            elif command == "button" and len(parts) > 2:
                btn_id = int(parts[1])
                state = int(parts[2])
                if 0 <= btn_id < 10:
                    self.state.joystickButtons[btn_id] = state
                    print(f"✓ Button {btn_id} set to {state}")
                else:
                    print("[ERROR] Button ID must be 0-9")

            elif command == "simulate":
                self.simulation_active = not self.simulation_active
                status = "started" if self.simulation_active else "stopped"
                print(f"✓ Automatic simulation {status}")

            elif command == "help":
                print(__doc__)

            elif command == "exit":
                self.running = False
                print("Goodbye!")

            elif command == "status":
                print(f"\n=== Current Dashboard State ===")
                print(f"Latency:        {self.state.latency:.1f} ms")
                print(f"Packet Loss:    {self.state.packetLoss:.2f}%")
                print(f"Signal:         {self.state.signalStrength:.0f} dBm")
                print(f"TX:             {self.state.txThroughput:.1f} Mbps")
                print(f"RX:             {self.state.rxThroughput:.1f} Mbps")
                print(f"System Status:  {self.state.systemStatus}")
                print(f"Joystick X:     {self.state.joystickAxes[0]:.2f}")
                print(f"Joystick Y:     {self.state.joystickAxes[1]:.2f}")
                print(f"Buttons:        {self.state.joystickButtons}")
                print()

            else:
                print(f"[ERROR] Unknown command: {command}. Type 'help' for commands.")

        except (ValueError, IndexError) as e:
            print(f"[ERROR] Invalid arguments: {e}")

    def run(self):
        """Main CLI loop"""
        print("=" * 60)
        print("🚀 Rover Dashboard Interactive Simulator")
        print("=" * 60)
        print(f"Bridge URL: {self.bridge_url}")
        print("Type 'help' for commands, 'exit' to quit")
        print("=" * 60)
        print()

        last_send = time.time()
        send_interval = 0.05  # Send every 50ms

        while self.running:
            try:
                # Update simulation if active
                if self.simulation_active:
                    self.update_simulation()

                # Send data periodically
                current_time = time.time()
                if current_time - last_send >= send_interval:
                    success = self.send_data()
                    if success:
                        print(f"✓ Data sent | Latency: {self.state.latency:.1f}ms | "
                              f"Loss: {self.state.packetLoss:.2f}% | "
                              f"Signal: {self.state.signalStrength:.0f}dBm | "
                              f"Status: {self.state.systemStatus}")
                    last_send = current_time

                # Read user input (non-blocking)
                try:
                    cmd = input(">>> ").strip()
                    if cmd:
                        self.handle_command(cmd)
                except EOFError:
                    break

            except KeyboardInterrupt:
                print("\n[STOP] Interrupted by user")
                break

        print("Simulator stopped.")


def main():
    parser = argparse.ArgumentParser(
        description="Rover Dashboard Interactive Simulator"
    )
    parser.add_argument(
        "--bridge-url",
        default="http://localhost:9090",
        help="Bridge server URL (default: http://localhost:9090)"
    )

    args = parser.parse_args()

    simulator = InteractiveSimulator(args.bridge_url)
    simulator.run()


if __name__ == "__main__":
    main()
