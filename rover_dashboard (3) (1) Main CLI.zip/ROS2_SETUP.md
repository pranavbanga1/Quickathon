# 🤖 Complete ROS 2 Integration Guide for Rover Dashboard

This guide walks you through setting up ROS 2, creating custom publishers for rover telemetry, and connecting everything to the dashboard in real-time.

## Table of Contents

1. [ROS 2 Installation](#ros-2-installation)
2. [Understanding ROS 2 Topics](#understanding-ros-2-topics)
3. [Creating Publisher Nodes](#creating-publisher-nodes)
4. [Connecting to Dashboard](#connecting-to-dashboard)
5. [Troubleshooting](#troubleshooting)

---

## ROS 2 Installation

### Prerequisites

- Ubuntu 20.04 or 22.04 (or VMware/WSL2)
- 4GB RAM minimum
- Internet connection

### Step 1: Set Up ROS 2 Repository

```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install required packages
sudo apt install -y curl gnupg lsb-release ubuntu-keyring

# Add ROS 2 GPG key
sudo curl -sSL https://repo.ros2.org/ros.key | sudo apt-key add -

# Add ROS 2 repository
sudo sh -c 'echo "deb [arch=$(dpkg --print-architecture)] http://packages.ros.org/ros2/ubuntu $(lsb_release -cs) main" > /etc/apt/sources.list.d/ros2-latest.list'

# Update package list
sudo apt update
```

### Step 2: Install ROS 2 Humble

```bash
# Install ROS 2 Humble (recommended for this project)
sudo apt install -y ros-humble-desktop

# Install development tools
sudo apt install -y ros-humble-ros2-control ros-humble-ros2-controllers

# Install Python development tools
sudo apt install -y python3-colcon-common-extensions python3-rosdep
```

### Step 3: Initialize ROS 2 Environment

```bash
# Source ROS 2 setup script
source /opt/ros/humble/setup.bash

# Add to ~/.bashrc for automatic sourcing
echo "source /opt/ros/humble/setup.bash" >> ~/.bashrc
source ~/.bashrc

# Verify installation
ros2 --version
# Should output: ROS 2 Humble Hawksbill
```

### Step 4: Set Up ROS 2 Workspace

```bash
# Create workspace directory
mkdir -p ~/rover_ws/src
cd ~/rover_ws

# Initialize workspace
colcon build

# Source workspace
source install/setup.bash

# Add to ~/.bashrc
echo "source ~/rover_ws/install/setup.bash" >> ~/.bashrc
```

---

## Understanding ROS 2 Topics

### What is a Topic?

A **topic** is a named channel for asynchronous communication between ROS 2 nodes. Publishers send data, subscribers receive it.

### Key Concepts

| Concept | Explanation |
|---------|-------------|
| **Topic** | Named communication channel (e.g., `/rover/joystick_input`) |
| **Message Type** | Data structure (e.g., `sensor_msgs/Joy`, `std_msgs/Float32`) |
| **Publisher** | Node that sends data to a topic |
| **Subscriber** | Node that receives data from a topic |
| **QoS** | Quality of Service (reliability, durability) |

### Common Message Types

```bash
# List all available message types
ros2 msg list | grep -E "(sensor_msgs|std_msgs|geometry_msgs)"

# Inspect a message type
ros2 msg show sensor_msgs/Joy
# Output:
# std_msgs/Header header
#   builtin_interfaces/Time stamp
#   string frame_id
# float32[] axes
# int32[] buttons
```

### Topics for Rover Dashboard

Your rover should publish to these topics:

| Topic | Message Type | Fields | Purpose |
|-------|--------------|--------|---------|
| `/rover/joystick_input` | `sensor_msgs/Joy` | `axes[]`, `buttons[]` | Real joystick input from operator |
| `/rover/network_health` | Custom or `std_msgs/Float32MultiArray` | `latency_ms`, `packet_loss_pct`, `signal_strength_dbm`, `tx_mbps`, `rx_mbps` | Network metrics |
| `/rover/system_status` | `std_msgs/String` | `data: "GOOD"\|"WARNING"\|"CRITICAL"` | Overall system health |

---

## Creating Publisher Nodes

### Option 1: Create a Python Publisher (Recommended for Testing)

#### Step 1: Create Package Structure

```bash
cd ~/rover_ws/src

# Create a new ROS 2 Python package
ros2 pkg create --build-type ament_python rover_telemetry

cd rover_telemetry
```

#### Step 2: Create Network Health Publisher

Create file: `rover_telemetry/network_health_publisher.py`

```python
#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32MultiArray
import random
import time

class NetworkHealthPublisher(Node):
    def __init__(self):
        super().__init__('network_health_publisher')
        
        # Create publisher
        self.publisher = self.create_publisher(
            Float32MultiArray,
            '/rover/network_health',
            10  # QoS history depth
        )
        
        # Create timer to publish every 1 second
        self.timer = self.create_timer(1.0, self.publish_data)
        self.get_logger().info('Network Health Publisher started')
    
    def publish_data(self):
        """Publish simulated network health data"""
        msg = Float32MultiArray()
        
        # Simulate network metrics
        # [latency_ms, packet_loss_pct, signal_strength_dbm, tx_mbps, rx_mbps]
        msg.data = [
            30.0 + random.random() * 20,      # latency_ms (30-50ms)
            max(0, random.random() * 0.2),    # packet_loss_pct (0-0.2%)
            -80.0 + random.random() * 15,     # signal_strength_dbm (-80 to -65)
            30.0 + random.random() * 40,      # tx_mbps
            40.0 + random.random() * 50,      # rx_mbps
        ]
        
        self.publisher.publish(msg)
        self.get_logger().debug(f'Published: latency={msg.data[0]:.1f}ms, '
                               f'loss={msg.data[1]:.2f}%, '
                               f'signal={msg.data[2]:.0f}dBm')

def main(args=None):
    rclpy.init(args=args)
    node = NetworkHealthPublisher()
    
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info('Shutting down...')
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
```

#### Step 3: Create Joystick Input Publisher

Create file: `rover_telemetry/joystick_publisher.py`

```python
#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Joy
import random

class JoystickPublisher(Node):
    def __init__(self):
        super().__init__('joystick_publisher')
        
        # Create publisher for sensor_msgs/Joy
        self.publisher = self.create_publisher(
            Joy,
            '/rover/joystick_input',
            10
        )
        
        # Create timer to publish every 100ms (10 Hz)
        self.timer = self.create_timer(0.1, self.publish_data)
        self.get_logger().info('Joystick Publisher started')
    
    def publish_data(self):
        """Publish simulated joystick input"""
        msg = Joy()
        
        # Simulate joystick axes (X, Y, Z, etc.)
        # axes[0] = X (left-right), axes[1] = Y (forward-backward)
        msg.axes = [
            (random.random() - 0.5) * 2,  # X: -1.0 to 1.0
            (random.random() - 0.5) * 2,  # Y: -1.0 to 1.0
            0.0,                           # Z (unused)
            0.0,                           # Throttle (unused)
        ]
        
        # Simulate buttons (0 = not pressed, 1 = pressed)
        msg.buttons = [0, 0, 0, 0, 0, 0, 0, 0]  # 8 buttons
        
        self.publisher.publish(msg)
        self.get_logger().debug(f'Published: X={msg.axes[0]:.2f}, Y={msg.axes[1]:.2f}')

def main(args=None):
    rclpy.init(args=args)
    node = JoystickPublisher()
    
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info('Shutting down...')
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
```

#### Step 4: Create System Status Publisher

Create file: `rover_telemetry/system_status_publisher.py`

```python
#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from std_msgs.msg import String
import random

class SystemStatusPublisher(Node):
    def __init__(self):
        super().__init__('system_status_publisher')
        
        self.publisher = self.create_publisher(
            String,
            '/rover/system_status',
            10
        )
        
        # Publish every 2 seconds
        self.timer = self.create_timer(2.0, self.publish_data)
        self.get_logger().info('System Status Publisher started')
    
    def publish_data(self):
        """Publish system status"""
        msg = String()
        
        # Randomly choose status (mostly GOOD)
        rand = random.random()
        if rand > 0.85:
            msg.data = 'CRITICAL'
        elif rand > 0.70:
            msg.data = 'WARNING'
        else:
            msg.data = 'GOOD'
        
        self.publisher.publish(msg)
        self.get_logger().info(f'Published status: {msg.data}')

def main(args=None):
    rclpy.init(args=args)
    node = SystemStatusPublisher()
    
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info('Shutting down...')
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
```

#### Step 5: Update Package Setup

Edit `setup.py`:

```python
from setuptools import setup

package_name = 'rover_telemetry'

setup(
    name=package_name,
    version='0.0.1',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Your Name',
    maintainer_email='your.email@example.com',
    description='Rover telemetry publishers',
    license='MIT',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'network_health_pub = rover_telemetry.network_health_publisher:main',
            'joystick_pub = rover_telemetry.joystick_publisher:main',
            'system_status_pub = rover_telemetry.system_status_publisher:main',
        ],
    },
)
```

#### Step 6: Build and Run

```bash
# Build the package
cd ~/rover_ws
colcon build

# Source the workspace
source install/setup.bash

# Run publishers in separate terminals
ros2 run rover_telemetry network_health_pub
ros2 run rover_telemetry joystick_pub
ros2 run rover_telemetry system_status_pub
```

### Option 2: Use Existing ROS 2 Joystick Driver

If you have a real USB joystick:

```bash
# Install joystick driver
sudo apt install -y ros-humble-joy

# List connected joysticks
ls /dev/input/js*

# Run joystick node
ros2 run joy joy_node --ros-args -p dev:="/dev/input/js0"

# Verify it's publishing
ros2 topic echo /joy
```

---

## Connecting to Dashboard

### Step 1: Verify Topics Are Publishing

```bash
# List all active topics
ros2 topic list

# Should show:
# /rover/joystick_input
# /rover/network_health
# /rover/system_status

# Echo a topic to see data
ros2 topic echo /rover/joystick_input

# Check message type
ros2 topic info /rover/joystick_input
```

### Step 2: Start ROS 2 Bridge

```bash
# Terminal 1: Start publishers
ros2 run rover_telemetry network_health_pub
ros2 run rover_telemetry joystick_pub
ros2 run rover_telemetry system_status_pub

# Terminal 2: Start WebSocket bridge
cd ~/rover_dashboard
node ros2-bridge.mjs --port 9090 --namespace /rover

# Output should show:
# 🚀 ROS 2 WebSocket Bridge started on ws://0.0.0.0:9090
# 📡 ROS Namespace: /rover
```

### Step 3: Start Dashboard

```bash
# Terminal 3: Start dashboard
cd ~/rover_dashboard
pnpm dev

# Open browser: http://localhost:3000
```

### Step 4: Configure Dashboard

1. Click **⚙️ Settings**
2. Enter IP: `localhost` (or your rover IP)
3. Port: `9090`
4. Click **Save**

✅ Dashboard should now show real joystick input and network metrics!

---

## Real-World Integration

### Connecting to Actual Rover Hardware

#### For TBot or Similar Rover:

```bash
# 1. SSH into rover
ssh ubuntu@rover_ip

# 2. Start your rover control nodes
ros2 launch your_rover_bringup.launch.py

# 3. Verify joystick topic
ros2 topic echo /joy

# 4. Start bridge on rover
node ros2-bridge.mjs --port 9090 --namespace /rover

# 5. On operator machine, configure dashboard with rover IP
# Settings → IP: rover_ip → Port: 9090
```

#### Custom Topic Mapping:

If your rover uses different topic names, edit `ros2-bridge.mjs`:

```javascript
// Line 28-32: Update topic names
const TOPICS = {
  networkHealth: `/your_rover_namespace/network_metrics`,
  joystickInput: `/your_rover_namespace/cmd_vel`,  // or /joy
  systemStatus: `/your_rover_namespace/diagnostics`,
};
```

---

## Troubleshooting

### Issue: "ROS 2 command not found"

```bash
# Solution: Source ROS 2 setup
source /opt/ros/humble/setup.bash

# Or add to ~/.bashrc
echo "source /opt/ros/humble/setup.bash" >> ~/.bashrc
```

### Issue: "Topic not found"

```bash
# Verify topic exists
ros2 topic list

# Check if publisher is running
ros2 topic info /rover/joystick_input

# Echo topic to see data
ros2 topic echo /rover/joystick_input
```

### Issue: Bridge won't connect to ROS 2

```bash
# Check ROS_DOMAIN_ID
echo $ROS_DOMAIN_ID  # Should be 0 or match your setup

# Verify ROS 2 installation
ros2 --version

# Check if topics are being published
ros2 topic list -t
```

### Issue: Dashboard shows "Disconnected"

```bash
# Check bridge is running
ps aux | grep ros2-bridge

# Check port is accessible
nc -zv localhost 9090

# Check firewall
sudo ufw allow 9090

# Restart bridge
node ros2-bridge.mjs
```

### Issue: Joystick not updating in dashboard

```bash
# Verify joystick topic is publishing
ros2 topic echo /rover/joystick_input

# Check message frequency
ros2 topic hz /rover/joystick_input

# Verify bridge is receiving data
# (Check console output of ros2-bridge.mjs)
```

---

## Testing Checklist

- [ ] ROS 2 installed and sourced
- [ ] Workspace created and built
- [ ] Publishers running and publishing data
- [ ] Topics visible with `ros2 topic list`
- [ ] Bridge started successfully
- [ ] Dashboard connects to bridge
- [ ] Joystick input updates in real-time
- [ ] Network metrics display correctly
- [ ] System status changes dynamically

---

## Next Steps

1. **Integrate with Real Rover**: Replace simulated publishers with actual rover telemetry nodes
2. **Add More Metrics**: Extend network health with battery level, temperature, etc.
3. **Create Launch File**: Combine all nodes into a single launch file
4. **Add Logging**: Record telemetry data for post-mission analysis
5. **Implement Safety Checks**: Add emergency stop and failsafe mechanisms

---

## Resources

- [ROS 2 Documentation](https://docs.ros.org/en/humble/)
- [ROS 2 Tutorials](https://docs.ros.org/en/humble/Tutorials.html)
- [sensor_msgs/Joy Documentation](https://docs.ros2.org/latest/api/sensor_msgs/msg/Joy.html)
- [ROS 2 Python Client Library](https://docs.ros.org/en/humble/Concepts/About-Client-Libraries.html)

---

**Happy ROS 2 development! 🚀**
