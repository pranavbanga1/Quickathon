#!/usr/bin/env node

/**
 * Enhanced ROS 2 WebSocket Bridge with Full Joy Message Support
 * 
 * This server bridges ROS 2 topics to WebSocket clients with proper handling of:
 * - sensor_msgs/Joy (joystick input with axes and buttons)
 * - Custom network health messages
 * - System status messages
 * 
 * Usage:
 *   node ros2-bridge-enhanced.mjs [--port 9090] [--namespace /rover]
 * 
 * Environment variables:
 *   ROS_DOMAIN_ID - ROS 2 domain ID (default: 0)
 *   BRIDGE_PORT - WebSocket port (default: 9090)
 *   ROS_NAMESPACE - ROS namespace (default: /rover)
 */

import WebSocket from 'ws';
import { createServer } from 'http';
import { spawn } from 'child_process';
import { EventEmitter } from 'events';

// Configuration
const PORT = parseInt(process.env.BRIDGE_PORT || '9090');
const NAMESPACE = process.env.ROS_NAMESPACE || '/rover';
const ROS_DOMAIN_ID = process.env.ROS_DOMAIN_ID || '0';

// ROS 2 Topic Subscriptions
const TOPICS = {
  networkHealth: `${NAMESPACE}/network_health`,
  joystickInput: `/joy`,  // Standard ROS 2 joy topic
  systemStatus: `${NAMESPACE}/system_status`,
};

// Data store
const dataStore = new EventEmitter();
let dataSourceMode = 'ros';  // ros or simulator
let simulatedData = null;
let latestData = {
  latency: 0,
  packetLoss: 0,
  signalStrength: -80,
  txThroughput: 0,
  rxThroughput: 0,
  joystickX: 0,
  joystickY: 0,
  joystickButtons: Array(8).fill(0),
  joystickAxes: Array(6).fill(0),
  systemStatus: 'GOOD',
};

/**
 * Parse ROS 2 Joy message (sensor_msgs/Joy)
 * 
 * Joy message structure:
 * {
 *   "header": { "stamp": {...}, "frame_id": "..." },
 *   "axes": [float, float, ...],
 *   "buttons": [int, int, ...]
 * }
 */
function parseJoyMessage(message) {
  try {
    const axes = message.axes || [];
    const buttons = message.buttons || [];

    return {
      joystickX: axes[0] ?? 0,      // Left stick X
      joystickY: axes[1] ?? 0,      // Left stick Y
      joystickAxes: axes,           // All axes (for full controller visualization)
      joystickButtons: buttons.map(b => (b > 0 ? 1 : 0)), // Normalize buttons to 0/1
    };
  } catch (e) {
    console.error('[Parser] Error parsing Joy message:', e);
    return null;
  }
}

/**
 * Parse network health message
 * 
 * Expected format (Float32MultiArray or custom):
 * {
 *   "data": [latency_ms, packet_loss_pct, signal_strength_dbm, tx_mbps, rx_mbps]
 * }
 * 
 * Or individual fields:
 * {
 *   "latency_ms": float,
 *   "packet_loss_pct": float,
 *   "signal_strength_dbm": float,
 *   "tx_mbps": float,
 *   "rx_mbps": float
 * }
 */
function parseNetworkHealthMessage(message) {
  try {
    // Handle Float32MultiArray format
    if (message.data && Array.isArray(message.data)) {
      return {
        latency: message.data[0] ?? 0,
        packetLoss: message.data[1] ?? 0,
        signalStrength: message.data[2] ?? -80,
        txThroughput: message.data[3] ?? 0,
        rxThroughput: message.data[4] ?? 0,
      };
    }

    // Handle individual field format
    return {
      latency: message.latency_ms ?? message.latency ?? 0,
      packetLoss: message.packet_loss_pct ?? message.packet_loss ?? 0,
      signalStrength: message.signal_strength_dbm ?? message.signal_strength ?? -80,
      txThroughput: message.tx_mbps ?? message.tx ?? 0,
      rxThroughput: message.rx_mbps ?? message.rx ?? 0,
    };
  } catch (e) {
    console.error('[Parser] Error parsing network health message:', e);
    return null;
  }
}

/**
 * Parse system status message
 * 
 * Expected format:
 * {
 *   "data": "GOOD|WARNING|CRITICAL"
 * }
 */
function parseSystemStatusMessage(message) {
  try {
    const status = message.data || message.status || 'GOOD';
    const validStatuses = ['GOOD', 'WARNING', 'CRITICAL'];
    
    return {
      systemStatus: validStatuses.includes(status) ? status : 'GOOD',
    };
  } catch (e) {
    console.error('[Parser] Error parsing system status message:', e);
    return null;
  }
}

/**
 * Subscribe to a ROS 2 topic with JSON output
 */
function subscribeToTopic(topicName, callback) {
  console.log(`[ROS2] Subscribing to topic: ${topicName}`);
  
  const process = spawn('ros2', ['topic', 'echo', topicName, '--format', 'json'], {
    env: {
      ...process.env,
      ROS_DOMAIN_ID,
    },
  });

  let buffer = '';
  let messageCount = 0;

  process.stdout.on('data', (data) => {
    buffer += data.toString();
    const lines = buffer.split('\n');
    
    // Process complete lines
    for (let i = 0; i < lines.length - 1; i++) {
      const line = lines[i].trim();
      if (!line) continue;

      try {
        const message = JSON.parse(line);
        callback(message);
        messageCount++;

        // Log first message to verify parsing
        if (messageCount === 1) {
          console.log(`[ROS2] First message received from ${topicName}:`, JSON.stringify(message).substring(0, 100) + '...');
        }
      } catch (e) {
        // Skip invalid JSON lines (might be partial messages)
        if (line.length > 0) {
          console.debug(`[ROS2] Skipping invalid JSON: ${line.substring(0, 50)}`);
        }
      }
    }
    
    // Keep incomplete line in buffer
    buffer = lines[lines.length - 1];
  });

  process.stderr.on('data', (data) => {
    const error = data.toString();
    if (!error.includes('Could not determine')) {
      console.error(`[ROS2 Error] ${error}`);
    }
  });

  process.on('close', (code) => {
    console.log(`[ROS2] Topic subscription ended with code ${code}. Reconnecting in 3 seconds...`);
    // Attempt to reconnect after 3 seconds
    setTimeout(() => subscribeToTopic(topicName, callback), 3000);
  });

  return process;
}

/**
 * Update dashboard data from ROS 2 messages
 */
function updateDataFromROS2(topicName, message) {
  if (topicName === TOPICS.joystickInput) {
    const parsed = parseJoyMessage(message);
    if (parsed) {
      latestData = { ...latestData, ...parsed };
      console.debug('[Data] Updated joystick:', {
        x: latestData.joystickX.toFixed(2),
        y: latestData.joystickY.toFixed(2),
        buttons: latestData.joystickButtons.length,
      });
    }
  } else if (topicName === TOPICS.networkHealth) {
    const parsed = parseNetworkHealthMessage(message);
    if (parsed) {
      latestData = { ...latestData, ...parsed };
      console.debug('[Data] Updated network health:', {
        latency: latestData.latency.toFixed(1),
        packetLoss: latestData.packetLoss.toFixed(2),
      });
    }
  } else if (topicName === TOPICS.systemStatus) {
    const parsed = parseSystemStatusMessage(message);
    if (parsed) {
      latestData = { ...latestData, ...parsed };
      console.debug('[Data] Updated system status:', latestData.systemStatus);
    }
  }
  
  dataStore.emit('update', latestData);
}

/**
 * Create HTTP server with WebSocket
 */
const server = createServer();
const wss = new WebSocket.Server({ server });

wss.on('connection', (ws) => {
  console.log('[WS] Client connected. Total clients:', wss.clients.size);
  
  // Send initial data
  ws.send(JSON.stringify({
    type: 'data',
    data: latestData,
  }));

  // Listen for subscription requests
  ws.on('message', (message) => {
    try {
      const request = JSON.parse(message);
      
      if (request.type === 'subscribe') {
        console.log(`[WS] Client subscribed to namespace: ${request.namespace}`);
      }
    } catch (e) {
      console.error('[WS] Failed to parse message:', e);
    }
  });

  ws.on('close', () => {
    console.log('[WS] Client disconnected. Total clients:', wss.clients.size);
  });

  ws.on('error', (error) => {
    console.error('[WS] Client error:', error.message);
  });
});

// Send data updates to all connected clients
dataStore.on('update', (data) => {
  const message = JSON.stringify({
    type: 'data',
    data,
  });

  let sentCount = 0;
  wss.clients.forEach((client) => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(message);
      sentCount++;
    }
  });

  if (sentCount > 0) {
    console.debug(`[WS] Broadcast to ${sentCount} client(s)`);
  }
});

/**
 * Initialize ROS 2 subscriptions
 */
function initializeROS2Subscriptions() {
  console.log('[ROS2] Initializing subscriptions...');
  
  // Check if ROS 2 is available
  const checkROS = spawn('ros2', ['--version']);
  
  checkROS.on('close', (code) => {
    if (code !== 0) {
      console.warn('[ROS2] ROS 2 not found. Running in simulation mode.');
      console.warn('[ROS2] To use real rover data, ensure ROS 2 is installed and sourced.');
      console.warn('[ROS2] Expected topics:');
      console.warn(`  - ${TOPICS.joystickInput} (sensor_msgs/Joy)`);
      console.warn(`  - ${TOPICS.networkHealth} (Float32MultiArray or custom)`);
      console.warn(`  - ${TOPICS.systemStatus} (std_msgs/String)`);
      
      // Simulate data for testing
      simulateROS2Data();
    } else {
      console.log('[ROS2] ROS 2 found. Subscribing to topics...');
      
      // Subscribe to each topic
      subscribeToTopic(TOPICS.joystickInput, (msg) => updateDataFromROS2(TOPICS.joystickInput, msg));
      subscribeToTopic(TOPICS.networkHealth, (msg) => updateDataFromROS2(TOPICS.networkHealth, msg));
      subscribeToTopic(TOPICS.systemStatus, (msg) => updateDataFromROS2(TOPICS.systemStatus, msg));
    }
  });
}

/**
 * Simulate ROS 2 data for testing
 */
function simulateROS2Data() {
  console.log('[Simulation] Starting data simulation...');
  
  setInterval(() => {
    latestData = {
      latency: 30 + Math.random() * 20,
      packetLoss: Math.max(0, Math.random() * 0.2),
      signalStrength: -80 + Math.random() * 15,
      txThroughput: 30 + Math.random() * 40,
      rxThroughput: 40 + Math.random() * 50,
      joystickX: (Math.random() - 0.5) * 2,
      joystickY: (Math.random() - 0.5) * 2,
      joystickButtons: Array(8)
        .fill(0)
        .map(() => (Math.random() > 0.9 ? 1 : 0)),
      joystickAxes: Array(6)
        .fill(0)
        .map(() => (Math.random() - 0.5) * 2),
      systemStatus: Math.random() > 0.8 ? 'WARNING' : 'GOOD',
    };
    
    dataStore.emit('update', latestData);
  }, 1000);
}

/**
 * Start server
 */
server.listen(PORT, () => {
  console.log(`\n🚀 ROS 2 WebSocket Bridge started on ws://0.0.0.0:${PORT}`);
  console.log(`📡 ROS Namespace: ${NAMESPACE}`);
  console.log(`🌍 Connect dashboard to: ws://localhost:${PORT}\n`);
  console.log('Expected ROS 2 Topics:');
  console.log(`  1. ${TOPICS.joystickInput} (sensor_msgs/Joy)`);
  console.log(`  2. ${TOPICS.networkHealth} (Float32MultiArray or custom)`);
  console.log(`  3. ${TOPICS.systemStatus} (std_msgs/String)\n`);
  
  initializeROS2Subscriptions();
});

/**
 * Graceful shutdown
 */
process.on('SIGINT', () => {
  console.log('\n[Server] Shutting down gracefully...');
  wss.clients.forEach((client) => client.close());
  server.close(() => {
    console.log('[Server] Closed');
    process.exit(0);
  });
});

process.on('SIGTERM', () => {
  console.log('\n[Server] Shutting down gracefully...');
  wss.clients.forEach((client) => client.close());
  server.close(() => {
    console.log('[Server] Closed');
    process.exit(0);
  });
});
