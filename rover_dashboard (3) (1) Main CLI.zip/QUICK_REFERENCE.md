# ⚡ Quick Reference Cheat Sheet

**Fast lookup for all commands, setup steps, and troubleshooting.**

---

## 🚀 Quick Start (5 minutes)

### Terminal 1: Bridge
```bash
cd ~/rover_dashboard
node ros2-bridge-simulator.mjs
```

### Terminal 2: Dashboard
```bash
cd ~/rover_dashboard
pnpm dev
# Open http://localhost:3000
```

### Terminal 3: CLI Simulator
```bash
cd ~/rover_dashboard
python3 data_simulator_interactive.py --bridge-url http://localhost:9090
```

---

## 📋 CLI Commands

### Network Metrics
```bash
latency 50              # Set latency to 50ms
loss 0.1               # Set packet loss to 0.1%
signal -75             # Set signal to -75 dBm
tx 60                  # Set TX to 60 Mbps
rx 80                  # Set RX to 80 Mbps
status GOOD            # Set status (GOOD/WARNING/CRITICAL)
```

### Joystick Control
```bash
joystick 0.5 0.3       # Move joystick X=0.5, Y=0.3
button 0 1             # Press button 0 (A)
button 0 0             # Release button 0
button 4 1             # Press button 4 (LB)
```

### Automation
```bash
simulate               # Toggle automatic simulation
status                 # Show current state
help                   # Show all commands
exit                   # Exit simulator
```

---

## 🔌 Installation Commands

### Prerequisites
```bash
python3 --version     # Check Python (need 3.8+)
node --version        # Check Node.js (need 16+)
pnpm --version        # Check pnpm
```

### Install Dependencies
```bash
cd ~/rover_dashboard
pnpm install          # Install Node dependencies
pip3 install requests # Install Python requests
```

### Verify Installation
```bash
curl http://localhost:9090/health  # Test bridge
http://localhost:3000              # Test dashboard
python3 -c "import requests; print('OK')"  # Test Python
```

---

## 🐍 Simulator Mode Setup

### Step 1: Start Bridge
```bash
node ros2-bridge-simulator.mjs
# Output: [Bridge] Server running on port 9090
```

### Step 2: Start Dashboard
```bash
pnpm dev
# Output: ➜ Local: http://localhost:3000/
```

### Step 3: Start CLI
```bash
python3 data_simulator_interactive.py --bridge-url http://localhost:9090
# Output: >>> (ready for commands)
```

### Step 4: Test
```bash
# In CLI terminal, type:
latency 50
# Watch dashboard update
```

---

## 🤖 ROS 2 Mode Setup

### Step 1: Install ROS 2
```bash
# Ubuntu 22.04 (Humble)
sudo apt install ros-humble-desktop
source /opt/ros/humble/setup.bash
```

### Step 2: Create Package
```bash
mkdir -p ~/rover_ws/src
cd ~/rover_ws/src
ros2 pkg create rover_telemetry --build-type ament_python
```

### Step 3: Build Package
```bash
cd ~/rover_ws
colcon build --packages-select rover_telemetry
source install/setup.bash
```

### Step 4: Run Publishers
```bash
# Terminal 1
ros2 run rover_telemetry network_health_publisher

# Terminal 2
ros2 run rover_telemetry joystick_publisher

# Terminal 3
ros2 run rover_telemetry system_status_publisher
```

### Step 5: Start Bridge (ROS Mode)
```bash
cd ~/rover_dashboard
DATA_SOURCE=ros node ros2-bridge-simulator.mjs
```

### Step 6: Configure Dashboard
1. Click ⚙️ (Settings)
2. Select "🤖 ROS 2 Mode"
3. Set Bridge IP: `localhost` (or `<machine-ip>` if remote)
4. Click Save

---

## 🔍 Troubleshooting Commands

### Check Services Running
```bash
ps aux | grep "node ros2-bridge"      # Check bridge
ps aux | grep "pnpm dev"              # Check dashboard
ps aux | grep "python3 data_simulator" # Check CLI
```

### Check Ports
```bash
lsof -i :9090                         # Check port 9090
lsof -i :3000                         # Check port 3000
```

### Kill Processes
```bash
pkill -f "node ros2-bridge"           # Kill bridge
pkill -f "pnpm dev"                   # Kill dashboard
pkill -f "python3 data_simulator"     # Kill CLI
```

### Test Connectivity
```bash
curl http://localhost:9090/health     # Test bridge
ping <bridge-ip>                      # Test network
```

### Check ROS 2 Topics
```bash
ros2 topic list                       # List all topics
ros2 topic echo /joy                  # Monitor joystick
ros2 topic info /rover/network/latency # Get topic info
```

---

## 📊 Dashboard Modes

| Mode | Use Case | Data Source |
|------|----------|-------------|
| **Simulator** | Testing, demos, hackathon | Python CLI |
| **ROS 2** | Production, real rover | ROS 2 topics |

### Switch Modes
1. Click ⚙️ (Settings)
2. Select mode
3. Click Save

---

## 🎮 Button Mapping

| ID | Button | ID | Button |
|----|--------|----|----|
| 0 | A | 5 | RB |
| 1 | B | 6 | Back |
| 2 | X | 7 | Start |
| 3 | Y | 8 | LS |
| 4 | LB | 9 | RS |

---

## 📈 Performance Targets

| Metric | Target | Acceptable |
|--------|--------|-----------|
| Update Latency | <50ms | <100ms |
| CPU Usage | <5% | <10% |
| Memory | <100MB | <200MB |
| Network | <500 KB/s | <1 Mbps |

---

## 🌐 Network Configuration

### Local Setup (Same Machine)
```
Bridge IP: localhost
Bridge Port: 9090
Dashboard: http://localhost:3000
```

### Remote Setup (Different Machines)
```
Bridge IP: <rover-machine-ip>
Bridge Port: 9090
Dashboard: http://<operator-machine>:3000

# Get IP address:
hostname -I
```

### Firewall Rules
```bash
sudo ufw allow 9090    # Allow bridge port
sudo ufw allow 3000    # Allow dashboard port
sudo ufw status        # Check firewall
```

---

## 📝 File Locations

| File | Purpose |
|------|---------|
| `ros2-bridge-simulator.mjs` | Bridge server |
| `data_simulator_interactive.py` | CLI simulator |
| `client/src/pages/Home.tsx` | Dashboard main page |
| `client/src/index.css` | Dashboard styles |
| `package.json` | Node dependencies |

---

## 🐛 Common Errors & Fixes

| Error | Fix |
|-------|-----|
| `EADDRINUSE :::9090` | `pkill -f "node ros2-bridge"` |
| `Connection refused` | Check bridge is running |
| `ModuleNotFoundError: requests` | `pip3 install requests` |
| `Topic not found` | Check publishers are running |
| `WebSocket connection failed` | Check bridge IP in settings |

---

## 🎯 Demo Script

```bash
# Terminal 3 (CLI)

# 1. Show normal operation
latency 40
loss 0.05
status GOOD

# 2. Joystick movement
joystick 0.5 0.3
sleep 2

# 3. Network degradation
latency 120
loss 1.5
status WARNING
sleep 2

# 4. Recovery
latency 40
loss 0.05
status GOOD
sleep 2

# 5. Button press
button 0 1
sleep 1
button 0 0
```

---

## 📱 Browser Support

| Browser | Support |
|---------|---------|
| Chrome | ✅ Full |
| Firefox | ✅ Full |
| Safari | ✅ Full |
| Edge | ✅ Full |

---

## 🔗 Useful Links

- [ROS 2 Documentation](https://docs.ros.org/en/humble/)
- [React Documentation](https://react.dev/)
- [Tailwind CSS](https://tailwindcss.com/)
- [WebSocket API](https://developer.mozilla.org/en-US/docs/Web/API/WebSocket)

---

## 💡 Pro Tips

1. **Use automatic simulation for smooth visuals:**
   ```bash
   simulate
   ```

2. **Monitor bridge in real-time:**
   ```bash
   watch -n 1 'ps aux | grep node'
   ```

3. **Create demo script:**
   ```bash
   cat > demo.txt << EOF
   latency 50
   loss 0.1
   status GOOD
   EOF
   python3 data_simulator_interactive.py < demo.txt
   ```

4. **Record ROS 2 topics:**
   ```bash
   ros2 bag record -a
   ```

5. **Test WebSocket connection:**
   ```javascript
   // In browser console:
   const ws = new WebSocket('ws://localhost:9090');
   ws.onmessage = (e) => console.log(e.data);
   ```

---

## 📞 Support Checklist

- [ ] Bridge running: `curl http://localhost:9090/health`
- [ ] Dashboard loaded: `http://localhost:3000`
- [ ] CLI connected: Can type commands
- [ ] No port conflicts: `lsof -i :9090`
- [ ] Correct mode selected: Settings → Data Source
- [ ] Correct bridge IP: Settings → Bridge IP
- [ ] Network connectivity: `ping <bridge-ip>`
- [ ] Browser console clear: `F12 → Console`

---

**Quick reference complete! For detailed guides, see:**
- `SETUP_CLI_SIMULATOR.md` - Full CLI setup
- `SETUP_ROS2_INTEGRATION.md` - Full ROS 2 setup
- `TROUBLESHOOTING_FAQ.md` - Detailed troubleshooting
- `CLI_SIMULATOR_GUIDE.md` - CLI command reference

**Happy hacking! 🚀**
