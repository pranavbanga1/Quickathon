# 🎮 USB Joystick Integration Guide

This guide explains how to connect a real USB joystick/gamepad to your rover system and use it to control the rover directly through the dashboard.

## Table of Contents

1. [Hardware Setup](#hardware-setup)
2. [Linux Joystick Configuration](#linux-joystick-configuration)
3. [ROS 2 Joy Node Setup](#ros-2-joy-node-setup)
4. [Testing the Joystick](#testing-the-joystick)
5. [Calibration](#calibration)
6. [Troubleshooting](#troubleshooting)

---

## Hardware Setup

### Supported Joysticks

The following joysticks are tested and recommended:

| Device | Type | Notes |
|--------|------|-------|
| Xbox 360 Controller | Wireless/USB | Most common, excellent support |
| Xbox One Controller | Wireless/USB | Modern alternative |
| PlayStation 4 DualShock | Wireless/USB | Works well with Linux |
| Logitech F310/F710 | Wired/Wireless | Professional grade |
| Generic USB Gamepad | Wired | Budget option, may need calibration |

### Physical Connection

1. **Connect USB Joystick** to your rover system (or operator machine)
   ```bash
   # Plug USB joystick into USB port
   # For wireless, plug USB receiver
   ```

2. **Verify Connection**
   ```bash
   # List USB devices
   lsusb | grep -i joy
   # or
   lsusb | grep -i xbox
   
   # Should show something like:
   # Bus 001 Device 005: ID 045e:02ea Microsoft Corp. Xbox 360 Controller
   ```

3. **Check Joystick Device**
   ```bash
   # List joystick devices
   ls -la /dev/input/js*
   
   # Should show:
   # /dev/input/js0  (first joystick)
   # /dev/input/js1  (second joystick, if connected)
   ```

---

## Linux Joystick Configuration

### Step 1: Install Joystick Tools

```bash
# Install joystick utilities
sudo apt update
sudo apt install -y joystick jstest-gtk

# Verify installation
jstest /dev/input/js0
```

### Step 2: Test Joystick Input

```bash
# Interactive test (press buttons and move sticks)
jstest /dev/input/js0

# You should see:
# Axes:  0:     0  1:     0  2: -32767  3:     0  4:     0  5: -32767
# Buttons: BT=0

# Move left stick left/right - Axis 0 changes
# Move left stick up/down - Axis 1 changes
# Move right stick left/right - Axis 3 changes
# Move right stick up/down - Axis 4 changes
# Press buttons - Buttons change
```

### Step 3: Permissions Setup

```bash
# Add user to input group (allows joystick access without sudo)
sudo usermod -a -G input $USER

# Apply group changes
newgrp input

# Verify permission
ls -l /dev/input/js0
# Should show: crw-rw---- 1 root input ...
```

### Step 4: Persistent Permissions (Optional)

```bash
# Create udev rule for automatic permissions
sudo tee /etc/udev/rules.d/99-joystick.rules > /dev/null << EOF
# Joystick permissions
SUBSYSTEM=="input", MODE="0666"
EOF

# Reload udev rules
sudo udevadm control --reload-rules
sudo udevadm trigger
```

---

## ROS 2 Joy Node Setup

### Option A: Use Official ROS 2 Joy Package (Recommended)

```bash
# Install ROS 2 joy package
sudo apt install -y ros-humble-joy

# Start joy node
ros2 run joy joy_node --ros-args -p dev:="/dev/input/js0"

# In another terminal, verify it's publishing
ros2 topic echo /joy

# You should see:
# header:
#   stamp:
#     sec: ...
#     nsec: ...
#   frame_id: ''
# axes: [0.0, 0.0, -1.0, 0.0, 0.0, -1.0]
# buttons: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
```

### Option B: Use Custom Joystick Reader Node

If you need more control or custom mapping, use the provided `joystick_reader_node.py`:

```bash
# Copy the custom joystick reader to your package
cp example_ros2_package/rover_telemetry/joystick_reader_node.py \
   ~/rover_ws/src/rover_telemetry/rover_telemetry/

# Build package
cd ~/rover_ws
colcon build --packages-select rover_telemetry

# Run custom joystick reader
ros2 run rover_telemetry joystick_reader_node --ros-args -p device:="/dev/input/js0"
```

---

## Testing the Joystick

### Test 1: Verify Topic Publishing

```bash
# Terminal 1: Start joy node
ros2 run joy joy_node --ros-args -p dev:="/dev/input/js0"

# Terminal 2: Check topic frequency
ros2 topic hz /joy
# Should show: average rate: 50.00 Hz

# Terminal 3: Echo topic
ros2 topic echo /joy
# Move joystick and press buttons - should see values change
```

### Test 2: Verify Dashboard Updates

```bash
# Terminal 1: Start all publishers
cd ~/rover_ws
source install/setup.bash
ros2 run joy joy_node --ros-args -p dev:="/dev/input/js0" &
ros2 run rover_telemetry network_health_pub &
ros2 run rover_telemetry system_status_pub &

# Terminal 2: Start enhanced bridge
cd ~/rover_dashboard
node ros2-bridge-enhanced.mjs --port 9090

# Terminal 3: Start dashboard
pnpm dev

# Open http://localhost:3000
# Move joystick - Controller View should update in real-time
```

### Test 3: Verify Button Mapping

```bash
# Check which button is which
ros2 topic echo /joy

# Xbox 360 Controller Button Mapping:
# Button 0: A
# Button 1: B
# Button 2: X
# Button 3: Y
# Button 4: LB
# Button 5: RB
# Button 6: Back
# Button 7: Start
# Button 8: Left stick press
# Button 9: Right stick press

# Axis Mapping:
# Axis 0: Left stick X (-1.0 left, 1.0 right)
# Axis 1: Left stick Y (-1.0 up, 1.0 down)
# Axis 2: LT (Left Trigger) (-1.0 released, 1.0 pressed)
# Axis 3: Right stick X (-1.0 left, 1.0 right)
# Axis 4: Right stick Y (-1.0 up, 1.0 down)
# Axis 5: RT (Right Trigger) (-1.0 released, 1.0 pressed)
```

---

## Calibration

### Automatic Calibration

Most modern joysticks work out of the box. If you experience drift or incorrect axis mapping:

```bash
# Use jstest-gtk for interactive calibration
jstest-gtk

# Or use command line calibration
jscal -c /dev/input/js0
```

### Manual Calibration

```bash
# Center all sticks and triggers before calibration
jscal /dev/input/js0

# Follow on-screen prompts:
# 1. Center all axes
# 2. Move each axis to extremes
# 3. Press each button
```

### Save Calibration

```bash
# Save calibration to file
jscal -p /dev/input/js0 > joystick.cal

# Load calibration on startup
jscal -l joystick.cal /dev/input/js0

# Or add to ~/.bashrc for automatic loading
echo "jscal -l ~/joystick.cal /dev/input/js0" >> ~/.bashrc
```

---

## Rover Motor Control Integration

### Step 1: Create Motor Command Publisher

The joystick input needs to be converted to rover motor commands. Use the provided `motor_controller_node.py`:

```bash
# Copy motor controller to your package
cp example_ros2_package/rover_telemetry/motor_controller_node.py \
   ~/rover_ws/src/rover_telemetry/rover_telemetry/

# Update setup.py to include new entry point
# Add to entry_points['console_scripts']:
# 'motor_controller = rover_telemetry.motor_controller_node:main',

# Build
cd ~/rover_ws
colcon build --packages-select rover_telemetry
```

### Step 2: Start Motor Controller

```bash
# Terminal 1: Start joy node
ros2 run joy joy_node --ros-args -p dev:="/dev/input/js0"

# Terminal 2: Start motor controller
ros2 run rover_telemetry motor_controller

# Terminal 3: Verify motor commands
ros2 topic echo /rover/motor_commands

# You should see:
# left_motor: 0.0
# right_motor: 0.0
# (Values change as you move joystick)
```

### Step 3: Connect to Actual Rover Motors

Update `motor_controller_node.py` to send commands to your actual motor drivers:

```python
# In motor_controller_node.py, update the motor control section:

def send_motor_commands(self, left_speed, right_speed):
    """Send commands to actual rover motors"""
    
    # Option 1: CAN bus
    # self.can_interface.send(can_id, [left_speed, right_speed])
    
    # Option 2: Serial (Arduino/Microcontroller)
    # self.serial_port.write(f"L{left_speed},R{right_speed}\n".encode())
    
    # Option 3: GPIO (Raspberry Pi)
    # self.left_pwm.ChangeDutyCycle(left_speed)
    # self.right_pwm.ChangeDutyCycle(right_speed)
    
    # Option 4: ROS 2 actuator commands
    msg = MotorCommand()
    msg.left_speed = left_speed
    msg.right_speed = right_speed
    self.motor_pub.publish(msg)
```

---

## Complete Workflow

### Full Integration Example

```bash
# Terminal 1: Start ROS 2 joy node
ros2 run joy joy_node --ros-args -p dev:="/dev/input/js0"

# Terminal 2: Start motor controller (converts joy to motor commands)
ros2 run rover_telemetry motor_controller

# Terminal 3: Start network health publisher
ros2 run rover_telemetry network_health_pub

# Terminal 4: Start system status publisher
ros2 run rover_telemetry system_status_pub

# Terminal 5: Start ROS 2 bridge
cd ~/rover_dashboard
node ros2-bridge-enhanced.mjs --port 9090

# Terminal 6: Start dashboard
pnpm dev

# Open http://localhost:3000
# Move joystick → Motor commands sent to rover
# Dashboard shows real-time joystick input and network metrics
```

---

## Troubleshooting

### Issue: Joystick not detected

```bash
# Check if device exists
ls -la /dev/input/js*

# If not found, check USB connection
lsusb | grep -i joy

# If USB shows but no /dev/input/js*, try:
sudo modprobe joydev

# Verify module is loaded
lsmod | grep joydev
```

### Issue: Permission denied

```bash
# Check permissions
ls -l /dev/input/js0

# Add user to input group
sudo usermod -a -G input $USER
newgrp input

# Or run with sudo
sudo ros2 run joy joy_node --ros-args -p dev:="/dev/input/js0"
```

### Issue: Joystick not publishing data

```bash
# Verify joy node is running
ros2 node list | grep joy

# Check topic exists
ros2 topic list | grep joy

# If no /joy topic, check joy node logs
ros2 run joy joy_node --ros-args -p dev:="/dev/input/js0" 2>&1 | head -20

# Common issues:
# - Wrong device path (use ls /dev/input/js* to find correct one)
# - Permissions (add to input group)
# - Joystick not connected properly
```

### Issue: Axes/buttons not mapping correctly

```bash
# Check actual axis/button values
jstest /dev/input/js0

# Compare with expected mapping
# If different, update motor_controller_node.py axis mapping

# Or use custom joystick reader with custom mapping
ros2 run rover_telemetry joystick_reader_node --ros-args -p device:="/dev/input/js0"
```

### Issue: Joystick drifts or has dead zone

```bash
# Calibrate joystick
jscal -c /dev/input/js0

# Or adjust dead zone in motor_controller_node.py:
JOYSTICK_DEADZONE = 0.1  # Increase if too sensitive
```

---

## Advanced: Multiple Joysticks

```bash
# Connect multiple joysticks
ls /dev/input/js*
# /dev/input/js0
# /dev/input/js1

# Start joy node for each
ros2 run joy joy_node --ros-args -p dev:="/dev/input/js0" -p topic:="joy1" &
ros2 run joy joy_node --ros-args -p dev:="/dev/input/js1" -p topic:="joy2" &

# Or create a launch file to start all at once
# See example_ros2_package/launch/joystick.launch.py
```

---

## Performance Tips

1. **Increase Joy Node Frequency** (default 50 Hz)
   ```bash
   ros2 run joy joy_node --ros-args -p dev:="/dev/input/js0" -p deadzone:="0.05" -p autorepeat_rate:="100"
   ```

2. **Reduce Dashboard Update Frequency** if CPU usage is high
   ```bash
   # Edit motor_controller_node.py
   self.timer = self.create_timer(0.05, self.process_joystick)  # 20 Hz instead of 10 Hz
   ```

3. **Use Hardware Acceleration** for joystick processing
   - Offload motor control to microcontroller
   - Use CAN bus for low-latency communication

---

## Resources

- [ROS 2 Joy Package](https://index.ros.org/p/joy/)
- [Linux Joystick API](https://www.kernel.org/doc/html/latest/input/joydev/joystick-api.html)
- [Xbox Controller Linux Support](https://github.com/xpadneo/xpadneo)
- [Joystick Calibration Tools](https://wiki.archlinux.org/title/Gamepad)

---

**Happy controlling! 🎮**
