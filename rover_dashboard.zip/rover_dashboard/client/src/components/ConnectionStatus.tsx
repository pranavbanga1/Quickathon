import { Circle, AlertCircle, CheckCircle2 } from "lucide-react";

type ConnectionState = "connected" | "connecting" | "disconnected" | "error";

interface ConnectionStatusProps {
  state: ConnectionState;
  message?: string;
  onRetry?: () => void;
}

const stateConfig = {
  connected: {
    color: "text-green-400",
    bgColor: "bg-green-400/10",
    borderColor: "border-green-400/30",
    icon: CheckCircle2,
    label: "Connected",
  },
  connecting: {
    color: "text-yellow-400",
    bgColor: "bg-yellow-400/10",
    borderColor: "border-yellow-400/30",
    icon: Circle,
    label: "Connecting...",
  },
  disconnected: {
    color: "text-muted-foreground",
    bgColor: "bg-muted/10",
    borderColor: "border-muted/30",
    icon: Circle,
    label: "Disconnected",
  },
  error: {
    color: "text-red-400",
    bgColor: "bg-red-400/10",
    borderColor: "border-red-400/30",
    icon: AlertCircle,
    label: "Connection Error",
  },
};

export default function ConnectionStatus({
  state,
  message,
  onRetry,
}: ConnectionStatusProps) {
  const config = stateConfig[state];
  const Icon = config.icon;

  return (
    <div
      className={`flex items-center gap-3 px-4 py-3 rounded-lg border ${config.bgColor} ${config.borderColor}`}
    >
      <Icon
        size={18}
        className={`${config.color} ${state === "connecting" ? "animate-spin" : ""}`}
      />
      <div className="flex-1">
        <div className={`text-sm font-semibold ${config.color}`}>
          {config.label}
        </div>
        {message && (
          <div className="text-xs text-muted-foreground mt-0.5">{message}</div>
        )}
      </div>
      {state === "error" && onRetry && (
        <button
          onClick={onRetry}
          className="text-xs px-2 py-1 bg-accent/20 hover:bg-accent/30 rounded transition-colors text-accent-foreground font-semibold"
        >
          Retry
        </button>
      )}
    </div>
  );
}
