interface NetworkDataPoint {
  tx: number;
  rx: number;
  timestamp: number;
}

interface NetworkChartProps {
  data: NetworkDataPoint[];
}

export default function NetworkChart({ data }: NetworkChartProps) {
  const width = 400;
  const height = 120;
  const padding = 10;
  const graphWidth = width - padding * 2;
  const graphHeight = height - padding * 2;

  // Find max value for scaling
  const maxValue = Math.max(
    ...data.map((d) => Math.max(d.tx, d.rx)),
    100
  );

  // Generate path data for TX and RX lines
  const generatePath = (values: number[]) => {
    if (values.length === 0) return "";

    const points = values.map((value, index) => {
      const x = padding + (index / Math.max(values.length - 1, 1)) * graphWidth;
      const y = padding + graphHeight - (value / maxValue) * graphHeight;
      return `${x},${y}`;
    });

    return `M ${points.join(" L ")}`;
  };

  const txValues = data.map((d) => d.tx);
  const rxValues = data.map((d) => d.rx);

  const txPath = generatePath(txValues);
  const rxPath = generatePath(rxValues);

  return (
    <div className="w-full h-32 flex items-center justify-center">
      <svg
        width="100%"
        height="100%"
        viewBox={`0 0 ${width} ${height}`}
        preserveAspectRatio="none"
        className="w-full"
      >
        {/* Grid lines */}
        {[0, 0.25, 0.5, 0.75, 1].map((ratio) => (
          <line
            key={`grid-${ratio}`}
            x1={padding}
            y1={padding + graphHeight * ratio}
            x2={width - padding}
            y2={padding + graphHeight * ratio}
            stroke="oklch(0.3 0.02 262 / 15%)"
            strokeWidth="0.5"
            strokeDasharray="2,2"
          />
        ))}

        {/* TX line (bright blue) */}
        <path
          d={txPath}
          fill="none"
          stroke="oklch(0.65 0.22 262)"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          opacity="0.9"
        />

        {/* RX line (cyan) */}
        <path
          d={rxPath}
          fill="none"
          stroke="oklch(0.6 0.2 262)"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          opacity="0.8"
        />

        {/* Gradient fills for visual effect */}
        <defs>
          <linearGradient id="txGradient" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop
              offset="0%"
              stopColor="oklch(0.65 0.22 262)"
              stopOpacity="0.2"
            />
            <stop
              offset="100%"
              stopColor="oklch(0.65 0.22 262)"
              stopOpacity="0"
            />
          </linearGradient>
          <linearGradient id="rxGradient" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop
              offset="0%"
              stopColor="oklch(0.6 0.2 262)"
              stopOpacity="0.15"
            />
            <stop
              offset="100%"
              stopColor="oklch(0.6 0.2 262)"
              stopOpacity="0"
            />
          </linearGradient>
        </defs>

        {/* TX gradient fill */}
        {txPath && (
          <path
            d={`${txPath} L ${width - padding},${padding + graphHeight} L ${padding},${padding + graphHeight} Z`}
            fill="url(#txGradient)"
          />
        )}

        {/* RX gradient fill */}
        {rxPath && (
          <path
            d={`${rxPath} L ${width - padding},${padding + graphHeight} L ${padding},${padding + graphHeight} Z`}
            fill="url(#rxGradient)"
          />
        )}
      </svg>
    </div>
  );
}
