import { describe, it, expect } from "vitest";
import { render } from "@testing-library/react";
import StatCard from "../StatCard";

describe("StatCard", () => {
  it("renders label and value", () => {
    const { getByText } = render(
      <StatCard label="LATENCY" value="36.4" unit="ms" />
    );
    expect(getByText("LATENCY")).toBeTruthy();
    expect(getByText("36.4")).toBeTruthy();
  });

  it("renders unit when provided", () => {
    const { getByText } = render(
      <StatCard label="LATENCY" value="36.4" unit="ms" />
    );
    expect(getByText("ms")).toBeTruthy();
  });

  it("renders subtitle when provided", () => {
    const { getByText } = render(
      <StatCard
        label="LATENCY"
        value="36.4"
        unit="ms"
        subtitle="Optimal range"
      />
    );
    expect(getByText("Optimal range")).toBeTruthy();
  });

  it("renders GOOD status badge", () => {
    const { getByText } = render(
      <StatCard label="SYSTEM STATUS" value="GOOD" status="GOOD" />
    );
    expect(getByText("GOOD")).toBeTruthy();
  });

  it("renders WARNING status badge", () => {
    const { getByText } = render(
      <StatCard label="SYSTEM STATUS" value="WARNING" status="WARNING" />
    );
    expect(getByText("WARNING")).toBeTruthy();
  });

  it("renders CRITICAL status badge", () => {
    const { getByText } = render(
      <StatCard label="SYSTEM STATUS" value="CRITICAL" status="CRITICAL" />
    );
    expect(getByText("CRITICAL")).toBeTruthy();
  });

  it("renders icon when provided", () => {
    const { container } = render(
      <StatCard label="LATENCY" value="36.4" unit="ms" icon="⚡" />
    );
    expect(container.textContent).toContain("⚡");
  });

  it("applies correct styling for GOOD status", () => {
    const { container } = render(
      <StatCard label="STATUS" value="GOOD" status="GOOD" />
    );
    const statusElement = container.querySelector(".text-green-400");
    expect(statusElement).toBeTruthy();
  });

  it("applies correct styling for WARNING status", () => {
    const { container } = render(
      <StatCard label="STATUS" value="WARNING" status="WARNING" />
    );
    const statusElement = container.querySelector(".text-yellow-400");
    expect(statusElement).toBeTruthy();
  });

  it("applies correct styling for CRITICAL status", () => {
    const { container } = render(
      <StatCard label="STATUS" value="CRITICAL" status="CRITICAL" />
    );
    const statusElement = container.querySelector(".text-red-400");
    expect(statusElement).toBeTruthy();
  });

  it("renders without unit when not provided", () => {
    const { container } = render(<StatCard label="LATENCY" value="36.4" />);
    expect(container.textContent).toContain("36.4");
  });

  it("renders with cyan text color for numeric values", () => {
    const { container } = render(
      <StatCard label="LATENCY" value="36.4" unit="ms" />
    );
    const valueElement = container.querySelector(".text-cyan-400");
    expect(valueElement).toBeTruthy();
  });
});
