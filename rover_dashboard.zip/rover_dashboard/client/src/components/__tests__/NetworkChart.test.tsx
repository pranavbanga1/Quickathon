import { describe, it, expect } from "vitest";
import { render } from "@testing-library/react";
import NetworkChart from "../NetworkChart";

describe("NetworkChart", () => {
  const mockData = [
    { tx: 45.3, rx: 64.4, timestamp: Date.now() - 5000 },
    { tx: 48.2, rx: 62.1, timestamp: Date.now() - 4000 },
    { tx: 46.8, rx: 65.3, timestamp: Date.now() - 3000 },
    { tx: 50.1, rx: 63.8, timestamp: Date.now() - 2000 },
    { tx: 47.5, rx: 66.2, timestamp: Date.now() - 1000 },
    { tx: 49.3, rx: 64.9, timestamp: Date.now() },
  ];

  it("renders SVG element", () => {
    const { container } = render(<NetworkChart data={mockData} />);
    const svg = container.querySelector("svg");
    expect(svg).toBeTruthy();
  });

  it("renders with correct viewBox", () => {
    const { container } = render(<NetworkChart data={mockData} />);
    const svg = container.querySelector("svg");
    expect(svg?.getAttribute("viewBox")).toBe("0 0 400 120");
  });

  it("renders TX and RX lines", () => {
    const { container } = render(<NetworkChart data={mockData} />);
    const paths = container.querySelectorAll("path");
    // Should have TX line, RX line, and fill paths
    expect(paths.length).toBeGreaterThanOrEqual(2);
  });

  it("renders grid lines", () => {
    const { container } = render(<NetworkChart data={mockData} />);
    const lines = container.querySelectorAll("line");
    // Should have multiple grid lines
    expect(lines.length).toBeGreaterThan(0);
  });

  it("renders with empty data", () => {
    const { container } = render(<NetworkChart data={[]} />);
    const svg = container.querySelector("svg");
    expect(svg).toBeTruthy();
  });

  it("renders with single data point", () => {
    const { container } = render(
      <NetworkChart
        data={[{ tx: 45.3, rx: 64.4, timestamp: Date.now() }]}
      />
    );
    const svg = container.querySelector("svg");
    expect(svg).toBeTruthy();
  });

  it("renders gradients for visual effect", () => {
    const { container } = render(<NetworkChart data={mockData} />);
    const gradients = container.querySelectorAll("linearGradient");
    expect(gradients.length).toBeGreaterThanOrEqual(2);
  });

  it("applies correct gradient IDs", () => {
    const { container } = render(<NetworkChart data={mockData} />);
    const txGradient = container.querySelector("#txGradient");
    const rxGradient = container.querySelector("#rxGradient");
    expect(txGradient).toBeTruthy();
    expect(rxGradient).toBeTruthy();
  });

  it("renders large dataset without errors", () => {
    const largeData = Array.from({ length: 100 }, (_, i) => ({
      tx: 30 + Math.random() * 40,
      rx: 40 + Math.random() * 50,
      timestamp: Date.now() - (100 - i) * 1000,
    }));

    const { container } = render(<NetworkChart data={largeData} />);
    const svg = container.querySelector("svg");
    expect(svg).toBeTruthy();
  });

  it("handles zero values in data", () => {
    const zeroData = [
      { tx: 0, rx: 0, timestamp: Date.now() },
      { tx: 50, rx: 60, timestamp: Date.now() + 1000 },
    ];

    const { container } = render(<NetworkChart data={zeroData} />);
    const svg = container.querySelector("svg");
    expect(svg).toBeTruthy();
  });

  it("handles very high values in data", () => {
    const highData = [
      { tx: 1000, rx: 1000, timestamp: Date.now() },
      { tx: 500, rx: 600, timestamp: Date.now() + 1000 },
    ];

    const { container } = render(<NetworkChart data={highData} />);
    const svg = container.querySelector("svg");
    expect(svg).toBeTruthy();
  });
});
