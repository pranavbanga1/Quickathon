import { describe, it, expect } from "vitest";
import { render } from "@testing-library/react";
import JoystickRadar from "../JoystickRadar";

describe("JoystickRadar", () => {
  it("renders SVG element", () => {
    const { container } = render(<JoystickRadar x={0} y={0} />);
    const svg = container.querySelector("svg");
    expect(svg).toBeTruthy();
  });

  it("renders with correct viewBox", () => {
    const { container } = render(<JoystickRadar x={0} y={0} />);
    const svg = container.querySelector("svg");
    expect(svg?.getAttribute("viewBox")).toBe("0 0 300 300");
  });

  it("renders directional labels", () => {
    const { container } = render(<JoystickRadar x={0} y={0} />);
    const texts = container.querySelectorAll("text");
    const labels = Array.from(texts).map((t) => t.textContent);
    expect(labels).toContain("FWD");
    expect(labels).toContain("REV");
    expect(labels).toContain("LEFT");
    expect(labels).toContain("RIGHT");
  });

  it("renders concentric rings", () => {
    const { container } = render(<JoystickRadar x={0} y={0} />);
    const circles = container.querySelectorAll("circle");
    // Should have multiple circles for rings, center dot, and joystick indicator
    expect(circles.length).toBeGreaterThan(5);
  });

  it("renders joystick position indicator", () => {
    const { container } = render(<JoystickRadar x={0.5} y={-0.5} />);
    const groups = container.querySelectorAll("g");
    // Should have at least one group for the joystick indicator
    expect(groups.length).toBeGreaterThan(0);
  });

  it("handles edge case values (center position)", () => {
    const { container } = render(<JoystickRadar x={0} y={0} />);
    const svg = container.querySelector("svg");
    expect(svg).toBeTruthy();
  });

  it("handles edge case values (max positive)", () => {
    const { container } = render(<JoystickRadar x={1} y={1} />);
    const svg = container.querySelector("svg");
    expect(svg).toBeTruthy();
  });

  it("handles edge case values (max negative)", () => {
    const { container } = render(<JoystickRadar x={-1} y={-1} />);
    const svg = container.querySelector("svg");
    expect(svg).toBeTruthy();
  });

  it("applies glow filter", () => {
    const { container } = render(<JoystickRadar x={0} y={0} />);
    const filter = container.querySelector("filter");
    expect(filter?.getAttribute("id")).toBe("glow");
  });

  it("renders crosshair lines", () => {
    const { container } = render(<JoystickRadar x={0} y={0} />);
    const lines = container.querySelectorAll("line");
    // Should have multiple lines for crosshairs
    expect(lines.length).toBeGreaterThanOrEqual(4);
  });
});
