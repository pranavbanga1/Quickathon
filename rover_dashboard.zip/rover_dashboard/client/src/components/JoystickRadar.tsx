interface JoystickRadarProps {
  x: number;
  y: number;
}

export default function JoystickRadar({ x, y }: JoystickRadarProps) {
  // Normalize joystick values (-1 to 1) to SVG coordinates (0 to 300)
  const centerX = 150;
  const centerY = 150;
  const radius = 100;
  const dotX = centerX + x * radius;
  const dotY = centerY + y * radius;

  return (
    <div className="flex flex-col items-center justify-center">
      <svg
        width="300"
        height="300"
        viewBox="0 0 300 300"
        className="w-full max-w-xs"
        style={{
          filter:
            "drop-shadow(0 0 20px oklch(0.65 0.22 262 / 0.2)) drop-shadow(0 0 40px oklch(0.65 0.22 262 / 0.1))",
        }}
      >
        {/* Background circle with glow */}
        <circle
          cx={centerX}
          cy={centerY}
          r={radius + 20}
          fill="none"
          stroke="oklch(0.3 0.02 262 / 25%)"
          strokeWidth="1.5"
        />

        {/* Outer glow ring */}
        <circle
          cx={centerX}
          cy={centerY}
          r={radius + 22}
          fill="none"
          stroke="oklch(0.65 0.22 262 / 0.15)"
          strokeWidth="0.5"
        />

        {/* Concentric rings - enhanced */}
        {[1, 2, 3, 4].map((ring) => (
          <circle
            key={`ring-${ring}`}
            cx={centerX}
            cy={centerY}
            r={(radius / 4) * ring}
            fill="none"
            stroke={`oklch(0.3 0.02 262 / ${40 - ring * 5}%)`}
            strokeWidth="0.75"
            opacity={1 - ring * 0.1}
          />
        ))}

        {/* Crosshair lines - enhanced */}
        <line
          x1={centerX}
          y1={centerY - radius - 22}
          x2={centerX}
          y2={centerY + radius + 22}
          stroke="oklch(0.3 0.02 262 / 35%)"
          strokeWidth="0.75"
        />
        <line
          x1={centerX - radius - 22}
          y1={centerY}
          x2={centerX + radius + 22}
          y2={centerY}
          stroke="oklch(0.3 0.02 262 / 35%)"
          strokeWidth="0.75"
        />

        {/* Diagonal crosshair lines for sci-fi effect */}
        <line
          x1={centerX - radius * 0.7}
          y1={centerY - radius * 0.7}
          x2={centerX + radius * 0.7}
          y2={centerY + radius * 0.7}
          stroke="oklch(0.3 0.02 262 / 15%)"
          strokeWidth="0.5"
          strokeDasharray="3,3"
        />
        <line
          x1={centerX + radius * 0.7}
          y1={centerY - radius * 0.7}
          x2={centerX - radius * 0.7}
          y2={centerY + radius * 0.7}
          stroke="oklch(0.3 0.02 262 / 15%)"
          strokeWidth="0.5"
          strokeDasharray="3,3"
        />

        {/* Direction labels */}
        <text
          x={centerX}
          y={centerY - radius - 40}
          textAnchor="middle"
          fill="oklch(0.65 0.22 262)"
          fontSize="12"
          fontWeight="600"
          letterSpacing="1"
        >
          FWD
        </text>
        <text
          x={centerX}
          y={centerY + radius + 50}
          textAnchor="middle"
          fill="oklch(0.65 0.22 262)"
          fontSize="12"
          fontWeight="600"
          letterSpacing="1"
        >
          REV
        </text>
        <text
          x={centerX - radius - 40}
          y={centerY + 5}
          textAnchor="middle"
          fill="oklch(0.65 0.22 262)"
          fontSize="12"
          fontWeight="600"
          letterSpacing="1"
        >
          LEFT
        </text>
        <text
          x={centerX + radius + 40}
          y={centerY + 5}
          textAnchor="middle"
          fill="oklch(0.65 0.22 262)"
          fontSize="12"
          fontWeight="600"
          letterSpacing="1"
        >
          RIGHT
        </text>

        {/* Center dot */}
        <circle cx={centerX} cy={centerY} r="4" fill="oklch(0.5 0.01 262)" opacity="0.8" />

        {/* Joystick position indicator with enhanced glow */}
        <g>
          {/* Outer glow rings */}
          <circle
            cx={dotX}
            cy={dotY}
            r="16"
            fill="none"
            stroke="oklch(0.65 0.22 262 / 0.15)"
            strokeWidth="1"
            opacity="0.6"
          />
          <circle
            cx={dotX}
            cy={dotY}
            r="12"
            fill="none"
            stroke="oklch(0.65 0.22 262 / 0.3)"
            strokeWidth="1.5"
            opacity="0.8"
          />
          <circle
            cx={dotX}
            cy={dotY}
            r="8"
            fill="none"
            stroke="oklch(0.65 0.22 262 / 0.5)"
            strokeWidth="1.5"
            opacity="0.95"
          />
          {/* Main dot */}
          <circle cx={dotX} cy={dotY} r="6" fill="oklch(0.65 0.22 262)" filter="url(#glow)" />
        </g>

        {/* Glow filter definition */}
        <defs>
          <filter id="glow" x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur stdDeviation="3" result="coloredBlur" />
            <feMerge>
              <feMergeNode in="coloredBlur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>
      </svg>
    </div>
  );
}
