import { useState, useEffect } from "react";
import { X, Save, RotateCcw } from "lucide-react";

interface SettingsProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (config: ROS2Config) => void;
}

export interface ROS2Config {
  rosIP: string;
  rosPort: number;
  rosNamespace: string;
  autoConnect: boolean;
}

const DEFAULT_CONFIG: ROS2Config = {
  rosIP: "localhost",
  rosPort: 9090,
  rosNamespace: "/rover",
  autoConnect: true,
};

export default function Settings({ isOpen, onClose, onSave }: SettingsProps) {
  const [config, setConfig] = useState<ROS2Config>(DEFAULT_CONFIG);

  // Load saved config from localStorage on mount
  useEffect(() => {
    const saved = localStorage.getItem("ros2Config");
    if (saved) {
      try {
        setConfig(JSON.parse(saved));
      } catch (e) {
        console.error("Failed to load config:", e);
      }
    }
  }, [isOpen]);

  const handleSave = () => {
    localStorage.setItem("ros2Config", JSON.stringify(config));
    onSave(config);
    onClose();
  };

  const handleReset = () => {
    setConfig(DEFAULT_CONFIG);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="sci-fi-border rounded-2xl bg-card/95 backdrop-blur-sm max-w-md w-full p-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold glow-cyan">ROS 2 Configuration</h2>
          <button
            onClick={onClose}
            className="p-1 hover:bg-accent/20 rounded-lg transition-colors"
          >
            <X size={20} />
          </button>
        </div>

        {/* Form */}
        <div className="space-y-4 mb-6">
          {/* ROS IP */}
          <div>
            <label className="block text-sm font-semibold text-muted-foreground mb-2">
              ROS 2 Bridge IP
            </label>
            <input
              type="text"
              value={config.rosIP}
              onChange={(e) =>
                setConfig({ ...config, rosIP: e.target.value })
              }
              placeholder="localhost or 192.168.x.x"
              className="w-full px-3 py-2 bg-background border border-border rounded-lg text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent/50"
            />
            <p className="text-xs text-muted-foreground mt-1">
              IP address of the ROS 2 bridge server
            </p>
          </div>

          {/* ROS Port */}
          <div>
            <label className="block text-sm font-semibold text-muted-foreground mb-2">
              WebSocket Port
            </label>
            <input
              type="number"
              value={config.rosPort}
              onChange={(e) =>
                setConfig({ ...config, rosPort: parseInt(e.target.value) })
              }
              placeholder="9090"
              className="w-full px-3 py-2 bg-background border border-border rounded-lg text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent/50"
            />
            <p className="text-xs text-muted-foreground mt-1">
              WebSocket port for real-time data
            </p>
          </div>

          {/* ROS Namespace */}
          <div>
            <label className="block text-sm font-semibold text-muted-foreground mb-2">
              ROS Namespace
            </label>
            <input
              type="text"
              value={config.rosNamespace}
              onChange={(e) =>
                setConfig({ ...config, rosNamespace: e.target.value })
              }
              placeholder="/rover"
              className="w-full px-3 py-2 bg-background border border-border rounded-lg text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent/50"
            />
            <p className="text-xs text-muted-foreground mt-1">
              ROS 2 namespace for topics (e.g., /rover)
            </p>
          </div>

          {/* Auto Connect */}
          <div className="flex items-center gap-3">
            <input
              type="checkbox"
              id="autoConnect"
              checked={config.autoConnect}
              onChange={(e) =>
                setConfig({ ...config, autoConnect: e.target.checked })
              }
              className="w-4 h-4 rounded cursor-pointer"
            />
            <label
              htmlFor="autoConnect"
              className="text-sm font-semibold text-muted-foreground cursor-pointer"
            >
              Auto-connect on startup
            </label>
          </div>
        </div>

        {/* Info Box */}
        <div className="bg-background/50 border border-border rounded-lg p-3 mb-6">
          <p className="text-xs text-muted-foreground">
            <strong>Quick Start:</strong> Run the ROS 2 bridge on your rover
            system, then enter its IP address here. The dashboard will connect
            automatically.
          </p>
        </div>

        {/* Actions */}
        <div className="flex gap-3">
          <button
            onClick={handleReset}
            className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-background border border-border rounded-lg hover:bg-accent/10 transition-colors text-sm font-semibold"
          >
            <RotateCcw size={16} />
            Reset
          </button>
          <button
            onClick={handleSave}
            className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-accent text-accent-foreground rounded-lg hover:bg-accent/90 transition-colors text-sm font-semibold glow-blue"
          >
            <Save size={16} />
            Save
          </button>
        </div>
      </div>
    </div>
  );
}
