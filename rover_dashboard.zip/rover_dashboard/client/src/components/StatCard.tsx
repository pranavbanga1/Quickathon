interface StatCardProps {
  label: string;
  value: string;
  unit?: string;
  subtitle?: string;
  status?: "GOOD" | "WARNING" | "CRITICAL";
  icon?: string;
}

export default function StatCard({
  label,
  value,
  unit,
  subtitle,
  status,
  icon,
}: StatCardProps) {
  const statusColors = {
    GOOD: "text-green-400 border-green-400/50",
    WARNING: "text-yellow-400 border-yellow-400/50",
    CRITICAL: "text-red-400 border-red-400/50",
  };

  return (
    <div className="sci-fi-border rounded-xl p-4 bg-card/50 backdrop-blur-sm">
      <div className="flex items-start justify-between mb-3">
        <div className="text-xs font-semibold text-muted-foreground tracking-wider">
          {label}
        </div>
        {icon && <span className="text-lg">{icon}</span>}
      </div>

      {status ? (
        <div
          className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-full border ${statusColors[status]}`}
        >
          <div className="w-2 h-2 rounded-full bg-current"></div>
          <span className="font-bold text-sm">{value}</span>
        </div>
      ) : (
        <div className="flex items-baseline gap-1">
          <div className="text-2xl font-bold text-cyan-400">{value}</div>
          {unit && <div className="text-sm text-muted-foreground">{unit}</div>}
        </div>
      )}

      {subtitle && (
        <div className="text-xs text-muted-foreground mt-2">{subtitle}</div>
      )}
    </div>
  );
}
