import { useEffect, useState } from "react";
import { APP_LOGO, APP_TITLE } from "@/const";
import JoystickRadar from "@/components/JoystickRadar";
import StatCard from "@/components/StatCard";
import NetworkChart from "@/components/NetworkChart";
import Settings, { ROS2Config } from "@/components/Settings";
import ConnectionStatus from "@/components/ConnectionStatus";
import { Signal, Settings as SettingsIcon } from "lucide-react";
import { useROS2Connection } from "@/hooks/useROS2Connection";

interface DashboardData {
  latency: number;
  packetLoss: number;
  signalStrength: number;
  systemStatus: "GOOD" | "WARNING" | "CRITICAL";
  joystickX: number;
  joystickY: number;
  txThroughput: number;
  rxThroughput: number;
  networkHistory: Array<{ tx: number; rx: number; timestamp: number }>;
}

export default function Home() {
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [config, setConfig] = useState<ROS2Config>({
    rosIP: "localhost",
    rosPort: 9090,
    rosNamespace: "/rover",
    autoConnect: true,
  });

  const [data, setData] = useState<DashboardData>({
    latency: 36.4,
    packetLoss: 0.05,
    signalStrength: -74,
    systemStatus: "GOOD",
    joystickX: -0.29,
    joystickY: -0.45,
    txThroughput: 45.3,
    rxThroughput: 64.4,
    networkHistory: [],
  });

  const [time, setTime] = useState<string>("");
  const [useSimulation, setUseSimulation] = useState(true);

  // Load config from localStorage on mount
  useEffect(() => {
    const saved = localStorage.getItem("ros2Config");
    if (saved) {
      try {
        const parsedConfig = JSON.parse(saved);
        setConfig(parsedConfig);
        setUseSimulation(false); // Use ROS 2 connection if config exists
      } catch (e) {
        console.error("Failed to load config:", e);
      }
    }
  }, []);

  // ROS 2 Connection Hook
  const { state: connectionState, data: rosData, error: connectionError, connect: reconnect } = useROS2Connection({
    ip: config.rosIP,
    port: config.rosPort,
    namespace: config.rosNamespace,
    autoConnect: config.autoConnect && !useSimulation,
  });

  // Update data from ROS 2 or simulation
  useEffect(() => {
    if (rosData && !useSimulation) {
      setData((prev) => ({
        ...prev,
        latency: rosData.latency,
        packetLoss: rosData.packetLoss,
        signalStrength: rosData.signalStrength,
        systemStatus: rosData.systemStatus,
        joystickX: rosData.joystickX,
        joystickY: rosData.joystickY,
        txThroughput: rosData.txThroughput,
        rxThroughput: rosData.rxThroughput,
        networkHistory: [
          ...prev.networkHistory.slice(-59),
          { tx: rosData.txThroughput, rx: rosData.rxThroughput, timestamp: Date.now() },
        ],
      }));
    }
  }, [rosData, useSimulation]);

  // Update time every second
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const hours = String(now.getHours()).padStart(2, "0");
      const minutes = String(now.getMinutes()).padStart(2, "0");
      const seconds = String(now.getSeconds()).padStart(2, "0");
      setTime(`${hours}:${minutes}:${seconds}`);
    };

    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  // Simulate real-time data updates (when not using ROS 2)
  useEffect(() => {
    if (!useSimulation) return; // Skip simulation if using ROS 2

    const interval = setInterval(() => {
      setData((prev) => {
        const newLatency = 30 + Math.random() * 20;
        const newPacketLoss = Math.max(0, Math.random() * 0.2);
        const newSignalStrength = -80 + Math.random() * 15;
        const newJoystickX = (Math.random() - 0.5) * 2;
        const newJoystickY = (Math.random() - 0.5) * 2;
        const newTx = 30 + Math.random() * 40;
        const newRx = 40 + Math.random() * 50;

        const newHistory = [
          ...prev.networkHistory.slice(-59),
          { tx: newTx, rx: newRx, timestamp: Date.now() },
        ];

        return {
          ...prev,
          latency: newLatency,
          packetLoss: newPacketLoss,
          signalStrength: newSignalStrength,
          joystickX: newJoystickX,
          joystickY: newJoystickY,
          txThroughput: newTx,
          rxThroughput: newRx,
          networkHistory: newHistory,
          systemStatus:
            newLatency > 80 || newPacketLoss > 0.1
              ? "WARNING"
              : newLatency > 150 || newPacketLoss > 0.2
                ? "CRITICAL"
                : "GOOD",
        };
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [useSimulation]);

  const handleSettingsSave = (newConfig: ROS2Config) => {
    setConfig(newConfig);
    setUseSimulation(false);
    // Reconnect with new config
    reconnect();
  };

  return (
    <div className="min-h-screen bg-background text-foreground p-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center gap-3">
          <div className="w-3 h-3 rounded-full bg-cyan-400 animate-pulse"></div>
          <h1 className="text-2xl font-bold glow-cyan">{APP_TITLE}</h1>
        </div>
        <div className="flex items-center gap-4">
          <div className="text-right">
            <div className="text-lg font-mono font-bold">{time}</div>
          </div>
          <div className="flex items-center gap-2 px-3 py-2 rounded-full border sci-fi-border">
            <Signal size={16} className="text-cyan-400" />
            <span className="text-sm font-semibold">LTE</span>
          </div>
          <button
            onClick={() => setSettingsOpen(true)}
            className="p-2 hover:bg-accent/20 rounded-lg transition-colors"
            title="Settings"
          >
            <SettingsIcon size={20} className="text-cyan-400" />
          </button>
        </div>
      </div>

      {/* Connection Status */}
      {!useSimulation && (
        <div className="mb-6">
          <ConnectionStatus
            state={connectionState}
            message={
              connectionError
                ? connectionError
                : connectionState === "connected"
                  ? `Connected to ${config.rosIP}:${config.rosPort}`
                  : undefined
            }
            onRetry={reconnect}
          />
        </div>
      )}

      {/* Simulation Mode Notice */}
      {useSimulation && (
        <div className="mb-6 bg-yellow-400/10 border border-yellow-400/30 rounded-lg p-3">
          <p className="text-xs text-yellow-400 font-semibold">
            📊 Running in simulation mode. Configure ROS 2 connection in settings to use real rover data.
          </p>
        </div>
      )}

      {/* Main Dashboard Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Panel - Joystick Radar */}
        <div className="lg:col-span-1">
          <div className="sci-fi-border rounded-2xl p-6 bg-card/50 backdrop-blur-sm h-full">
            <JoystickRadar x={data.joystickX} y={data.joystickY} />
            <div className="mt-8 text-center">
              <div className="text-sm font-mono text-muted-foreground mb-2">
                JOYSTICK INPUT
              </div>
              <div className="text-cyan-400 font-mono font-bold">
                X: {data.joystickX.toFixed(2)} | Y: {data.joystickY.toFixed(2)}
              </div>
            </div>
          </div>
        </div>

        {/* Right Panel - Stats and Chart */}
        <div className="lg:col-span-2 space-y-6">
          {/* Stat Cards Grid */}
          <div className="grid grid-cols-2 gap-4">
            <StatCard
              label="LATENCY"
              value={data.latency.toFixed(1)}
              unit="ms"
              subtitle="Optimal range"
              icon="⚡"
            />
            <StatCard
              label="SYSTEM STATUS"
              value={data.systemStatus}
              status={data.systemStatus}
              icon="✓"
            />
            <StatCard
              label="PACKET LOSS"
              value={data.packetLoss.toFixed(2)}
              unit="%"
              icon="📡"
            />
            <StatCard
              label="SIGNAL STRENGTH"
              value={data.signalStrength.toFixed(0)}
              unit="dBm"
              icon="📶"
            />
          </div>

          {/* Network Traffic Chart */}
          <div className="sci-fi-border rounded-2xl p-6 bg-card/50 backdrop-blur-sm">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-semibold text-muted-foreground">
                NETWORK TRAFFIC
              </h3>
              <div className="text-xs text-muted-foreground">
                Last updated: 1 sec ago
              </div>
            </div>
            <div className="flex items-end justify-between mb-4 gap-4">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <div className="text-xs text-cyan-400">↑</div>
                  <span className="text-xs text-muted-foreground">TX</span>
                </div>
                <div className="text-xl font-bold">
                  {data.txThroughput.toFixed(1)}{" "}
                  <span className="text-sm text-muted-foreground">Mbps</span>
                </div>
              </div>
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <div className="text-xs text-cyan-400">↓</div>
                  <span className="text-xs text-muted-foreground">RX</span>
                </div>
                <div className="text-xl font-bold">
                  {data.rxThroughput.toFixed(1)}{" "}
                  <span className="text-sm text-muted-foreground">Mbps</span>
                </div>
              </div>
            </div>
            <NetworkChart data={data.networkHistory} />
          </div>
        </div>
      </div>

      {/* Settings Modal */}
      <Settings
        isOpen={settingsOpen}
        onClose={() => setSettingsOpen(false)}
        onSave={handleSettingsSave}
      />
    </div>
  );
}
