import { useState, useEffect, useCallback, useRef } from "react";

export interface ROS2Data {
  latency: number;
  packetLoss: number;
  signalStrength: number;
  txThroughput: number;
  rxThroughput: number;
  joystickX: number;
  joystickY: number;
  systemStatus: "GOOD" | "WARNING" | "CRITICAL";
  timestamp: number;
}

type ConnectionState = "connected" | "connecting" | "disconnected" | "error";

interface UseROS2ConnectionOptions {
  ip: string;
  port: number;
  namespace?: string;
  autoConnect?: boolean;
}

export function useROS2Connection({
  ip,
  port,
  namespace = "/rover",
  autoConnect = true,
}: UseROS2ConnectionOptions) {
  const [state, setState] = useState<ConnectionState>("disconnected");
  const [data, setData] = useState<ROS2Data | null>(null);
  const [error, setError] = useState<string | null>(null);
  const wsRef = useRef<WebSocket | null>(null);
  const reconnectTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const connect = useCallback(() => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      return; // Already connected
    }

    setState("connecting");
    setError(null);

    try {
      const wsUrl = `ws://${ip}:${port}`;
      const ws = new WebSocket(wsUrl);

      ws.onopen = () => {
        console.log("Connected to ROS 2 bridge");
        setState("connected");
        setError(null);

        // Send subscription request
        ws.send(
          JSON.stringify({
            type: "subscribe",
            namespace,
            topics: [
              "network_health",
              "joystick_input",
              "system_status",
            ],
          })
        );
      };

      ws.onmessage = (event) => {
        try {
          const message = JSON.parse(event.data);

          if (message.type === "data") {
            setData({
              latency: message.data.latency ?? 0,
              packetLoss: message.data.packetLoss ?? 0,
              signalStrength: message.data.signalStrength ?? -80,
              txThroughput: message.data.txThroughput ?? 0,
              rxThroughput: message.data.rxThroughput ?? 0,
              joystickX: message.data.joystickX ?? 0,
              joystickY: message.data.joystickY ?? 0,
              systemStatus: message.data.systemStatus ?? "GOOD",
              timestamp: Date.now(),
            });
          }
        } catch (e) {
          console.error("Failed to parse message:", e);
        }
      };

      ws.onerror = (event) => {
        console.error("WebSocket error:", event);
        setState("error");
        setError("Failed to connect to ROS 2 bridge");
      };

      ws.onclose = () => {
        console.log("Disconnected from ROS 2 bridge");
        setState("disconnected");
        wsRef.current = null;

        // Auto-reconnect after 3 seconds
        if (autoConnect) {
          reconnectTimeoutRef.current = setTimeout(() => {
            connect();
          }, 3000);
        }
      };

      wsRef.current = ws;
    } catch (e) {
      console.error("Connection error:", e);
      setState("error");
      setError(String(e));
    }
  }, [ip, port, namespace, autoConnect]);

  const disconnect = useCallback(() => {
    if (reconnectTimeoutRef.current) {
      clearTimeout(reconnectTimeoutRef.current);
    }
    if (wsRef.current) {
      wsRef.current.close();
      wsRef.current = null;
    }
    setState("disconnected");
  }, []);

  // Auto-connect on mount if enabled
  useEffect(() => {
    if (autoConnect) {
      connect();
    }

    return () => {
      disconnect();
    };
  }, [autoConnect, connect, disconnect]);

  return {
    state,
    data,
    error,
    connect,
    disconnect,
  };
}
