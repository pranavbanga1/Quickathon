#!/usr/bin/env node

/**
 * ROS 2 WebSocket Bridge
 * 
 * This server bridges ROS 2 topics to WebSocket clients.
 * It subscribes to ROS 2 topics and forwards data to connected dashboard clients.
 * 
 * Usage:
 *   node ros2-bridge.mjs [--port 9090] [--namespace /rover]
 * 
 * Environment variables:
 *   ROS_DOMAIN_ID - ROS 2 domain ID (default: 0)
 *   BRIDGE_PORT - WebSocket port (default: 9090)
 *   ROS_NAMESPACE - ROS namespace (default: /rover)
 */

import WebSocket from 'ws';
import { createServer } from 'http';
import { spawn } from 'child_process';
import { EventEmitter } from 'events';

// Configuration
const PORT = parseInt(process.env.BRIDGE_PORT || '9090');
const NAMESPACE = process.env.ROS_NAMESPACE || '/rover';
const ROS_DOMAIN_ID = process.env.ROS_DOMAIN_ID || '0';

// ROS 2 Topic Subscriptions
const TOPICS = {
  networkHealth: `${NAMESPACE}/network_health`,
  joystickInput: `${NAMESPACE}/joystick_input`,
  systemStatus: `${NAMESPACE}/system_status`,
};

// Data store
const dataStore = new EventEmitter();
let latestData = {
  latency: 0,
  packetLoss: 0,
  signalStrength: -80,
  txThroughput: 0,
  rxThroughput: 0,
  joystickX: 0,
  joystickY: 0,
  systemStatus: 'GOOD',
};

/**
 * Parse ROS 2 message output
 */
function parseROS2Message(output) {
  try {
    // Try to parse as JSON first (if using ros2 topic echo --format json)
    return JSON.parse(output);
  } catch {
    // Fallback: parse key-value format
    const data = {};
    const lines = output.split('\n');
    
    for (const line of lines) {
      const match = line.match(/^\s*(\w+):\s*(.+)$/);
      if (match) {
        const [, key, value] = match;
        // Try to parse as number
        data[key] = isNaN(value) ? value : parseFloat(value);
      }
    }
    
    return data;
  }
}

/**
 * Subscribe to a ROS 2 topic
 */
function subscribeToTopic(topicName, callback) {
  console.log(`[ROS2] Subscribing to topic: ${topicName}`);
  
  const process = spawn('ros2', ['topic', 'echo', topicName, '--format', 'json'], {
    env: {
      ...process.env,
      ROS_DOMAIN_ID,
    },
  });

  let buffer = '';

  process.stdout.on('data', (data) => {
    buffer += data.toString();
    const lines = buffer.split('\n');
    
    // Process complete lines
    for (let i = 0; i < lines.length - 1; i++) {
      try {
        const message = JSON.parse(lines[i]);
        callback(message);
      } catch (e) {
        // Skip invalid JSON lines
      }
    }
    
    // Keep incomplete line in buffer
    buffer = lines[lines.length - 1];
  });

  process.stderr.on('data', (data) => {
    console.error(`[ROS2 Error] ${data}`);
  });

  process.on('close', (code) => {
    console.log(`[ROS2] Topic subscription ended with code ${code}`);
    // Attempt to reconnect after 3 seconds
    setTimeout(() => subscribeToTopic(topicName, callback), 3000);
  });

  return process;
}

/**
 * Map ROS 2 messages to dashboard data
 */
function updateDataFromROS2(topicName, message) {
  if (topicName === TOPICS.networkHealth) {
    // Expected fields: latency_ms, packet_loss_pct, signal_strength_dbm, tx_mbps, rx_mbps
    latestData = {
      ...latestData,
      latency: message.latency_ms ?? message.latency ?? latestData.latency,
      packetLoss: message.packet_loss_pct ?? message.packet_loss ?? latestData.packetLoss,
      signalStrength: message.signal_strength_dbm ?? message.signal_strength ?? latestData.signalStrength,
      txThroughput: message.tx_mbps ?? message.tx ?? latestData.txThroughput,
      rxThroughput: message.rx_mbps ?? message.rx ?? latestData.rxThroughput,
    };
  } else if (topicName === TOPICS.joystickInput) {
    // Expected fields: x, y, buttons
    latestData = {
      ...latestData,
      joystickX: message.x ?? message.axes?.[0] ?? latestData.joystickX,
      joystickY: message.y ?? message.axes?.[1] ?? latestData.joystickY,
    };
  } else if (topicName === TOPICS.systemStatus) {
    // Expected fields: status (GOOD, WARNING, CRITICAL)
    latestData = {
      ...latestData,
      systemStatus: message.status ?? message.state ?? latestData.systemStatus,
    };
  }
  
  dataStore.emit('update', latestData);
}

/**
 * Create HTTP server with WebSocket
 */
const server = createServer();
const wss = new WebSocket.Server({ server });

wss.on('connection', (ws) => {
  console.log('[WS] Client connected');
  
  // Send initial data
  ws.send(JSON.stringify({
    type: 'data',
    data: latestData,
  }));

  // Listen for subscription requests
  ws.on('message', (message) => {
    try {
      const request = JSON.parse(message);
      
      if (request.type === 'subscribe') {
        console.log(`[WS] Client subscribed to topics in namespace: ${request.namespace}`);
        // Client is now subscribed, will receive updates
      }
    } catch (e) {
      console.error('[WS] Failed to parse message:', e);
    }
  });

  ws.on('close', () => {
    console.log('[WS] Client disconnected');
  });

  ws.on('error', (error) => {
    console.error('[WS] Client error:', error);
  });
});

// Send data updates to all connected clients
dataStore.on('update', (data) => {
  const message = JSON.stringify({
    type: 'data',
    data,
  });

  wss.clients.forEach((client) => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(message);
    }
  });
});

/**
 * Initialize ROS 2 subscriptions
 */
function initializeROS2Subscriptions() {
  console.log('[ROS2] Initializing subscriptions...');
  
  // Check if ROS 2 is available
  const checkROS = spawn('ros2', ['--version']);
  
  checkROS.on('close', (code) => {
    if (code !== 0) {
      console.warn('[ROS2] ROS 2 not found. Running in simulation mode.');
      console.warn('[ROS2] To use real rover data, ensure ROS 2 is installed and sourced.');
      
      // Simulate data for testing
      simulateROS2Data();
    } else {
      console.log('[ROS2] ROS 2 found. Subscribing to topics...');
      
      // Subscribe to each topic
      subscribeToTopic(TOPICS.networkHealth, (msg) => updateDataFromROS2(TOPICS.networkHealth, msg));
      subscribeToTopic(TOPICS.joystickInput, (msg) => updateDataFromROS2(TOPICS.joystickInput, msg));
      subscribeToTopic(TOPICS.systemStatus, (msg) => updateDataFromROS2(TOPICS.systemStatus, msg));
    }
  });
}

/**
 * Simulate ROS 2 data for testing
 */
function simulateROS2Data() {
  setInterval(() => {
    latestData = {
      latency: 30 + Math.random() * 20,
      packetLoss: Math.max(0, Math.random() * 0.2),
      signalStrength: -80 + Math.random() * 15,
      txThroughput: 30 + Math.random() * 40,
      rxThroughput: 40 + Math.random() * 50,
      joystickX: (Math.random() - 0.5) * 2,
      joystickY: (Math.random() - 0.5) * 2,
      systemStatus: Math.random() > 0.8 ? 'WARNING' : 'GOOD',
    };
    
    dataStore.emit('update', latestData);
  }, 1000);
}

/**
 * Start server
 */
server.listen(PORT, () => {
  console.log(`\n🚀 ROS 2 WebSocket Bridge started on ws://0.0.0.0:${PORT}`);
  console.log(`📡 ROS Namespace: ${NAMESPACE}`);
  console.log(`🌍 Connect dashboard to: ws://localhost:${PORT}\n`);
  
  initializeROS2Subscriptions();
});

/**
 * Graceful shutdown
 */
process.on('SIGINT', () => {
  console.log('\n[Server] Shutting down gracefully...');
  wss.clients.forEach((client) => client.close());
  server.close(() => {
    console.log('[Server] Closed');
    process.exit(0);
  });
});

process.on('SIGTERM', () => {
  console.log('\n[Server] Shutting down gracefully...');
  wss.clients.forEach((client) => client.close());
  server.close(() => {
    console.log('[Server] Closed');
    process.exit(0);
  });
});
