# 🚀 TASC Rover Dashboard

A high-fidelity, real-time monitoring dashboard for the TASC rover team. Built with React, TypeScript, and Tailwind CSS with a modern sci-fi interface. Connects to ROS 2 via WebSocket bridge for live network and joystick monitoring.

## ✨ Features

- **Real-time Network Monitoring**: Latency, packet loss, signal strength, TX/RX throughput
- **Interactive Joystick Visualization**: 2D radar-style display with glowing indicators
- **ROS 2 Integration**: WebSocket bridge for seamless rover data streaming
- **Dynamic IP Configuration**: Switch between rovers without code changes
- **Sci-Fi Dark Theme**: Modern UI with neon blue/cyan accents and smooth animations
- **Responsive Design**: Works on desktop and tablet browsers
- **Simulation Mode**: Test without ROS 2 (perfect for development)

## 🎯 Quick Start (Hackathon)

### Prerequisites

- Node.js 18+ and pnpm
- ROS 2 Humble (optional, for real rover data)
- Modern web browser (Chrome, Firefox, Safari, Edge)

### Option 1: Run Locally (Simulation Mode)

```bash
# Install dependencies
pnpm install

# Start development server
pnpm dev

# Open browser to http://localhost:3000
```

The dashboard will run in **simulation mode** with mock data. Perfect for testing the UI!

### Option 2: Connect to Real Rover (ROS 2)

#### Step 1: Start ROS 2 Bridge on Rover System

On your rover (or VM with ROS 2):

```bash
# Terminal 1: Source ROS 2
source /opt/ros/humble/setup.bash

# Terminal 2: Start the WebSocket bridge
cd /path/to/rover_dashboard
node ros2-bridge.mjs --port 9090 --namespace /rover

# Output should show:
# 🚀 ROS 2 WebSocket Bridge started on ws://0.0.0.0:9090
```

#### Step 2: Configure Dashboard

1. Open dashboard in browser: `http://localhost:3000`
2. Click **⚙️ Settings** (top-right)
3. Enter rover IP: `192.168.x.x` (or `localhost` if on same machine)
4. Enter port: `9090`
5. Click **Save**

Dashboard will auto-connect and start displaying real rover data!

## 🏗️ Architecture

```
┌─────────────────────────────────────────┐
│         Rover Dashboard (Browser)       │
│  React + TypeScript + Tailwind CSS      │
│  - Real-time UI updates                 │
│  - WebSocket client                     │
│  - Settings/Config management           │
└──────────────┬──────────────────────────┘
               │ WebSocket (ws://)
               │
┌──────────────▼──────────────────────────┐
│     ROS 2 WebSocket Bridge (Node.js)    │
│  ros2-bridge.mjs                        │
│  - Subscribes to ROS 2 topics           │
│  - Forwards data to dashboard           │
│  - Handles reconnection                 │
└──────────────┬──────────────────────────┘
               │ ROS 2 IPC
               │
┌──────────────▼──────────────────────────┐
│         ROS 2 Rover System              │
│  - Network health topics                │
│  - Joystick input topics                │
│  - System status topics                 │
└─────────────────────────────────────────┘
```

## 📡 ROS 2 Topic Mapping

The bridge expects these ROS 2 topics (customize in `ros2-bridge.mjs`):

### Network Health Topic
```
Topic: /rover/network_health
Message Type: custom or std_msgs/Float32MultiArray
Fields:
  - latency_ms: float (milliseconds)
  - packet_loss_pct: float (0-100%)
  - signal_strength_dbm: float (dBm)
  - tx_mbps: float (Mbps)
  - rx_mbps: float (Mbps)
```

### Joystick Input Topic
```
Topic: /rover/joystick_input
Message Type: sensor_msgs/Joy or custom
Fields:
  - x: float (-1.0 to 1.0)
  - y: float (-1.0 to 1.0)
```

### System Status Topic
```
Topic: /rover/system_status
Message Type: custom or std_msgs/String
Fields:
  - status: string ("GOOD" | "WARNING" | "CRITICAL")
```

## 🔧 Configuration

### Environment Variables

Create `.env` file in project root:

```bash
# ROS 2 Bridge Settings
BRIDGE_PORT=9090
ROS_NAMESPACE=/rover
ROS_DOMAIN_ID=0

# Dashboard Settings
VITE_APP_TITLE=Rover Dashboard
VITE_APP_ID=rover-dashboard
```

### Custom ROS Topics

Edit `ros2-bridge.mjs` line 28-32:

```javascript
const TOPICS = {
  networkHealth: `${NAMESPACE}/your_network_topic`,
  joystickInput: `${NAMESPACE}/your_joystick_topic`,
  systemStatus: `${NAMESPACE}/your_status_topic`,
};
```

## 📦 Deployment

### Build for Production

```bash
# Build frontend
pnpm build

# Output: dist/public/

# Copy to your rover system
scp -r dist/public/* rover@192.168.x.x:/var/www/html/
```

### Docker Deployment (Optional)

```dockerfile
FROM node:18-alpine

WORKDIR /app

# Copy bridge
COPY ros2-bridge.mjs .
COPY package.json package-lock.json ./
RUN npm install

# Copy built dashboard
COPY dist/public ./public

EXPOSE 9090

CMD ["node", "ros2-bridge.mjs"]
```

Build and run:
```bash
docker build -t rover-dashboard .
docker run -p 9090:9090 rover-dashboard
```

## 🧪 Testing

### Run Unit Tests

```bash
pnpm exec vitest run

# Output: 33 tests passing
```

### Manual Testing Checklist

- [ ] Dashboard loads without errors
- [ ] Simulation mode shows updating data
- [ ] Settings modal opens and saves config
- [ ] Joystick indicator moves smoothly
- [ ] Network chart updates in real-time
- [ ] Status badges change colors correctly
- [ ] Connection status indicator works
- [ ] Responsive layout on mobile/tablet

## 🎨 Customization

### Change Color Scheme

Edit `client/src/index.css` (dark theme colors):

```css
.dark {
  --primary: oklch(0.65 0.22 262);  /* Neon blue */
  --accent: oklch(0.65 0.22 262);   /* Cyan */
  --background: oklch(0.08 0.01 262); /* Deep navy */
}
```

### Add More Metrics

1. Add field to `ROS2Data` interface in `client/src/hooks/useROS2Connection.ts`
2. Create new `StatCard` in `client/src/pages/Home.tsx`
3. Update ROS 2 bridge to parse new topic

### Modify Joystick Visualization

Edit `client/src/components/JoystickRadar.tsx` to customize:
- Ring count and styling
- Glow effects
- Direction labels
- Indicator size/color

## 🐛 Troubleshooting

### Dashboard won't connect to bridge

1. Check bridge is running: `ps aux | grep ros2-bridge`
2. Verify IP/port in settings
3. Check firewall: `sudo ufw allow 9090`
4. Test connection: `nc -zv 192.168.x.x 9090`

### ROS 2 topics not showing data

1. Verify topics exist: `ros2 topic list`
2. Check message format: `ros2 topic echo /rover/network_health`
3. Ensure topic names match in bridge config
4. Check ROS_DOMAIN_ID matches

### UI not updating

1. Open browser console (F12) for errors
2. Check WebSocket connection in Network tab
3. Verify bridge is sending data: `node ros2-bridge.mjs` (should show "Client connected")

## 📊 Performance

- **Update Frequency**: 1 Hz (1 second)
- **Network Latency**: < 50ms typical
- **CPU Usage**: < 5% (bridge), < 10% (dashboard)
- **Memory**: ~50MB (bridge), ~100MB (dashboard)

## 🚀 Future Enhancements

- [ ] Historical data logging and playback
- [ ] Multi-rover dashboard (monitor multiple rovers)
- [ ] Alert thresholds and notifications
- [ ] Data export (CSV/JSON)
- [ ] Mobile app version
- [ ] Voice alerts for critical events
- [ ] Custom metric plugins
- [ ] Dark/light theme toggle

## 📝 Project Structure

```
rover_dashboard/
├── client/                          # React frontend
│   ├── src/
│   │   ├── components/             # Reusable UI components
│   │   │   ├── JoystickRadar.tsx
│   │   │   ├── StatCard.tsx
│   │   │   ├── NetworkChart.tsx
│   │   │   ├── Settings.tsx
│   │   │   └── ConnectionStatus.tsx
│   │   ├── hooks/
│   │   │   └── useROS2Connection.ts # WebSocket hook
│   │   ├── pages/
│   │   │   └── Home.tsx            # Main dashboard
│   │   ├── index.css               # Tailwind + custom styles
│   │   └── main.tsx
│   └── public/                     # Static assets
├── ros2-bridge.mjs                 # ROS 2 WebSocket bridge
├── package.json
├── vite.config.ts
├── vitest.config.ts
└── README.md
```

## 📄 License

MIT License - Feel free to use and modify!

## 🤝 Support

For hackathon support:
1. Check troubleshooting section above
2. Review ROS 2 topic mapping
3. Test bridge independently: `node ros2-bridge.mjs`
4. Check browser console for errors

---

**Good luck at the hackathon! 🏆**

Built with ❤️ for TASC Comms & Controls
