# 🚀 Quick Start Guide - TASC Rover Dashboard

## For the Hackathon (30 seconds setup)

### Step 1: Install & Run (Simulation Mode)
```bash
cd rover_dashboard
pnpm install
pnpm dev
```
Open browser: **http://localhost:3000**

✅ Dashboard is running! You'll see simulated rover data.

---

## When You Have ROS 2 Running

### Step 2: Start the ROS 2 Bridge
On your rover system (or VM with ROS 2):
```bash
cd rover_dashboard
node ros2-bridge.mjs
```

You should see:
```
🚀 ROS 2 WebSocket Bridge started on ws://0.0.0.0:9090
📡 ROS Namespace: /rover
```

### Step 3: Connect Dashboard to Bridge
1. Click **⚙️ Settings** (top-right of dashboard)
2. Enter rover IP: `192.168.x.x` (or `localhost` if same machine)
3. Port: `9090`
4. Click **Save**

✅ Dashboard will auto-connect and show real rover data!

---

## Troubleshooting

| Problem | Solution |
|---------|----------|
| Dashboard won't load | Check port 3000 is available: `lsof -i :3000` |
| Bridge won't start | Ensure Node.js 18+ installed: `node --version` |
| Can't connect to bridge | Check firewall: `sudo ufw allow 9090` |
| No ROS 2 data | Verify topics exist: `ros2 topic list` |

---

## Key Features

✨ **Real-time Metrics**
- Latency, Packet Loss, Signal Strength
- TX/RX Throughput with live chart
- System Status (GOOD/WARNING/CRITICAL)

🎮 **Joystick Visualization**
- 2D radar display with glowing indicator
- Real-time X/Y position tracking

⚙️ **Easy Configuration**
- Switch between rovers without code changes
- Simulation mode for testing
- Auto-reconnect on connection loss

---

## Demo Script (3-5 minutes)

1. **Show Simulation Mode** (1 min)
   - Open dashboard
   - Show all metrics updating
   - Explain UI components

2. **Show ROS 2 Integration** (2 min)
   - Open settings, show IP config
   - Connect to real rover
   - Show live data streaming

3. **Show Code Quality** (1 min)
   - Quick tour of architecture
   - Mention 33 passing tests
   - Highlight modular design

---

## Files to Show Judges

- `README.md` - Full documentation
- `ros2-bridge.mjs` - Clean, well-commented bridge code
- `client/src/pages/Home.tsx` - Main dashboard component
- `client/src/hooks/useROS2Connection.ts` - WebSocket integration

---

**You're ready to win! 🏆**
